﻿using FileMerger;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ProjectTools
{
    public partial class FileMergerContext : UserControl
    {
        private List<string> Projects { get; } = new List<string>();
        ProjectMergeOptions Options = new ProjectMergeOptions();
        public FileMergerContext()
        {
            InitializeComponent();
        }

        private void btnMerge_Click(object sender, EventArgs e)
        {
            if(string.IsNullOrEmpty(tbInput.Text)) return;
            Options.StripComments = cbStripComments.Checked;
            Options.MergeNamespacesIntoOne = cbMergeNamespacesIntoOne.Checked;
            Options.CompressEmptyLines = cbCompressEmptyLines.Checked;
            Options.MergedNamespace = tbNamespaceMergeName.Text.Length == 0 ? "MergedProject" : tbNamespaceMergeName.Text;

            ProjectMerger.MergeProject(tbInput.Text, Options);
        }

        private void cbMergeNamespacesIntoOne_CheckedChanged(object sender, EventArgs e)
        {
            tbNamespaceMergeName.Enabled = cbMergeNamespacesIntoOne.Checked;
        }

        private void btnSelectProjects_Click(object sender, EventArgs e)
        {
            if(string.IsNullOrEmpty(tbInput.Text)) return;
            using(var dlg = new FolderPickerForm(tbInput.Text))
            {
                if(dlg.ShowDialog() == DialogResult.OK)
                {
                    Options.IncludeFolders.AddRange(dlg.IncludeFolders.ToList());
                    Options.ExcludeFolders.AddRange(dlg.ExcludeFolders.ToList());
                }
            }
        }
    }

    public sealed class FolderPickerForm : Form
    {
        private readonly string _projectRoot;

        private readonly TreeView _tree = new TreeView();
        private readonly RadioButton _rbInclude = new RadioButton();
        private readonly RadioButton _rbExclude = new RadioButton();
        private readonly Button _btnOk = new Button();
        private readonly Button _btnCancel = new Button();

        public List<string> IncludeFolders { get; } = new List<string>();
        public List<string> ExcludeFolders { get; } = new List<string>();

        public FolderPickerForm(string projectRoot)
        {
            _projectRoot = projectRoot;

            Text = "Select Project Folders";
            Width = 500;
            Height = 600;
            StartPosition = FormStartPosition.CenterParent;

            _tree.Dock = DockStyle.Fill;
            _tree.CheckBoxes = true;

            _rbInclude.Text = "Include selected folders";
            _rbInclude.Checked = true;

            _rbExclude.Text = "Exclude selected folders";

            var panelTop = new FlowLayoutPanel
            {
                Dock = DockStyle.Top,
                Height = 40
            };

            panelTop.Controls.Add(_rbInclude);
            panelTop.Controls.Add(_rbExclude);

            var panelBottom = new FlowLayoutPanel
            {
                Dock = DockStyle.Bottom,
                Height = 40,
                FlowDirection = FlowDirection.RightToLeft
            };

            _btnOk.Text = "OK";
            _btnCancel.Text = "Cancel";

            _btnOk.Click += (_, __) => ApplySelection();
            _btnCancel.Click += (_, __) => DialogResult = DialogResult.Cancel;

            panelBottom.Controls.Add(_btnOk);
            panelBottom.Controls.Add(_btnCancel);

            Controls.Add(_tree);
            Controls.Add(panelTop);
            Controls.Add(panelBottom);

            Load += (_, __) => BuildTree();
        }

        private void BuildTree()
        {
            _tree.Nodes.Clear();

            var root = new TreeNode(Path.GetFileName(_projectRoot))
            {
                Tag = ""
            };

            _tree.Nodes.Add(root);
            BuildSubTree(root, _projectRoot);
            root.Expand();
        }

        private void BuildSubTree(TreeNode parent, string path)
        {
            foreach(var dir in Directory.GetDirectories(path))
            {
                string name = Path.GetFileName(dir);

                if(name.Equals("bin", StringComparison.OrdinalIgnoreCase) ||
                    name.Equals("obj", StringComparison.OrdinalIgnoreCase) ||
                    name.Equals("files", StringComparison.OrdinalIgnoreCase))
                    continue;

                string relative = dir.Substring(_projectRoot.Length)
                                     .TrimStart(Path.DirectorySeparatorChar);

                var node = new TreeNode(name)
                {
                    Tag = relative.Replace('\\', '/')
                };

                parent.Nodes.Add(node);
                BuildSubTree(node, dir);
            }
        }

        private void ApplySelection()
        {
            IncludeFolders.Clear();
            ExcludeFolders.Clear();

            var selected = GetCheckedNodes(_tree.Nodes);

            if(_rbInclude.Checked)
                IncludeFolders.AddRange(selected);
            else
                ExcludeFolders.AddRange(selected);

            DialogResult = DialogResult.OK;
        }

        private static IEnumerable<string> GetCheckedNodes(TreeNodeCollection nodes)
        {
            foreach(TreeNode node in nodes)
            {
                if(node.Checked && node.Tag is string path && !string.IsNullOrEmpty(path))
                    yield return path;

                foreach(var child in GetCheckedNodes(node.Nodes))
                    yield return child;
            }
        }
    }
}
