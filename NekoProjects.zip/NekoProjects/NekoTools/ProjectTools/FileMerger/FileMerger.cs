﻿// File: ProjectMerger.cs
// Compile-ready – .NET Framework 4.8.1+ / .NET 6+
// ANALYSIS ONLY

using System;
using System.IO;
using System.Linq;
using System.Text;
using System.Collections.Generic;
using System.Text.RegularExpressions;

namespace ProjectTools
{
    public sealed class ProjectMergeOptions
    {
        public bool StripComments { get; set; } = false;
        public bool MergeNamespacesIntoOne { get; set; } = true;
        public bool CompressEmptyLines { get; set; } = true;
        public string MergedNamespace { get; set; } = "MergedProject";

        // NEW 🔽
        public List<string> IncludeFolders { get; } = new List<string>();
        public List<string> ExcludeFolders { get; } = new List<string>();
    }

    public static class ProjectMerger
    {
        public static void MergeProject(
            string projectRoot,
            ProjectMergeOptions options = null)
        {
            options = options??new ProjectMergeOptions();
            projectRoot = Path.GetFullPath(projectRoot);

            if(!Directory.Exists(projectRoot))
                throw new DirectoryNotFoundException(projectRoot);

            string filesDir = Path.Combine(projectRoot, "files");
            Directory.CreateDirectory(filesDir);

            var csFiles = Directory.GetFiles(projectRoot, "*.cs", SearchOption.AllDirectories)
                .Where(f =>
                    !f.Contains(@"\bin\") &&
                    !f.Contains(@"\obj\") &&
                    !f.Contains(@"\files\"))
                .Where(f => IsFolderAllowed(projectRoot, f, options))
                .OrderBy(f => f)
                .ToList();

            var usings = new HashSet<string>();
            var merged = new StringBuilder();

            string currentFolder = null;

            foreach(var file in csFiles)
            {
                string relativePath = GetRelativePath(projectRoot, file);
                string folder = Path.GetDirectoryName(relativePath)?.Replace('\\', '/') ?? "";

                string target = Path.Combine(filesDir, relativePath);
                Directory.CreateDirectory(Path.GetDirectoryName(target));
                File.Copy(file, target, true);

                if(currentFolder != folder)
                {
                    if(currentFolder != null)
                        merged.AppendLine("#endregion");

                    if(!string.IsNullOrEmpty(folder))
                    {
                        merged.AppendLine();
                        merged.AppendLine($"#region Folder: {folder}");
                    }

                    currentFolder = folder;
                }

                merged.AppendLine($"    #region File: {relativePath}");

                string content = File.ReadAllText(file);
                ExtractUsings(content, usings);
                content = RemoveNamespaceWrappers(content);

                merged.AppendLine(Indent(content.Trim(), 2));
                merged.AppendLine($"    #endregion");
                merged.AppendLine();
            }

            if(currentFolder != null)
                merged.AppendLine("#endregion");

            string body = merged.ToString();

            if(options.StripComments)
                body = StripComments(body);

            if(options.CompressEmptyLines)
                body = CompressEmptyLines(body);

            var finalFile = new StringBuilder();

            finalFile.AppendLine("// AUTO-GENERATED SUPER FILE");
            finalFile.AppendLine("// FOR STATIC ANALYSIS ONLY");
            finalFile.AppendLine("// GENERATED: " + DateTime.Now);
            finalFile.AppendLine();

            foreach(var u in usings.OrderBy(u => u))
                finalFile.AppendLine(u);

            finalFile.AppendLine();

            if(options.MergeNamespacesIntoOne)
            {
                finalFile.AppendLine($"namespace {options.MergedNamespace}");
                finalFile.AppendLine("{");
                finalFile.AppendLine(Indent(body, 1));
                finalFile.AppendLine("}");
            }
            else
            {
                finalFile.AppendLine(body);
            }

            File.WriteAllText(
                Path.Combine(filesDir, "MergedProject.cs"),
                finalFile.ToString(),
                Encoding.UTF8);
        }

        // -------------------------------------------------
        // FOLDER FILTERING
        // -------------------------------------------------
        private static bool IsFolderAllowed(
            string projectRoot,
            string filePath,
            ProjectMergeOptions options)
        {
            string relative = GetRelativePath(projectRoot, filePath)
                .Replace('\\', '/');

            bool included =
                options.IncludeFolders.Count == 0 ||
                options.IncludeFolders.Any(f =>
                    relative.StartsWith(
                        f.TrimEnd('/').Replace('\\', '/') + "/",
                        StringComparison.OrdinalIgnoreCase) ||
                    string.Equals(relative, f, StringComparison.OrdinalIgnoreCase));

            if(!included)
                return false;

            bool excluded =
                options.ExcludeFolders.Any(f =>
                    relative.StartsWith(
                        f.TrimEnd('/').Replace('\\', '/') + "/",
                        StringComparison.OrdinalIgnoreCase));

            return !excluded;
        }

        // -------------------------------------------------
        // RELATIVE PATH (INLINE)
        // -------------------------------------------------
        private static string GetRelativePath(string root, string fullPath)
        {
            root = Path.GetFullPath(root)
                .TrimEnd(Path.DirectorySeparatorChar) + Path.DirectorySeparatorChar;

            fullPath = Path.GetFullPath(fullPath);

            if(fullPath.StartsWith(root, StringComparison.OrdinalIgnoreCase))
                return fullPath.Substring(root.Length);

            Uri baseUri = new Uri(root);
            Uri fileUri = new Uri(fullPath);

            return Uri.UnescapeDataString(
                    baseUri.MakeRelativeUri(fileUri).ToString()
                )
                .Replace('/', Path.DirectorySeparatorChar);
        }

        // ---------------- helpers ----------------

        private static void ExtractUsings(string text, HashSet<string> usings)
        {
            foreach(Match m in Regex.Matches(text, @"^\s*using\s+[^\;]+;", RegexOptions.Multiline))
                usings.Add(m.Value.Trim());
        }

        private static string RemoveNamespaceWrappers(string text)
        {
            return Regex.Replace(
                text,
                @"namespace\s+[^{]+\{([\s\S]*?)\}\s*$",
                "$1",
                RegexOptions.Multiline);
        }

        private static string StripComments(string input)
        {
            input = Regex.Replace(input, @"/\*[\s\S]*?\*/", "");
            input = Regex.Replace(input, @"//.*?$", "", RegexOptions.Multiline);
            return input;
        }

        private static string CompressEmptyLines(string text)
        {
            return Regex.Replace(
                text,
                @"(\r?\n\s*){3,}",
                Environment.NewLine + Environment.NewLine);
        }

        private static string Indent(string text, int level)
        {
            string pad = new string(' ', level * 4);
            var lines = text.Split(new[] { "\r\n", "\n" }, StringSplitOptions.None);
            return string.Join(Environment.NewLine, lines.Select(l => pad + l));
        }
    }
}
