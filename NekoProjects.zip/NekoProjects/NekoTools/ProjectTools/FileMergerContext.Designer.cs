﻿namespace ProjectTools
{
    partial class FileMergerContext
    {
        /// <summary> 
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if(disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Designer de Componentes

        /// <summary> 
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.Label label1;
            System.Windows.Forms.FlowLayoutPanel flowLayoutPanel1;
            System.Windows.Forms.Panel panel1;
            this.tbInput = new System.Windows.Forms.TextBox();
            this.cbStripComments = new System.Windows.Forms.CheckBox();
            this.cbMergeNamespacesIntoOne = new System.Windows.Forms.CheckBox();
            this.tbNamespaceMergeName = new System.Windows.Forms.TextBox();
            this.cbCompressEmptyLines = new System.Windows.Forms.CheckBox();
            this.btnSelectProjects = new System.Windows.Forms.Button();
            this.btnMerge = new System.Windows.Forms.Button();
            this.gpFileMerger = new System.Windows.Forms.GroupBox();
            label1 = new System.Windows.Forms.Label();
            flowLayoutPanel1 = new System.Windows.Forms.FlowLayoutPanel();
            panel1 = new System.Windows.Forms.Panel();
            flowLayoutPanel1.SuspendLayout();
            panel1.SuspendLayout();
            this.gpFileMerger.SuspendLayout();
            this.SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            label1.Location = new System.Drawing.Point(3, 9);
            label1.Name = "label1";
            label1.Size = new System.Drawing.Size(52, 24);
            label1.TabIndex = 2;
            label1.Text = "Path:";
            // 
            // flowLayoutPanel1
            // 
            flowLayoutPanel1.AutoSize = true;
            flowLayoutPanel1.Controls.Add(panel1);
            flowLayoutPanel1.Controls.Add(this.cbStripComments);
            flowLayoutPanel1.Controls.Add(this.cbMergeNamespacesIntoOne);
            flowLayoutPanel1.Controls.Add(this.tbNamespaceMergeName);
            flowLayoutPanel1.Controls.Add(this.cbCompressEmptyLines);
            flowLayoutPanel1.Controls.Add(this.btnSelectProjects);
            flowLayoutPanel1.Controls.Add(this.btnMerge);
            flowLayoutPanel1.FlowDirection = System.Windows.Forms.FlowDirection.TopDown;
            flowLayoutPanel1.Location = new System.Drawing.Point(17, 19);
            flowLayoutPanel1.Name = "flowLayoutPanel1";
            flowLayoutPanel1.Size = new System.Drawing.Size(345, 331);
            flowLayoutPanel1.TabIndex = 3;
            // 
            // panel1
            // 
            panel1.Controls.Add(label1);
            panel1.Controls.Add(this.tbInput);
            panel1.Dock = System.Windows.Forms.DockStyle.Top;
            panel1.Location = new System.Drawing.Point(3, 3);
            panel1.Name = "panel1";
            panel1.Size = new System.Drawing.Size(339, 65);
            panel1.TabIndex = 4;
            // 
            // tbInput
            // 
            this.tbInput.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.tbInput.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbInput.Location = new System.Drawing.Point(0, 36);
            this.tbInput.Name = "tbInput";
            this.tbInput.Size = new System.Drawing.Size(339, 29);
            this.tbInput.TabIndex = 1;
            // 
            // cbStripComments
            // 
            this.cbStripComments.AutoSize = true;
            this.cbStripComments.Font = new System.Drawing.Font("Verdana", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cbStripComments.Location = new System.Drawing.Point(10, 74);
            this.cbStripComments.Margin = new System.Windows.Forms.Padding(10, 3, 10, 3);
            this.cbStripComments.Name = "cbStripComments";
            this.cbStripComments.Size = new System.Drawing.Size(201, 30);
            this.cbStripComments.TabIndex = 1;
            this.cbStripComments.Text = "StripComments";
            this.cbStripComments.UseVisualStyleBackColor = true;
            // 
            // cbMergeNamespacesIntoOne
            // 
            this.cbMergeNamespacesIntoOne.AutoSize = true;
            this.cbMergeNamespacesIntoOne.Font = new System.Drawing.Font("Verdana", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cbMergeNamespacesIntoOne.Location = new System.Drawing.Point(10, 110);
            this.cbMergeNamespacesIntoOne.Margin = new System.Windows.Forms.Padding(10, 3, 10, 3);
            this.cbMergeNamespacesIntoOne.Name = "cbMergeNamespacesIntoOne";
            this.cbMergeNamespacesIntoOne.Size = new System.Drawing.Size(325, 30);
            this.cbMergeNamespacesIntoOne.TabIndex = 1;
            this.cbMergeNamespacesIntoOne.Text = "MergeNamespacesIntoOne";
            this.cbMergeNamespacesIntoOne.UseVisualStyleBackColor = true;
            this.cbMergeNamespacesIntoOne.CheckedChanged += new System.EventHandler(this.cbMergeNamespacesIntoOne_CheckedChanged);
            // 
            // tbNamespaceMergeName
            // 
            this.tbNamespaceMergeName.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)));
            this.tbNamespaceMergeName.Enabled = false;
            this.tbNamespaceMergeName.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbNamespaceMergeName.Location = new System.Drawing.Point(19, 146);
            this.tbNamespaceMergeName.Name = "tbNamespaceMergeName";
            this.tbNamespaceMergeName.Size = new System.Drawing.Size(307, 29);
            this.tbNamespaceMergeName.TabIndex = 5;
            // 
            // cbCompressEmptyLines
            // 
            this.cbCompressEmptyLines.AutoSize = true;
            this.cbCompressEmptyLines.Font = new System.Drawing.Font("Verdana", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cbCompressEmptyLines.Location = new System.Drawing.Point(10, 181);
            this.cbCompressEmptyLines.Margin = new System.Windows.Forms.Padding(10, 3, 10, 3);
            this.cbCompressEmptyLines.Name = "cbCompressEmptyLines";
            this.cbCompressEmptyLines.Size = new System.Drawing.Size(265, 30);
            this.cbCompressEmptyLines.TabIndex = 1;
            this.cbCompressEmptyLines.Text = "CompressEmptyLines";
            this.cbCompressEmptyLines.UseVisualStyleBackColor = true;
            // 
            // btnSelectProjects
            // 
            this.btnSelectProjects.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)));
            this.btnSelectProjects.AutoSize = true;
            this.btnSelectProjects.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSelectProjects.Location = new System.Drawing.Point(80, 217);
            this.btnSelectProjects.Name = "btnSelectProjects";
            this.btnSelectProjects.Size = new System.Drawing.Size(185, 40);
            this.btnSelectProjects.TabIndex = 0;
            this.btnSelectProjects.Text = "Select Projects";
            this.btnSelectProjects.UseVisualStyleBackColor = true;
            this.btnSelectProjects.Click += new System.EventHandler(this.btnSelectProjects_Click);
            // 
            // btnMerge
            // 
            this.btnMerge.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)));
            this.btnMerge.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnMerge.Location = new System.Drawing.Point(83, 263);
            this.btnMerge.Name = "btnMerge";
            this.btnMerge.Size = new System.Drawing.Size(178, 40);
            this.btnMerge.TabIndex = 0;
            this.btnMerge.Text = "Merge";
            this.btnMerge.UseVisualStyleBackColor = true;
            this.btnMerge.Click += new System.EventHandler(this.btnMerge_Click);
            // 
            // gpFileMerger
            // 
            this.gpFileMerger.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.gpFileMerger.Controls.Add(flowLayoutPanel1);
            this.gpFileMerger.Location = new System.Drawing.Point(0, 0);
            this.gpFileMerger.Margin = new System.Windows.Forms.Padding(0);
            this.gpFileMerger.Name = "gpFileMerger";
            this.gpFileMerger.Size = new System.Drawing.Size(373, 381);
            this.gpFileMerger.TabIndex = 3;
            this.gpFileMerger.TabStop = false;
            this.gpFileMerger.Text = "File merger";
            // 
            // FileMergerContext
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSize = true;
            this.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.Controls.Add(this.gpFileMerger);
            this.Margin = new System.Windows.Forms.Padding(15);
            this.Name = "FileMergerContext";
            this.Size = new System.Drawing.Size(373, 381);
            flowLayoutPanel1.ResumeLayout(false);
            flowLayoutPanel1.PerformLayout();
            panel1.ResumeLayout(false);
            panel1.PerformLayout();
            this.gpFileMerger.ResumeLayout(false);
            this.gpFileMerger.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btnSelectProjects;
        private System.Windows.Forms.TextBox tbInput;
        private System.Windows.Forms.GroupBox gpFileMerger;
        private System.Windows.Forms.CheckBox cbStripComments;
        private System.Windows.Forms.CheckBox cbMergeNamespacesIntoOne;
        private System.Windows.Forms.CheckBox cbCompressEmptyLines;
        private System.Windows.Forms.TextBox tbNamespaceMergeName;
        private System.Windows.Forms.Button btnMerge;
    }
}
