﻿using PageNav.Core.Abstractions;
using PageNav.Core.Models;
 using PageNav.Diagnostics;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
 
namespace PageNav.Core.Services
{
    

    public enum NavigationLoadMode
    {
        ShowImmediately,     // current behavior
        LoadBeforeShow,      // preload then attach + show
        LoadInBackground     // show skeleton UI while loading
    }
    [Flags]
    public enum NavigationBehavior
    {
        Default   = 0,
        NoMask    = 1,
        Transient = 2,
        NoHistory = 4
    }
    public static partial class NavigationService
    {
        private static IPageHost _host;

        public static IPageView Current { get; private set; }
        public static IInteractionBlocker _blocker;
        internal static IEventDispatcherAdapter _events;
        private static IPageMask _mask;
        public static event Action<IPageView, Type, NavigationArgs> Navigating;
        public static event Action<IPageView, IPageView, NavigationArgs> Navigated;
        public static event Action<IPageView, Type, Exception> NavigationFailed;
        public static event Action<IPageView> CurrentChanged;
        public static event Action HistoryChanged;
        public static IDialogService Dialogs { get; private set; }
      
      
        public static void Initialize(object nativeHost, int timeoutSeconds = 10)
        {
#if DEBUG
            if(_host != null)
                throw new InvalidOperationException("NavigationService.Initialize called twice without Shutdown().");
#endif
            if(nativeHost == null)
                throw new ArgumentNullException(nameof(nativeHost));

            // Resolve platform
            var adapter = PlatformRegistry.ResolveHost(nativeHost);
            
            _host = adapter.CreateHost(nativeHost);

            // Retrieve platform-specific services (mask, event dispatcher, etc)
            _mask = adapter.CreateMask(nativeHost);
            _events = adapter.CreateEventDispatcher(nativeHost);
            _blocker = adapter.CreateInteractionBlocker(nativeHost);
            var timer = adapter.CreateTimerAdapter();
            Dialogs = adapter.CreateDialogService(nativeHost);
            // Init timeout + mask service
            PageMaskService.Initialize(_mask);
            TimeoutService.Initialize(timer, timeoutSeconds);

            TimeoutService.TimeoutReached += OnTimeout;
        }

        public static async Task Shutdown()
        {
            if(Current != null)
            {
                await PageLifecycleCleanupService.CleanupAsync(Current, _events);
                Current = null;
            }

            TimeoutService.TimeoutReached -= OnTimeout;
            TimeoutService.Dispose();
            if(_mask is IDisposable d)
                d.Dispose();

            Dialogs = null;
            _host = null;
            _events = null;
            _blocker = null;
            _mask = null;
        }


        // -------------------------------------------------------------------------
        // PUBLIC API
        // -------------------------------------------------------------------------


        public readonly struct NavigationArgs
        {
            public object Payload { get; }
            public NavigationBehavior Behavior { get; }
            public NavigationLoadMode LoadMode { get; }

            private NavigationArgs(
                object payload,
                NavigationBehavior behavior,
                NavigationLoadMode loadMode)
            {
                Payload = payload;
                Behavior = behavior;
                LoadMode = loadMode;
            }

            // ---- Factories (THIS is the key) ----

            public static NavigationArgs Default(object payload = null) => new NavigationArgs(payload, NavigationBehavior.Default, NavigationLoadMode.ShowImmediately);

            public static NavigationArgs Transient(object payload = null) => new NavigationArgs(payload, NavigationBehavior.Transient, NavigationLoadMode.ShowImmediately);

            public static NavigationArgs Silent(object payload = null) => new NavigationArgs(payload, NavigationBehavior.NoMask, NavigationLoadMode.ShowImmediately);

            public static NavigationArgs Preload(object payload = null) => new NavigationArgs(payload, NavigationBehavior.Default, NavigationLoadMode.LoadBeforeShow);

            public static NavigationArgs Background(object payload = null) => new NavigationArgs(payload, NavigationBehavior.Default, NavigationLoadMode.LoadInBackground);
        }









        // -------------------------------------------------------------------------
        // 1) CACHED NAVIGATION (Persistent pages)
        // -------------------------------------------------------------------------
        public static Task SwitchPage<T>(object args = null) where T : IPageView => SwitchInternal(typeof(T), NavigationArgs.Default(args));
        public static Task SwitchPage(Type type, object args = null) => SwitchInternal(type, NavigationArgs.Default(args));


        // -------------------------------------------------------------------------
        // 2) TRANSIENT NAVIGATION (New instance every time)
        // -------------------------------------------------------------------------
        public static Task SwitchTransient<T>(object args = null) where T : IPageView => SwitchInternal(typeof(T), NavigationArgs.Transient(args));
        public static Task SwitchTransient(Type type, object args = null) => SwitchInternal(type, NavigationArgs.Transient(args));



        public static async Task GoHomeAsync(object args = null)
        {
            var target = PageRegistry.ResolveTimeoutTarget();

            if(target == null)
                return; // or throw/log depending on design

            await SwitchInternal(target.GetType(), NavigationArgs.Default());
        }






        public static async Task<bool> GoBackAsync()
        {
            if(!NavigationHistory.CanGoBack)
                return false;

            var entry = NavigationHistory.PopBack();

            if(Current != null)
                NavigationHistory.PushForward(new PageHistoryEntry(Current, (Current as IPageStateful)?.CaptureState()));

            await SwitchInternal(
                entry.PageType,
                NavigationArgs.Default(entry.Payload)
                
            );

            return true;
        }

        public static async Task<bool> GoForwardAsync()
        {
            if(!NavigationHistory.CanGoForward)
                return false;

            var entry = NavigationHistory.PopForward();

            if(Current != null)
                NavigationHistory.Record(Current);

            await SwitchInternal(entry.PageType,NavigationArgs.Default(entry.Payload));

            return true;
        }
#if DEBUG
        public static void AssertFrameworkIsDown()
        {
            if(_host != null || Current != null || _events != null)
                throw new InvalidOperationException("Framework still alive. Did you forget NavigationService.Shutdown()?");
        }
#endif
    }

}
