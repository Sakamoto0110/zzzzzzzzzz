﻿using PageNav.Core.Models;
using PageNav.Diagnostics;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static PageNav.Core.Services.TimeoutService;

namespace PageNav.Core.Services
{
    public static partial class NavigationService
    {

        private static void OnChildViewAdded(object obj)
        {

            // Attach timeout reset handler to newly added controls
            if(_events != null)
            {
                _events.AttatchEvent<EventHandler>(obj, "Click", TimeoutService.Reset);
                _events.AttatchEvent<EventHandler>(obj, "Disposed", (_,__)=>Console.WriteLine($"{_} disposed"));
            }


        }

        private static void OnChildViewRemoved(object obj)
        {

            if(_events != null)
                _events.DetatchEvent<EventHandler>(obj, "Click", TimeoutService.Reset);


        }

        /// <summary>
        /// Default Timeout fallback
        /// </summary>
        internal static async void OnTimeout()
        {

            if(Current != null)
            {
                if(!PageRegistry.TryToGetDescriptor(Current.GetType(), out var desc))
                    throw new InvalidOperationException($"PageDescriptor of {Current.GetType()} not found.");

                switch(desc.Timeout)
                {
                    case TimeoutBehavior.IgnoreTimeout:
                        return;

                    case TimeoutBehavior.OverrideHome:
                        await SwitchInternal(desc.PageType, new NavigationArgs());
                        return;
                }
            }
            // try to switch to home page
            try
            {
                var target = PageRegistry.ResolveTimeoutTarget();

                if(target == null)
                    return;  
                await SwitchInternal(target.GetType(), NavigationArgs.Default());
            }
            catch(Exception ex)
            {
                PageLogger.LogError($"Timeout navigation failed: {ex.Message}");
            }

        }

    }
}
