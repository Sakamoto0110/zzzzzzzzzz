﻿using PageNav.Core.Abstractions;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PageNav.Core.Services
{
    public static class TimeoutService 
    {
        public enum TimeoutBehavior
        {
            Default,
            OverrideHome,
            IgnoreTimeout
        }
        public enum TimeoutState { Uninitialized, Running, Paused, Fired, Stopped }
        public static int SecondsRemaining => _thresholdTicks - _ticks;
        public static int TotalTimeoutSeconds => (_thresholdTicks * _intervalMs) / 1000;
        public static TimeoutState State { get; private set; } = TimeoutState.Uninitialized;
        private static ITimerAdapter _timer;
        private static int _ticks;
        private static int _thresholdTicks;
        private static int _intervalMs=1000;

        public static event Action TimeoutReached;

        public static void Initialize(ITimerAdapter timerAdapter, int timeoutSeconds)
        {
            _timer = timerAdapter ?? throw new ArgumentNullException(nameof(timerAdapter));
            if(State != TimeoutState.Uninitialized)
                throw new InvalidOperationException("TimeoutService already initialized.");
            State = TimeoutState.Running;
            // convert seconds → ticks (1 tick per second)
            _thresholdTicks = timeoutSeconds;

            _timer.Start(_intervalMs, OnTick); // 1s tick
        }

        private static void OnTick()
        {Console.WriteLine($"timeout {_ticks}");
            _ticks++; 
            if(_ticks >= _thresholdTicks)
            
            {
                
                _ticks = 0;
                
                Reset(null, EventArgs.Empty);
                TimeoutReached?.Invoke();
            }
        }

        public static void Reset(object s, EventArgs e)
        {
             _ticks = 0;
         }

        public static void Pause()
        {
            State = TimeoutState.Paused;
            _timer.Stop(); 
        }

        public static void Continue()
        {
            State = TimeoutState.Running;
            _timer.Continue();
              
        }

        public static void Dispose()
        {
             
            _timer?.Stop();
            _timer?.Dispose();
            _timer = null;


        }
    }
}
