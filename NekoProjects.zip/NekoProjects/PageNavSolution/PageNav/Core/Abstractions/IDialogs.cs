﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PageNav.Core.Abstractions
{
    public enum DialogIcon
    {
        None,
        Info,
        Warning,
        Error,
        Question
    }
    public enum DialogResult
    {
        None,
        Ok,
        Yes,
        No,
        Cancel,
        Abort,
Ignore,
Retry,

    }

    public interface IDialogService
    {
        /// <summary>Shows a simple informational message.</summary>
        Task<DialogResult> ShowMessageAsync(string message, string title = null, DialogIcon icon = DialogIcon.Info);

        /// <summary>Shows an OK/Cancel dialog.</summary>
        Task<DialogResult> ShowConfirmAsync(string message, string title = null, DialogIcon icon = DialogIcon.Question);

       
    }
}
