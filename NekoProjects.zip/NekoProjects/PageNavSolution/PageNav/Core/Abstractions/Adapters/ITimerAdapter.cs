﻿using System;

namespace PageNav.Core.Abstractions
{
    public interface ITimerAdapter : IDisposable
    {
        void Continue();
        void Start(int intervalMilliseconds, Action tick);
        void Stop();
    }
}
