﻿namespace PageNav.Core.Abstractions
{
    public interface IMovableAdapter
    {
        void MakeMovable(object view);
        void RemoveMovable(object view);
    }
}
