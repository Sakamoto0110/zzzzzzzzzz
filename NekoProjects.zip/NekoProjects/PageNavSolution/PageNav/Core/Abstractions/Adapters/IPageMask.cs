﻿namespace PageNav.Core.Abstractions
{
    public interface IPageMask
    {
        void Show(string message = "");
        void Hide();
    }
}
