﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PageNav.Core.Abstractions
{
    /// <summary>
    /// Represents a UI framework container (WinForms Panel, WPF Grid, etc.)
    /// where a PageView can attach itself.
    /// </summary>
    public interface IPageHost
    {

        void Attach(IPageView page);
    void Detach(IPageView page);
    void BringToFront(IPageView page);
        /// <summary>
        /// Called by NavigationService to add a page to the host.
        /// Framework adapter decides how to insert.
        /// </summary>
        void AddView(object frameworkView);

        /// <summary>
        /// Called by NavigationService to remove a page.
        /// </summary>
        void RemoveView(object frameworkView);

        /// <summary>
        /// Brings the view to the top (sets z-order).
        /// </summary>
        void BringToFront(object frameworkView);

        /// <summary>
        /// Sets focus to the view if supported.
        /// </summary>
        void Focus(object frameworkView);
    }
}
