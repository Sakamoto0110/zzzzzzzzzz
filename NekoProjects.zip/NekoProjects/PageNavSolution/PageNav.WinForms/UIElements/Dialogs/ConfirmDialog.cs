﻿using PageNav.WinForms.Controls;
using System.Drawing;
using System.Windows.Forms;
using static System.Net.Mime.MediaTypeNames;

public class ConfirmDialog : BaseDialogForm
{
    private Label lblMessage;
    private Button btnYes, btnNo;

    public ConfirmDialog(string message, string title = "Confirm")
    {
        Text = title;

        lblMessage = new Label
        {
            Text = message,
            AutoSize = false,
            TextAlign = ContentAlignment.MiddleCenter,
            Dock = DockStyle.Fill,
            Font = new Font("Segoe UI", 12)
        };

        btnYes = new Button { Text = "Yes", Dock = DockStyle.Bottom };
        btnNo = new Button { Text = "No", Dock = DockStyle.Bottom };

        btnYes.Click += (_, __) => CloseDialog(DialogResult.Yes);
        btnNo.Click += (_, __) => CloseDialog(DialogResult.No);

        Controls.Add(lblMessage);
        Controls.Add(btnYes);
        Controls.Add(btnNo);

        BindDragArea(lblMessage);
    }
}
