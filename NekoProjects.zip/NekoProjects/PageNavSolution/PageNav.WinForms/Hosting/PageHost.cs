﻿using PageNav.Core.Abstractions;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PageNav.WinForms
{
    public class PageHost : IPageHost
    {
        private readonly Control _container;

        public PageHost(Control container)
        {
            _container = container;
        }

        public void AddView(object view)
        {
            if(view is Control ctrl)
                _container.Controls.Add(ctrl);
        }

        public void RemoveView(object view)
        {
            if(view is Control ctrl)
                _container.Controls.Remove(ctrl);
        }

        public void BringToFront(object view)
        {
            if(view is Control ctrl)
                ctrl.BringToFront();
        }

        public void Focus(object view)
        {
            if(view is Control ctrl)
                ctrl.Focus();
        }
        public void Attach(IPageView page)
        {
            if(!(page?.NativeView is Control control))
                throw new InvalidOperationException(
                    "IPageView.NativeView must be a WinForms Control.");

            if(!_container.Controls.Contains(control))
            {
                control.Dock = DockStyle.Fill;
                _container.Controls.Add(control);
            }
        }
        public void Detach(IPageView page)
        {
            if(!(page?.NativeView is  Control control))
                return;

            if(_container.Controls.Contains(control))
                _container.Controls.Remove(control);
        }

        public void BringToFront(IPageView page)
        {
            if(page?.NativeView is Control control)
                control.BringToFront();
        }
    }
}
