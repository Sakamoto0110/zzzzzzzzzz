﻿using System.Threading.Tasks;
using System.Windows.Forms;
using PageNav.Core.Abstractions;
using DialogResult = PageNav.Core.Abstractions.DialogResult;

namespace PageNav.WinForms.Services
{
    public class WinFormsDialogService : IDialogService
    {
        public Task<DialogResult> ShowMessageAsync(string message, string title = null, DialogIcon icon = DialogIcon.Info)
        {
            return Task.FromResult(Convert(
                MessageBox.Show(message, title ?? "Info")));
        }

        public Task<DialogResult> ShowConfirmAsync(string message, string title = null, DialogIcon icon = DialogIcon.Question)
        {
            return Task.FromResult(Convert(
                MessageBox.Show(message, title ?? "Confirm")));
        }


        private DialogResult Convert(System.Windows.Forms.DialogResult input)
        {
            switch(input)
            {
                case System.Windows.Forms.DialogResult.OK: return DialogResult.Ok;
                case System.Windows.Forms.DialogResult.Yes: return DialogResult.Yes;
                case System.Windows.Forms.DialogResult.Cancel: return DialogResult.Cancel;
                case System.Windows.Forms.DialogResult.No: return DialogResult.No;
                case System.Windows.Forms.DialogResult.Abort: return DialogResult.Abort;
                case System.Windows.Forms.DialogResult.Ignore: return DialogResult.Ignore;
                case System.Windows.Forms.DialogResult.Retry: return DialogResult.Retry;
                default: return DialogResult.None;
            }
        }

    }
}
