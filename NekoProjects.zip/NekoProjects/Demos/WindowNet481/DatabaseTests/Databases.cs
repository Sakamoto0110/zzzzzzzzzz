﻿
using NekoDatabaseGatewayModern.Connection;
using NekoDatabaseGatewayModern.Query;
using NekoDbGatewayModern;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsNet481.DatabaseTests
{
    public partial class DatabasesWindow : Form
    {
        DatabaseGateway dg = new DatabaseGateway();
        public DatabasesWindow()
        {
            InitializeComponent();
        }

        private async void button1_Click(object sender, EventArgs e)
        {
            int i = 0;
            rtbOutput.Clear();
            using(var sql = DatabaseContexts.Remote)
            {
                sql.OnSqlGenerated += (_) => Console.WriteLine("SqlGenerated");
                sql.OnSqlDispatch += (_) => Console.WriteLine("SqlDispatch");
                sql.OnSuccess += (_) => Console.WriteLine("Success");
                sql.OnError += (_) => {
                    Console.WriteLine("Error");
                };
                await dg.Read<dynamic>(sql,
                    new QueryBuilder()
                    .Select("Nome", "id_setor", "id_funcionario")
                    .Top(5)
                    .From("Funcionarios"),
                    (func) => {

                        Invoke(new Action(() => {
                            rtbOutput.AppendText($"[{i++}]Funcionario:{func.Nome}, {func.id_funcionario}, {func.id_setor}\n");

                        }));
                    });



            }
        }

     
        private void button2_Click(object sender, EventArgs e)
        {
        }
        private void btnClear_Click(object sender, EventArgs e)
        {
            rtbOutput.Clear();
        }

        private void richTextBox1_TextChanged(object sender, EventArgs e)
        {
            if(rtbOutput.Text.Length > 0 && !rtbOutput.Text.EndsWith("\n")) rtbOutput.AppendText("\n");
        }
    }
    public static class DatabaseContexts
    {
        //private static readonly IDbConnectionFactory _oleDbFactory = new AccessConnectionFactory();
        private static readonly IDbConnectionFactory _oleDbFactory = null;
        private static readonly IDbConnectionFactory _sqlDbFactory = new SqlConnectionFactory("Server=SQL5111.site4now.net;Database=db_a45fb2_dmretiradanew;User Id=db_a45fb2_dmretiradanew_admin;Password=##DMRetiradaLab220##;");

        private static readonly IDbQueryTranslator _oleTranslator = new AccessQueryTranslator();
        private static readonly IDbQueryTranslator _sqlTranslator = new SqlServerQueryTranslator();

        public static QueryExecutionContext Local { get => new QueryExecutionContext(_oleDbFactory, _oleTranslator); }
        public static QueryExecutionContext Remote { get => new QueryExecutionContext(_sqlDbFactory, _sqlTranslator); }

    }
}
