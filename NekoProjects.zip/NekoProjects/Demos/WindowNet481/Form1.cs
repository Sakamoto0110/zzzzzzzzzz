using System;
using System.ComponentModel;
using System.Security.Policy;
using System.Windows.Forms;
using WindowsNet481.DatabaseTests;


namespace WindowsNet481
{
    public partial class Form1 : Form
    {
         public Form1()
        {
            InitializeComponent();
        }

        private void tsmiExitBtn_Click(object sender, EventArgs e) => Close();

        private void btnOpen_Click(object sender, EventArgs e)
        {
            if(cbSelectWindow.SelectedItem != null)
            {
                if((string)cbSelectWindow.SelectedItem == "DatabasesWindow")
                {
                    var wnd = new DatabasesWindow();
                    wnd.Show();

                }
            }
        }
    }
    
}
