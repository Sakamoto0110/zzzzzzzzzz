﻿namespace LibNet9
{
    public class Class1
    {
        public static int Minus(int a, int b) => a - b;
    }
}
