﻿namespace WindowNet9
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if(disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            components = new System.ComponentModel.Container();
            Label label1;
            ToolStripDropDownButton toolStripDropDownButton1;
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            tsmiExitBtn = new ToolStripMenuItem();
            cbSelectWindow = new ComboBox();
             btnOpen = new Button();
            statusStrip1 = new StatusStrip();
            toolStripStatusLabel1 = new ToolStripStatusLabel();
            toolStrip1 = new ToolStrip();
            label1 = new Label();
            toolStripDropDownButton1 = new ToolStripDropDownButton();
             statusStrip1.SuspendLayout();
            toolStrip1.SuspendLayout();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Verdana", 16F);
            label1.Location = new Point(12, 35);
            label1.Name = "label1";
            label1.Size = new Size(109, 26);
            label1.TabIndex = 1;
            label1.Text = "Window:";
            // 
            // toolStripDropDownButton1
            // 
            toolStripDropDownButton1.DisplayStyle = ToolStripItemDisplayStyle.Text;
            toolStripDropDownButton1.DropDownItems.AddRange(new ToolStripItem[] { tsmiExitBtn });
            toolStripDropDownButton1.Image = (Image)resources.GetObject("toolStripDropDownButton1.Image");
            toolStripDropDownButton1.ImageTransparentColor = Color.Magenta;
            toolStripDropDownButton1.Name = "toolStripDropDownButton1";
            toolStripDropDownButton1.Size = new Size(38, 22);
            toolStripDropDownButton1.Text = "File";
            // 
            // tsmiExitBtn
            // 
            tsmiExitBtn.Name = "tsmiExitBtn";
            tsmiExitBtn.Size = new Size(93, 22);
            tsmiExitBtn.Text = "Exit";
            tsmiExitBtn.Click += tsmiExitBtn_Click;
            // 
            // cbSelectWindow
            // 
            cbSelectWindow.Font = new Font("Verdana", 16F);
            cbSelectWindow.FormattingEnabled = true;
            cbSelectWindow.Items.AddRange(new object[] { "DatabasesWindow" });
            cbSelectWindow.Location = new Point(12, 64);
            cbSelectWindow.Name = "cbSelectWindow";
            cbSelectWindow.Size = new Size(269, 33);
            cbSelectWindow.TabIndex = 0;
            cbSelectWindow.Text = "DatabasesWindow";
            // 
            // availalbeWindowsBindingSource
            // 
             // 
            // btnOpen
            // 
            btnOpen.Font = new Font("Segoe UI", 12F);
            btnOpen.Location = new Point(287, 65);
            btnOpen.Name = "btnOpen";
            btnOpen.Size = new Size(120, 33);
            btnOpen.TabIndex = 2;
            btnOpen.Text = "Open";
            btnOpen.UseVisualStyleBackColor = true;
            btnOpen.Click += btnOpen_Click;
            // 
            // statusStrip1
            // 
            statusStrip1.Items.AddRange(new ToolStripItem[] { toolStripStatusLabel1 });
            statusStrip1.Location = new Point(0, 168);
            statusStrip1.Name = "statusStrip1";
            statusStrip1.Size = new Size(431, 22);
            statusStrip1.TabIndex = 3;
            statusStrip1.Text = "statusStrip1";
            // 
            // toolStripStatusLabel1
            // 
            toolStripStatusLabel1.Name = "toolStripStatusLabel1";
            toolStripStatusLabel1.Size = new Size(416, 17);
            toolStripStatusLabel1.Spring = true;
            // 
            // toolStrip1
            // 
            toolStrip1.Items.AddRange(new ToolStripItem[] { toolStripDropDownButton1 });
            toolStrip1.Location = new Point(0, 0);
            toolStrip1.Name = "toolStrip1";
            toolStrip1.Size = new Size(431, 25);
            toolStrip1.TabIndex = 4;
            toolStrip1.Text = "toolStrip1";
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(431, 190);
            Controls.Add(toolStrip1);
            Controls.Add(statusStrip1);
            Controls.Add(btnOpen);
            Controls.Add(label1);
            Controls.Add(cbSelectWindow);
            Name = "Form1";
            Text = "Form1";
             statusStrip1.ResumeLayout(false);
            statusStrip1.PerformLayout();
            toolStrip1.ResumeLayout(false);
            toolStrip1.PerformLayout();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private ComboBox cbSelectWindow;
        private Label label1;
        private Button btnOpen;
        private StatusStrip statusStrip1;
        private ToolStrip toolStrip1;
        private ToolStripMenuItem tsmiExitBtn;
        private ToolStripStatusLabel toolStripStatusLabel1;
     }
}
