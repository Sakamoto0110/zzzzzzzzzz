﻿using NekoLogger.Abstractions;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace NekoLogger.ConsoleUI
{
    public class NekoLogConsole : Form, INekoConsoleWindow
    {
        private System.ComponentModel.IContainer components = null;





        private TabControl TabLogControl;
        private NekoConsoleTab _AllLogs;
        private NekoConsoleTab _InfoLogs;
        private NekoConsoleTab _ErrorLogs;
        public IConsoleTabView ActiveWindow { get => (IConsoleTabView)TabLogControl.TabPages[TabLogControl.SelectedIndex].Controls[0]; }


        public NekoLogConsole()
        {

            InitializeComponent();



            // Controls.Add(Tabs);



        }

        private void InitializeComponent()
        {
            System.Windows.Forms.TabPage TabErrorLogs;
            System.Windows.Forms.TabPage TabInfoLogs;
            System.Windows.Forms.TabPage TabAllLogs;
            this._ErrorLogs = new global::NekoLogger.ConsoleUI.NekoConsoleTab();
            this._InfoLogs = new global::NekoLogger.ConsoleUI.NekoConsoleTab();
            this._AllLogs = new global::NekoLogger.ConsoleUI.NekoConsoleTab();
            this.TabLogControl = new System.Windows.Forms.TabControl();
            TabErrorLogs = new System.Windows.Forms.TabPage();
            TabInfoLogs = new System.Windows.Forms.TabPage();
            TabAllLogs = new System.Windows.Forms.TabPage();
            TabErrorLogs.SuspendLayout();
            TabInfoLogs.SuspendLayout();
            TabAllLogs.SuspendLayout();
            this.TabLogControl.SuspendLayout();
            this.SuspendLayout();
            // 
            // TabErrorLogs
            // 
            TabErrorLogs.Controls.Add(this._ErrorLogs);
            TabErrorLogs.Location = new System.Drawing.Point(4, 22);
            TabErrorLogs.Name = "TabErrorLogs";
            TabErrorLogs.Padding = new System.Windows.Forms.Padding(3);
            TabErrorLogs.Size = new System.Drawing.Size(592, 601);
            TabErrorLogs.TabIndex = 2;
            TabErrorLogs.Text = "ErrorLogs";
            TabErrorLogs.UseVisualStyleBackColor = true;
            // 
            // _ErrorLogs
            // 
            this._ErrorLogs.AllowInput = true;
            this._ErrorLogs.AllowZoom = true;
            this._ErrorLogs.Dock = System.Windows.Forms.DockStyle.Fill;
            this._ErrorLogs.Location = new System.Drawing.Point(3, 3);
            this._ErrorLogs.AllowedTags = new string[] {
        "ERROR",
        "WARN"};
            this._ErrorLogs.Name = "_ErrorLogs";
            this._ErrorLogs.ShowBottomMenu = true;
            this._ErrorLogs.Size = new System.Drawing.Size(586, 595);
            this._ErrorLogs.TabIndex = 0;
            // 
            // TabInfoLogs
            // 
            TabInfoLogs.Controls.Add(this._InfoLogs);
            TabInfoLogs.Location = new System.Drawing.Point(4, 22);
            TabInfoLogs.Name = "TabInfoLogs";
            TabInfoLogs.Padding = new System.Windows.Forms.Padding(3);
            TabInfoLogs.Size = new System.Drawing.Size(592, 601);
            TabInfoLogs.TabIndex = 1;
            TabInfoLogs.Text = "InfoLogs";
            TabInfoLogs.UseVisualStyleBackColor = true;
            // 
            // _InfoLogs
            // 
            this._InfoLogs.AllowInput = true;
            this._InfoLogs.AllowZoom = true;
            this._InfoLogs.Dock = System.Windows.Forms.DockStyle.Fill;
            this._InfoLogs.Location = new System.Drawing.Point(3, 3);
            this._InfoLogs.AllowedTags = new string[] {
        "INFO"};
            this._InfoLogs.Name = "_InfoLogs";
            this._InfoLogs.ShowBottomMenu = true;
            this._InfoLogs.Size = new System.Drawing.Size(586, 595);
            this._InfoLogs.TabIndex = 0;
            // 
            // TabAllLogs
            // 
            TabAllLogs.Controls.Add(this._AllLogs);
            TabAllLogs.Location = new System.Drawing.Point(4, 22);
            TabAllLogs.Name = "TabAllLogs";
            TabAllLogs.Padding = new System.Windows.Forms.Padding(3);
            TabAllLogs.Size = new System.Drawing.Size(592, 601);
            TabAllLogs.TabIndex = 0;
            TabAllLogs.Text = "All";
            TabAllLogs.UseVisualStyleBackColor = true;
            // 
            // _AllLogs
            // 
            this._AllLogs.AllowInput = true;
            this._AllLogs.AllowZoom = true;
            this._AllLogs.Dock = System.Windows.Forms.DockStyle.Fill;
            this._AllLogs.Location = new System.Drawing.Point(3, 3);
            this._AllLogs.AllowedTags = new string[] {
        "all"};
            this._AllLogs.Name = "_AllLogs";
            this._AllLogs.ShowBottomMenu = true;
            this._AllLogs.Size = new System.Drawing.Size(586, 595);
            this._AllLogs.TabIndex = 0;
            // 
            // TabLogControl
            // 
            this.TabLogControl.Controls.Add(TabAllLogs);
            this.TabLogControl.Controls.Add(TabInfoLogs);
            this.TabLogControl.Controls.Add(TabErrorLogs);
            this.TabLogControl.Dock = System.Windows.Forms.DockStyle.Fill;
            this.TabLogControl.Location = new System.Drawing.Point(0, 0);
            this.TabLogControl.Name = "TabLogControl";
            this.TabLogControl.SelectedIndex = 0;
            this.TabLogControl.Size = new System.Drawing.Size(600, 627);
            this.TabLogControl.TabIndex = 0;
            // 
            // NekoLogConsole
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(600, 627);
            this.Controls.Add(this.TabLogControl);
            this.Name = "NekoConsole";
            this.Text = "ConsoleHandler";
            TabErrorLogs.ResumeLayout(false);
            TabInfoLogs.ResumeLayout(false);
            TabAllLogs.ResumeLayout(false);
            this.TabLogControl.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        protected override void Dispose(bool disposing)
        {


            if(disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        private void nekoVirtualConsole21_Load(object sender, EventArgs e)
        {

        }
    }
}