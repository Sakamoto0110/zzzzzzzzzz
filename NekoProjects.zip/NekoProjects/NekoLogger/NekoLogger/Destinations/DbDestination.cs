﻿using NekoLogger.Abstractions;
using NekoLogger.Core;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NekoLogger.Destinations
{
    public class DatabaseDestination : ILoggerDestination
    {
        private readonly string _connectionString;

        public DatabaseDestination(string conn) => _connectionString = conn;

        public void Write(LoggerEventArgs e)
        {
            // Placeholder – adapt to SQL/Access provider
        }
    }
}
