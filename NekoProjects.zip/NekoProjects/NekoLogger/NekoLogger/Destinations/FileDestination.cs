﻿using NekoLogger.Abstractions;
using NekoLogger.Core;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NekoLogger.Destinations
{
    public class FileDestination : ILoggerDestination
    {
        private readonly string _file;

        public FileDestination(string file)
        {
            _file = file;
        }

        public void Write(LoggerEventArgs e)
        {            
            File.AppendAllText(_file, e.FullMessage + Environment.NewLine);
        }
    }
}
