﻿using NekoLogger.Abstractions;
using NekoLogger.Core;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NekoLogger.Destinations
{
    public class ConsoleDestination : LogDestination, ILoggerDestination
    {

        public void Write(LoggerEventArgs e)
        {
            System.Console.ForegroundColor = ConsoleColor.Gray;

            switch(e.Severity)
            {
                case Severity.Error: System.Console.ForegroundColor = ConsoleColor.Red; break;
                case Severity.Warn: System.Console.ForegroundColor = ConsoleColor.Yellow; break;
                case Severity.Done: System.Console.ForegroundColor = ConsoleColor.Green; break;
            }

            System.Console.WriteLine(e.FullMessage);
            System.Console.ResetColor();
        }
    }
}
