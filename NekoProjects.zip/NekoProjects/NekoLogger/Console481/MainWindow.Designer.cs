﻿namespace Console481
{
    partial class MainWindow
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if(disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnInfo = new System.Windows.Forms.Button();
            this.btnWarn = new System.Windows.Forms.Button();
            this.btnError = new System.Windows.Forms.Button();
            this.btnGeneric = new System.Windows.Forms.Button();
            this.btnZoom = new System.Windows.Forms.Button();
            this.btnFooter = new System.Windows.Forms.Button();
            this.btnInput = new System.Windows.Forms.Button();
            this.btnEx = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // btnInfo
            // 
            this.btnInfo.Location = new System.Drawing.Point(123, 12);
            this.btnInfo.Name = "btnInfo";
            this.btnInfo.Size = new System.Drawing.Size(105, 45);
            this.btnInfo.TabIndex = 0;
            this.btnInfo.Text = "INFO";
            this.btnInfo.UseVisualStyleBackColor = true;
            this.btnInfo.Click += new System.EventHandler(this.btnInfo_Click);
            // 
            // btnWarn
            // 
            this.btnWarn.Location = new System.Drawing.Point(234, 12);
            this.btnWarn.Name = "btnWarn";
            this.btnWarn.Size = new System.Drawing.Size(105, 45);
            this.btnWarn.TabIndex = 0;
            this.btnWarn.Text = "WARN";
            this.btnWarn.UseVisualStyleBackColor = true;
            this.btnWarn.Click += new System.EventHandler(this.btnWarn_Click);
            // 
            // btnError
            // 
            this.btnError.Location = new System.Drawing.Point(345, 12);
            this.btnError.Name = "btnError";
            this.btnError.Size = new System.Drawing.Size(105, 45);
            this.btnError.TabIndex = 0;
            this.btnError.Text = "ERROR";
            this.btnError.UseVisualStyleBackColor = true;
            this.btnError.Click += new System.EventHandler(this.btnError_Click);
            // 
            // btnGeneric
            // 
            this.btnGeneric.Location = new System.Drawing.Point(12, 12);
            this.btnGeneric.Name = "btnGeneric";
            this.btnGeneric.Size = new System.Drawing.Size(105, 45);
            this.btnGeneric.TabIndex = 0;
            this.btnGeneric.Text = "GENERIC";
            this.btnGeneric.UseMnemonic = false;
            this.btnGeneric.UseVisualStyleBackColor = true;
            this.btnGeneric.Click += new System.EventHandler(this.btnGeneric_Click);
            // 
            // btnZoom
            // 
            this.btnZoom.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnZoom.Location = new System.Drawing.Point(12, 63);
            this.btnZoom.Name = "btnZoom";
            this.btnZoom.Size = new System.Drawing.Size(105, 45);
            this.btnZoom.TabIndex = 1;
            this.btnZoom.Text = "Toggle zoom";
            this.btnZoom.UseVisualStyleBackColor = true;
            this.btnZoom.Click += new System.EventHandler(this.btnZoom_Click);
            // 
            // btnFooter
            // 
            this.btnFooter.Location = new System.Drawing.Point(123, 61);
            this.btnFooter.Name = "btnFooter";
            this.btnFooter.Size = new System.Drawing.Size(105, 45);
            this.btnFooter.TabIndex = 1;
            this.btnFooter.Text = "Toggle footer";
            this.btnFooter.UseVisualStyleBackColor = true;
            this.btnFooter.Click += new System.EventHandler(this.btnFooter_Click);
            // 
            // btnInput
            // 
            this.btnInput.Location = new System.Drawing.Point(234, 61);
            this.btnInput.Name = "btnInput";
            this.btnInput.Size = new System.Drawing.Size(105, 45);
            this.btnInput.TabIndex = 1;
            this.btnInput.Text = "Toggle input";
            this.btnInput.UseVisualStyleBackColor = true;
            this.btnInput.Click += new System.EventHandler(this.btnInput_Click);
            // 
            // btnEx
            // 
            this.btnEx.Enabled = false;
            this.btnEx.Location = new System.Drawing.Point(345, 63);
            this.btnEx.Name = "btnEx";
            this.btnEx.Size = new System.Drawing.Size(105, 45);
            this.btnEx.TabIndex = 1;
            this.btnEx.Text = "UNSED";
            this.btnEx.UseVisualStyleBackColor = true;
            this.btnEx.Click += new System.EventHandler(this.btnEx_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(474, 140);
            this.Controls.Add(this.btnEx);
            this.Controls.Add(this.btnInput);
            this.Controls.Add(this.btnFooter);
            this.Controls.Add(this.btnZoom);
            this.Controls.Add(this.btnError);
            this.Controls.Add(this.btnWarn);
            this.Controls.Add(this.btnGeneric);
            this.Controls.Add(this.btnInfo);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btnInfo;
        private System.Windows.Forms.Button btnWarn;
        private System.Windows.Forms.Button btnError;
        private System.Windows.Forms.Button btnGeneric;
        private System.Windows.Forms.Button btnZoom;
        private System.Windows.Forms.Button btnFooter;
        private System.Windows.Forms.Button btnInput;
        private System.Windows.Forms.Button btnEx;
    }
}