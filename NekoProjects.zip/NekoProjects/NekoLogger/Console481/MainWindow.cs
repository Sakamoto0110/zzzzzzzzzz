﻿using NekoLogger.Abstractions;
using NekoLogger.ConsoleUI;
using NekoLogger.Core;
using NekoLogger.Destinations;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Console481
{
    public partial class MainWindow : Form
    {
        INekoConsoleWindow NekoConsole;
        public MainWindow()
        {
            Logger.AddDestination(new ConsoleDestination() { AllowedTags = new[] { "" } });
            InitializeComponent();
            NekoConsole = new NekoLogConsole();
            NekoConsole.Show();


        }
        private void btnGeneric_Click(object sender, EventArgs e)
        {
            Logger.Log("Some message.");
        }
        private void btnInfo_Click(object sender, EventArgs e)
        {
            Logger.Log(sender: this,
                       severity: Severity.Info,
                       content: "Some infomation message.",
                       tags: new[] { "info" });
        }

        private void btnWarn_Click(object sender, EventArgs e)
        {
            Logger.Log(sender: this,
                       severity: Severity.Warn,
                       content: "Some warn message.",
                       tags: new[] { "warn" });
        }

        private void btnError_Click(object sender, EventArgs e)
        {
            Logger.Log(sender: this,
                       severity: Severity.Error,
                       content: "Some error message.",
                       tags: new[] { "error" });
        }

        private void btnZoom_Click(object sender, EventArgs e)
        {
            NekoConsole.ActiveWindow.AllowZoom = !NekoConsole.ActiveWindow.AllowZoom;

        }

        private void btnFooter_Click(object sender, EventArgs e)
        {
            NekoConsole.ActiveWindow.ShowBottomMenu = !NekoConsole.ActiveWindow.ShowBottomMenu;
        }

        private void btnInput_Click(object sender, EventArgs e)
        {
            NekoConsole.ActiveWindow.AllowInput = !NekoConsole.ActiveWindow.AllowInput;
        }

        private void btnEx_Click(object sender, EventArgs e)
        {

        }
    }
}
