﻿// AUTO-GENERATED SUPER FILE
// FOR STATIC ANALYSIS ONLY
// GENERATED: 17/12/2025 12:27:02

using Microsoft.Data.SqlClient;
using NekoDatabaseGatewayModern.Connection;
using NekoDatabaseGatewayModern.Dynamic;
using NekoDatabaseGatewayModern.Mapping;
using NekoDatabaseGatewayModern.Query;
using NekoDbGatewayModern;
using System.Collections.Generic;
using System.Data.Common;
using System.Data.OleDb;
using System.Data;
using System.Diagnostics;
using System.Dynamic;
using System.Globalization;
using System.Linq;
using System.Reflection.Emit;
using System.Reflection;
using System.Runtime.CompilerServices;
using System.Text.RegularExpressions;
using System.Text;
using System.Threading.Tasks;
using System.Threading;
using System;


#region Folder: Connection
    #region File: Connection\Factories.cs
        #nullable enable
        using System;
        using System.Data.Common;
        using System.Data.OleDb;
        using System.Diagnostics;
        using System.Threading.Tasks;
        using Microsoft.Data.SqlClient;
        using NekoDbGatewayModern;

public interface IDbConnectionFactory : IDisposable
            {

Task<DbConnection> Create();

public class DbConnectionAbstractFactory<T> : IDbConnectionFactory where T : DbConnection
            {
                private readonly string _connectionString;
                private DbConnection? _connection;

public DbConnectionAbstractFactory(string ConnectionString)
                {
                    if(ConnectionString == null) throw new ArgumentNullException(nameof(ConnectionString));
                    _connectionString = ConnectionString;
                }

public Task<DbConnection> Create()
                {
                                _connection = (DbConnection?)Activator.CreateInstance(typeof(T), _connectionString);
                    if(_connection is null) throw new InvalidOperationException($"Failed to create connection of type {typeof(T).FullName}.");
                    return Task.FromResult(_connection);
                }
        
                public void Dispose()
                {
                    if(_connection != null && _connection.State != System.Data.ConnectionState.Closed)
                    {
                        try
                        {
                            _connection.Close();
                        }
                        catch(Exception ex) { Debug.WriteLine($"Unable to close {_connection.Database} connection\n{ex.Message}"); }
                    }
                                _connection?.Dispose();            
                }
            }

public sealed class AccessConnectionFactory : DbConnectionAbstractFactory<OleDbConnection>
            {
                public AccessConnectionFactory(string ConnectionString) : base(ConnectionString) { }
            }

public sealed class SqlConnectionFactory : DbConnectionAbstractFactory<SqlConnection>
            {
                public SqlConnectionFactory(string ConnectionString) : base(ConnectionString) { }
            }
        }
    #endregion

#endregion
    #region File: DatabaseGateway.Core.cs
        #nullable enable
        using NekoDatabaseGatewayModern.Query;
        using System;
        using System.Collections.Generic;
        using System.Data;
        using System.Data.Common;
        using System.Data.OleDb;
        using System.Linq;
        using System.Threading;
        using System.Threading.Tasks;

public partial class DatabaseGateway
            {
        
                #region ctor

public DatabaseGateway()
                {

#endregion
        
                #region Connection / command helpers
        
                private async Task<DbConnection> OpenConnectionAsync(QueryExecutionContext ctx,CancellationToken Ct)
                {
                    var conn = await ctx.ConnectionFactory.Create().ConfigureAwait(false);

try
                    {
                        await conn.OpenAsync(Ct).ConfigureAwait(false);
                    }
                    catch(NotSupportedException)
                    {
                        conn.Open();
                    }
        
                    return conn;

}
        
                private async Task<T> WithCommandAsync<T>(QueryExecutionContext ctx, string Sql, Dictionary<string, object?>? Parameters, Func<DbCommand, Task<T>> work, CancellationToken Ct)
                {
                    if(Sql == null) throw new ArgumentNullException(nameof(Sql));
                    if(work == null) throw new ArgumentNullException(nameof(work));
                    if(ctx == null) throw new ArgumentNullException(nameof(ctx));
                    using(DbConnection conn = await OpenConnectionAsync(ctx,Ct).ConfigureAwait(false))
                    {
                        using(DbCommand cmd = conn.CreateCommand())
                        {
                            cmd.CommandText = Sql;
                            cmd.CommandType = CommandType.Text;
        
                            ApplyParameters(cmd, Parameters);
                            T result = default;
                            try
                            {
                                
                                ctx.RaiseSqlDispatch(Sql);
                                result = await work(cmd).ConfigureAwait(false);
                                ctx.RaiseSuccess(Sql);
                            }
                            catch(Exception ex) { ctx.RaiseError(Sql,ex); }
                            return result;
                            
                        }
                    }
                }
        
                private Task<T> WithCommandAsync<T>(QueryExecutionContext ctx, string Sql, Func<DbCommand, Task<T>> work, CancellationToken Ct)
                {
                    return WithCommandAsync(ctx, Sql, null, work, Ct);
                }
        
                private static async Task<DbDataReader> ExecuteReaderSafeAsync(DbCommand Cmd, CancellationToken Ct)
                {
                    try
                    {
                        DbDataReader reader = await Cmd.ExecuteReaderAsync(Ct).ConfigureAwait(false);
                        return reader;
                    }
                    catch(NotSupportedException)
                    {
                        return Cmd.ExecuteReader();
                    }
                }
        
                private static async Task<int> ExecuteNonQuerySafeAsync(DbCommand Cmd, CancellationToken Ct)
                {
                    try
                    {
                        int count = await Cmd.ExecuteNonQueryAsync(Ct).ConfigureAwait(false);
                        return count;
                    }
                    catch(NotSupportedException)
                    {
                        return Cmd.ExecuteNonQuery();
                    }
                }
        
                private static async Task<bool> ReadSafeAsync(DbDataReader Reader, CancellationToken Ct)
                {          
                    try
                    {
                        bool has = await Reader.ReadAsync(Ct).ConfigureAwait(false);
                        return has;
                    }
                    catch(NotSupportedException)
                    {
                        return Reader.Read();
                    }
                }
        
                private static void ApplyParameters(DbCommand Cmd, Dictionary<string, object?>? Parameters)
                {
                    if(Parameters == null || Parameters.Count == 0)
                        return;
        
                    bool isAccess = Cmd is OleDbCommand;
        
                    IEnumerable<KeyValuePair<string, object>> ordered;
        
                    if(isAccess)
                        ordered = new List<KeyValuePair<string, object>>(Parameters).OrderBy(p => p.Key, StringComparer.Ordinal);
                    else
                        ordered = Parameters;
        
                    foreach(KeyValuePair<string, object> kv in ordered)
                    {
                        DbParameter p = Cmd.CreateParameter();
                        if(!isAccess)
                            p.ParameterName = kv.Key;
        
                        p.Value = kv.Value ?? DBNull.Value;
                        Cmd.Parameters.Add(p);
                    }
                }
        
                #endregion

}
        }
    #endregion

    #region File: DatabaseGateway.Dynamic.cs
        #nullable enable
        using NekoDatabaseGatewayModern.Query;
        using System;
        using System.Collections.Generic;
        using System.Data.Common;
        using System.Globalization;
        using System.Reflection;
        using System.Reflection.Emit;
        using System.Threading;
        using System.Threading.Tasks;

public partial class DatabaseGateway
            {
                #region DynamicRow (IL-backed)

public sealed class DynamicRow : System.Dynamic.DynamicObject
                {
                    private readonly object _instance;
                    private readonly Dictionary<string, PropertyInfo> _props;
        
                    public DynamicRow(object Instance)
                    {
                        if(Instance == null) throw new ArgumentNullException(nameof(Instance));
                        _instance = Instance;
        
                        PropertyInfo[] properties = Instance
                            .GetType()
                            .GetProperties(BindingFlags.Public | BindingFlags.Instance);
        
                        _props = new Dictionary<string, PropertyInfo>(properties.Length, StringComparer.OrdinalIgnoreCase);
                        for(int i = 0; i < properties.Length; i++)
                        {
                            PropertyInfo p = properties[i];
                            string key = p.Name.ToLowerInvariant();
                            _props[key] = p;
                        
                    }
        
                    public object? this[string Name]
                    {
                        get { return Get(Name); }
                        set { Set(Name, value); }
                    }
        
                    private object? Get(string Name)
                    {
                        if(string.IsNullOrEmpty(Name)) return null;
                        string key = Name.ToLowerInvariant();
                        PropertyInfo pi;
                        if(_props.TryGetValue(key, out pi))
                            return pi.GetValue(_instance, null);
                        return null;
                    }
        
                    private void Set(string Name, object? Value)
                    {
                        if(string.IsNullOrEmpty(Name)) return;
                        string key = Name.ToLowerInvariant();
                        PropertyInfo pi;
                        if(_props.TryGetValue(key, out pi) && pi.CanWrite)
                            pi.SetValue(_instance, Value, null);
                    }
        
                    public override bool TryGetMember(System.Dynamic.GetMemberBinder Binder, out object? Result)
                    {
                        Result = Get(Binder.Name);
                        return true;
                    }
        
                    public override bool TrySetMember(System.Dynamic.SetMemberBinder Binder, object? Value)
                    {
                        Set(Binder.Name, Value);
                        return true;
                    }
        
                    public override bool TryGetIndex(System.Dynamic.GetIndexBinder Binder, object[] Indexes, out object? Result)
                    {
                        if(Indexes != null && Indexes.Length == 1 && Indexes[0] is string)
                        {
                            string name = (string)Indexes[0];
                            Result = Get(name);
                            return true;
                        }
        
                        Result = null;
                        return false;
                    }
        
                    public override bool TrySetIndex(System.Dynamic.SetIndexBinder Binder, object[] Indexes, object? Value)
                    {
                        if(Indexes != null && Indexes.Length == 1 && Indexes[0] is string)
                        {
                            string name = (string)Indexes[0];
                            Set(name, Value);
                            return true;
                        }
        
                        return false;
                    }
                }
        
                #endregion
        
                #region RuntimeTypeFactory + FillDynamicObject
        
                private static class RuntimeTypeFactory
                {
                    private static readonly AssemblyName _assemblyName = new AssemblyName("DynamicRowTypesAsm");
                    private static readonly ModuleBuilder _module;
                    private static readonly Dictionary<string, Type> _cache = new Dictionary<string, Type>(StringComparer.Ordinal);
                    private static readonly LinkedList<string> _lru = new LinkedList<string>();
                    private const int MaxTypes = 256;
                    private static int _typeCounter;
                    private static readonly object _sync = new object();
        
                    static RuntimeTypeFactory()
                    {
                        AssemblyBuilder ab = AssemblyBuilder.DefineDynamicAssembly(
                            _assemblyName, AssemblyBuilderAccess.Run);
                        _module = ab.DefineDynamicModule("MainModule");
                    }
        
                    public static Type GetOrCreate(SchemaInfo Schema)
                    {
                        if(Schema == null) throw new ArgumentNullException(nameof(Schema));
        
                        string signature = BuildSignature(Schema);
        
                        lock(_sync)
                        {
                            Type t;
                            if(_cache.TryGetValue(signature, out t))
                            {
                                MoveToTail(signature);
                                return t;
                            }
        
                            Type created = CreateType(Schema);
                            _cache[signature] = created;
                            _lru.AddLast(signature);
                            EnforceCapacity();
                            return created;
                        }
                    }
        
                    private static string BuildSignature(SchemaInfo Schema)
                    {
                        System.Text.StringBuilder sb = new System.Text.StringBuilder();
        
                        List<string> ordered = new List<string>(Schema.Columns);
                        ordered.Sort(StringComparer.OrdinalIgnoreCase);
        
                        for(int i = 0; i < ordered.Count; i++)
                        {
                            string col = ordered[i];
                            Type t;
                            if(!Schema.ColumnTypes.TryGetValue(col, out t) || t == null)
                                t = typeof(string);
        
                            sb.Append(col.ToLowerInvariant());
                            sb.Append(':');
                            sb.Append(t.FullName);
                            sb.Append('|');
                        }
        
                        return sb.ToString();
                    }
        
                    private static Type CreateType(SchemaInfo Schema)
                    {
                        string typeName = "DynamicRowType_" + System.Threading.Interlocked.Increment(ref _typeCounter);
                        TypeBuilder tb = _module.DefineType(typeName, TypeAttributes.Public | TypeAttributes.Class);
        
                        for(int i = 0; i < Schema.Columns.Count; i++)
                        {
                            string propName = Schema.Columns[i];
                            Type propType;
                            if(!Schema.ColumnTypes.TryGetValue(propName, out propType) || propType == null)
                                propType = typeof(string);
        
                            FieldBuilder field = tb.DefineField("_" + propName, propType, FieldAttributes.Private);
                            PropertyBuilder prop = tb.DefineProperty(
                                propName,
                                System.Reflection.PropertyAttributes.HasDefault,
                                propType,
                                null);
        
                            MethodBuilder getter = tb.DefineMethod(
                                "get_" + propName,
                                MethodAttributes.Public | MethodAttributes.SpecialName | MethodAttributes.HideBySig,
                                propType,
                                Type.EmptyTypes);
        
                            ILGenerator ilGet = getter.GetILGenerator();
                            ilGet.Emit(OpCodes.Ldarg_0);
                            ilGet.Emit(OpCodes.Ldfld, field);
                            ilGet.Emit(OpCodes.Ret);
        
                            MethodBuilder setter = tb.DefineMethod(
                                "set_" + propName,
                                MethodAttributes.Public | MethodAttributes.SpecialName | MethodAttributes.HideBySig,
                                null,
                                new Type[] { propType });
        
                            ILGenerator ilSet = setter.GetILGenerator();
                            ilSet.Emit(OpCodes.Ldarg_0);
                            ilSet.Emit(OpCodes.Ldarg_1);
                            ilSet.Emit(OpCodes.Stfld, field);
                            ilSet.Emit(OpCodes.Ret);
        
                            prop.SetGetMethod(getter);
                            prop.SetSetMethod(setter);
                        }
        
                        Type createdType = tb.CreateType();
                        return createdType;
                    }
        
                    private static void MoveToTail(string Key)
                    {
                        LinkedListNode<string> node = _lru.Find(Key);
                        if(node != null)
                        {
                            _lru.Remove(node);
                            _lru.AddLast(node);
                        }
                    }
        
                    private static void EnforceCapacity()
                    {
                        while(_lru.Count > MaxTypes)
                        {
                            LinkedListNode<string> first = _lru.First;
                            if(first == null) break;
        
                            string key = first.Value;
                            _lru.RemoveFirst();
                            _cache.Remove(key);
                        }
                    }
                }
        
                private static void FillDynamicObject(object Instance, Type RuntimeType, SchemaInfo Schema, DbDataReader Reader)
                {
                    for(int i = 0; i < Schema.Columns.Count; i++)
                    {
                        string col = Schema.Columns[i];
                        PropertyInfo pi = RuntimeType.GetProperty(col);
                        if(pi == null || !pi.CanWrite) continue;
        
                        object raw = Reader[col];
                        if(raw is DBNull) continue;
        
                        try
                        {
                            Type targetType = pi.PropertyType;
                            if(targetType.IsGenericType &&
                                targetType.GetGenericTypeDefinition() == typeof(Nullable<>))
                            {
                                targetType = Nullable.GetUnderlyingType(targetType);
                            }
        
                            object converted = Convert.ChangeType(raw, targetType, CultureInfo.InvariantCulture);
                            pi.SetValue(Instance, converted, null);
                        }
                        catch
                        {
                            try { pi.SetValue(Instance, raw, null); } catch { }
                        }
                    }
                }
        
                #endregion
        
                #region Dynamic API (IL + DynamicRow, no DTO)
        
                public async Task<List<DynamicRow>> GetDynamic(QueryExecutionContext ctx,QueryBuilder Builder,  CancellationToken Ct = default)
                {
                    if(Builder == null) throw new ArgumentNullException(nameof(Builder));
                    if(ctx == null) throw new ArgumentNullException(nameof(ctx));
        
                    List<DynamicRow> list = new List<DynamicRow>();
                    await ReadDynamic(ctx, Builder, delegate (DynamicRow row) { list.Add(row); }, Ct)
                        .ConfigureAwait(false);
                    return list;
                }
        
                public async Task ReadDynamic(QueryExecutionContext ctx,QueryBuilder Builder ,Action<DynamicRow> Callback,CancellationToken Ct = default)
                {
                    if(Builder == null) throw new ArgumentNullException(nameof(Builder));
                    if(Callback == null) throw new ArgumentNullException(nameof(Callback));
                    if(ctx == null) throw new ArgumentNullException(nameof(ctx));
        
                    var translator = ctx.Translator;
                    QueryModel model = Builder.Build();
                    ctx.RaiseSqlGenerated(model.Sql);
                    DbQuery dbq = translator.Translate(model);
        
                    await WithCommandAsync(ctx, dbq.Sql,  dbq.Parameters, async delegate (DbCommand cmd)
                    {
                        using(DbDataReader reader = await ExecuteReaderSafeAsync(cmd, Ct).ConfigureAwait(false))
                        {
                            SchemaInfo schema = ExtractSchema(reader);
        
                            if(schema.Columns.Count == 0)
                                return 0;
        
                            Type ilType = RuntimeTypeFactory.GetOrCreate(schema);
        
                            while(await ReadSafeAsync(reader, Ct).ConfigureAwait(false))
                            {
                                object inst = Activator.CreateInstance(ilType);
                                FillDynamicObject(inst, ilType, schema, reader);
                                DynamicRow row = new DynamicRow(inst);
                                try
                                {
                                    ctx.RaiseSqlDispatch(dbq.Sql);
                                    Callback(row);
                                }
                                catch(Exception ex) { ctx.RaiseError(dbq.Sql,ex); }
                                
                            }
                            
                        }
        
                        return 0;
                    }, Ct).ConfigureAwait(false);
                }

#region DataStreaming
        
                public IAsyncEnumerable<DynamicRow> StreamDynamic(QueryExecutionContext ctx, QueryBuilder builder, CancellationToken ct = default)
        
                {
                    if(ctx == null) throw new ArgumentNullException(nameof(ctx));
                    if(builder == null) throw new ArgumentNullException(nameof(builder));
        
                    var translator = ctx.Translator;
                    QueryModel model = builder.Build();
                    DbQuery dbq = translator.Translate(model);
        
                    ctx.RaiseSqlGenerated(dbq.Sql);
        
                    try
                    {
                        return StreamDynamicInternal(ctx, dbq, ct);
                    }
                    catch(Exception ex)
                    {
                        ctx.RaiseError(dbq.Sql, ex);
                        throw;
                    }
                }
                private async IAsyncEnumerable<DynamicRow> StreamDynamicInternal(QueryExecutionContext ctx, DbQuery dbq, [System.Runtime.CompilerServices.EnumeratorCancellation] CancellationToken ct)
                {
                    DbConnection conn = null;
                    DbCommand cmd = null;
                    DbDataReader reader = null;
        
                    try
                    {
                        conn = await ctx.ConnectionFactory.Create().ConfigureAwait(false);
                        try { await conn.OpenAsync(ct).ConfigureAwait(false); }
                        catch(NotSupportedException) { conn.Open(); }
        
                        cmd = conn.CreateCommand();
                        cmd.CommandText = dbq.Sql;
                        ApplyParameters(cmd, dbq.Parameters);
        
                        reader = await ExecuteReaderSafeAsync(cmd, ct).ConfigureAwait(false);
                        var schema = ExtractSchema(reader);
        
                        if(schema.Columns.Count == 0)
                            yield break;
        
                        Type ilType = RuntimeTypeFactory.GetOrCreate(schema);
        
                        while(await ReadSafeAsync(reader, ct).ConfigureAwait(false))
                        {
                            ct.ThrowIfCancellationRequested();
        
                            object inst = Activator.CreateInstance(ilType);
                            FillDynamicObject(inst, ilType, schema, reader);
        
                            yield return new DynamicRow(inst);
                        }
        
                        ctx.RaiseSuccess(dbq.Sql);
                    }
                    finally
                    {
                        if(reader != null) reader.Dispose();
                        if(cmd != null) cmd.Dispose();
                        if(conn != null) conn.Dispose();
                    }
                }
                
                #endregion DataStreaming
        
                #endregion
            }
        }
    #endregion

    #region File: DatabaseGateway.Helpers.cs
        #nullable enable
        using System;
        using System.Collections.Generic;
        using System.Data;
        using System.Data.Common;
        using System.Linq;
        using System.Text;
        using System.Threading.Tasks;

public static class DbDataReaderExtensions
            {

public static bool HasColumn(this IDataRecord Reader, string ColumnName)
                {
                    if(Reader == null) throw new ArgumentNullException(nameof(Reader));
                    if(string.IsNullOrEmpty(ColumnName)) return false;
        
                    int fieldCount = Reader.FieldCount;
                    for(int i = 0; i < fieldCount; i++)
                    {
                        string name = Reader.GetName(i);
                        if(string.Equals(name, ColumnName, StringComparison.OrdinalIgnoreCase))
                            return true;
                    
                    return false;
                }
            }
        
            public partial class DatabaseGateway
            {
                #region Schema helpers

private sealed class SchemaInfo
                {
                    public List<string> Columns { get; private set; }
                    public Dictionary<string, Type> ColumnTypes { get; private set; }
        
                    public SchemaInfo()
                    {
                        Columns = new List<string>();
                        ColumnTypes = new Dictionary<string, Type>(StringComparer.OrdinalIgnoreCase);
                    }
                }
        
                private static SchemaInfo ExtractSchema(DbDataReader Reader)
                {
                    SchemaInfo result = new SchemaInfo();
                    DataTable dt = Reader.GetSchemaTable();
                    if(dt == null) return result;
        
                    foreach(DataRow row in dt.Rows)
                    {
                        string name = row["ColumnName"] != null
                            ? row["ColumnName"].ToString() ?? ("Col" + result.Columns.Count)
                            : "Col" + result.Columns.Count;
        
                        Type type = row["DataType"] as Type ?? typeof(string);
        
                        result.Columns.Add(name);
                        if(!result.ColumnTypes.ContainsKey(name))
                            result.ColumnTypes[name] = type;
                    }
        
                    return result;
                }
        
                #endregion
            }

}
    #endregion

    #region File: DatabaseGateway.raw_dto.cs
        #nullable enable
        using NekoDatabaseGatewayModern.Mapping;
        using NekoDatabaseGatewayModern.Query;
        using System;
        using System.Collections.Generic;
        using System.Data.Common;
        using System.Globalization;
        using System.Reflection;
        using System.Threading;
        using System.Threading.Tasks;

public partial class DatabaseGateway
            {
                #region Raw API (RecordItem)
        
                public async Task<bool> ContainsData(QueryExecutionContext ctx,string Sql,CancellationToken Ct = default)
                {
                    bool has = await WithCommandAsync(ctx,Sql, async delegate (DbCommand cmd)
                    {
                        using(DbDataReader reader = await ExecuteReaderSafeAsync(cmd, Ct).ConfigureAwait(false))
                        {
                            bool any = await ReadSafeAsync(reader, Ct).ConfigureAwait(false);
                            return any;
                        
                    }, Ct).ConfigureAwait(false);
        
                    return has;
                }
        
                public Task<List<Dictionary<string, RecordItem>>> GetRaw(QueryExecutionContext ctx,string Sql,CancellationToken Ct = default)
                {
                    return GetRaw(ctx,Sql,null, Ct);
                }
        
                public async Task<List<Dictionary<string, RecordItem>>> GetRaw(QueryExecutionContext ctx,string Sql, Dictionary<string, object?>? Parameters,CancellationToken Ct = default)
                {
                    List<Dictionary<string, RecordItem>> result = await WithCommandAsync(ctx,Sql,Parameters, async delegate (DbCommand cmd)
                    {
                        List<Dictionary<string, RecordItem>> list = new List<Dictionary<string, RecordItem>>();
        
                        using(DbDataReader reader = await ExecuteReaderSafeAsync(cmd, Ct).ConfigureAwait(false))
                        {
                            SchemaInfo schema = ExtractSchema(reader);
        
                            while(await ReadSafeAsync(reader, Ct).ConfigureAwait(false))
                            {
                                Ct.ThrowIfCancellationRequested();
                                Dictionary<string, RecordItem> row = new Dictionary<string, RecordItem>(StringComparer.OrdinalIgnoreCase);
                                foreach(string col in schema.Columns)
                                {
                                    object raw = reader[col];
                                    string strValue = Convert.ToString(raw, CultureInfo.InvariantCulture) ?? string.Empty;
        
                                    RecordItem item = new RecordItem
                                    {
                                        Name = col,
                                        Type = schema.ColumnTypes[col].FullName ?? typeof(string).FullName!,
                                        Value = strValue
                                    };
                                    row[col] = item;
                                }
                                list.Add(row);
                            }
                        }
        
                        return list;
                    }, Ct).ConfigureAwait(false);
        
                    return result;
                }
        
                public Task ReadRaw(QueryExecutionContext ctx,string Sql,Action<Dictionary<string, RecordItem>> Callback,CancellationToken Ct = default)
                {
                    return ReadRaw(ctx,Sql, null, Callback, Ct);
                }
        
                public async Task ReadRaw(QueryExecutionContext ctx,string Sql,Dictionary<string, object?>? Parameters,Action<Dictionary<string, RecordItem>> Callback,CancellationToken Ct = default)
                {
                    if(Callback == null) throw new ArgumentNullException(nameof(Callback));
                    if(ctx == null) throw new ArgumentNullException(nameof(ctx));
        
                    await WithCommandAsync(ctx,Sql, Parameters, async delegate (DbCommand cmd)
                    {
                        using(DbDataReader reader = await ExecuteReaderSafeAsync(cmd, Ct).ConfigureAwait(false))
                        {
                            SchemaInfo schema = ExtractSchema(reader);
        
                            while(await ReadSafeAsync(reader, Ct).ConfigureAwait(false))
                            {
                                Ct.ThrowIfCancellationRequested();
                                Dictionary<string, RecordItem> row = new Dictionary<string, RecordItem>(StringComparer.OrdinalIgnoreCase);
        
                                foreach(string col in schema.Columns)
                                {
                                    object raw = reader[col];
                                    string strValue = Convert.ToString(raw, CultureInfo.InvariantCulture) ?? string.Empty;
        
                                    RecordItem item = new RecordItem
                                    {
                                        Name = col,
                                        Type = schema.ColumnTypes[col].FullName ?? typeof(string).FullName!,
                                        Value = strValue
                                    };
                                    row[col] = item;
                                }
                                try
                                {
                                    Callback(row);
                                }
                                catch(Exception ex) { ctx.RaiseError(Sql, ex); }
                            }
                        }
        
                        return 0;
                    }, Ct).ConfigureAwait(false);
                }
        
                protected async Task<int> Upsert(QueryExecutionContext ctx,string Sql,Dictionary<string, object?>? Parameters,CancellationToken Ct = default)
                {
                    if(string.IsNullOrWhiteSpace(Sql))
                        throw new ArgumentNullException(nameof(Sql));
                    if(ctx == null) throw new ArgumentNullException(nameof(ctx));
        
                    int affected = await WithCommandAsync(ctx,Sql,Parameters, delegate (DbCommand cmd)
                    {
                        try
                        {
                            return ExecuteNonQuerySafeAsync(cmd, Ct);
                        }
                        catch(Exception ex) { ctx.RaiseError(Sql, ex); return Task.FromResult(-1); }

}, Ct).ConfigureAwait(false);
        
                    return affected;
                }
        
                public Task<int> Insert(QueryExecutionContext ctx,string Sql,CancellationToken Ct = default)
                {
                    return Upsert(ctx,Sql,null, Ct);
                }
        
                public Task<int> Insert(QueryExecutionContext ctx,string Sql,Dictionary<string, object?>? Parameters,CancellationToken Ct = default)
                {
                    return Upsert(ctx,Sql,Parameters, Ct);
                }
        
                public Task<int> Update(QueryExecutionContext ctx,string Sql,CancellationToken Ct = default)
                {
                    return Upsert(ctx,Sql, null, Ct);
                }
        
                public Task<int> Update(QueryExecutionContext ctx,string Sql,Dictionary<string, object?>? Parameters,CancellationToken Ct = default)
                {
                    return Upsert(ctx,Sql,Parameters, Ct);
                }
        
                public async Task<List<Dictionary<string, RecordItem>>> GetRaw(QueryExecutionContext ctx,QueryBuilder Builder,CancellationToken Ct = default)
                {
                    if(Builder == null) throw new ArgumentNullException(nameof(Builder));
                    if(ctx == null) throw new ArgumentNullException(nameof(ctx));
        
                    var translator = ctx.Translator;
                    QueryModel model = Builder.Build();
                    DbQuery dbq = translator.Translate(model);
                    ctx.RaiseSqlGenerated(dbq.Sql);
                    List<Dictionary<string, RecordItem>> result = null;
                    try 
                    {
                        ctx.RaiseSqlDispatch(dbq.Sql);
                        result = await GetRaw(ctx, dbq.Sql, dbq.Parameters, Ct).ConfigureAwait(false);
                        ctx.RaiseSuccess(dbq.Sql);
                    }
                    catch(Exception ex) { ctx.RaiseError(dbq.Sql, ex);  }
                    
                    return result;
                }
        
                public async Task ReadRaw(QueryExecutionContext ctx,QueryBuilder Builder ,Action<Dictionary<string, RecordItem>> Callback,CancellationToken Ct = default)
                {
                    if(Builder == null) throw new ArgumentNullException(nameof(Builder));
                    if(Callback == null) throw new ArgumentNullException(nameof(Callback));
                    if(ctx == null) throw new ArgumentNullException(nameof(ctx));
        
                    var translator = ctx.Translator;
                    QueryModel model = Builder.Build();
                    DbQuery dbq = translator.Translate(model);
                    ctx.RaiseSqlGenerated(dbq.Sql);

try
                    {
                        ctx.RaiseSqlDispatch(dbq.Sql);
                        await ReadRaw(ctx, dbq.Sql, dbq.Parameters, Callback, Ct).ConfigureAwait(false);
                        ctx.RaiseSuccess(dbq.Sql);
                    }
                    catch(Exception ex) { ctx.RaiseError(dbq.Sql,ex); }
        
                }
        
                public async Task<int> Insert(QueryExecutionContext ctx,QueryBuilder Builder , CancellationToken Ct = default)
                {
                    if(Builder == null) throw new ArgumentNullException(nameof(Builder));
        
                    var translator = ctx.Translator;
                    QueryModel model = Builder.Build();
                    DbQuery dbq = translator.Translate(model);
                    ctx.RaiseSqlGenerated(dbq.Sql);
        
                    int affected = 0;
                    try
                    {
                        ctx.RaiseSqlDispatch(dbq.Sql);
                         affected = await Insert(ctx, dbq.Sql, dbq.Parameters, Ct).ConfigureAwait(false);
                        ctx.RaiseSuccess(dbq.Sql);
                    }
                    catch(Exception ex) { ctx.RaiseError(dbq.Sql, ex); affected = -1; }
                    
                    return affected;
                }
        
                public async Task<int> Update(QueryExecutionContext ctx,QueryBuilder Builder , CancellationToken Ct = default)
                {
                    if(Builder == null) throw new ArgumentNullException(nameof(Builder));
                    if(ctx == null) throw new ArgumentNullException(nameof(ctx));
        
                    var translator = ctx.Translator;
                    QueryModel model = Builder.Build();
                    DbQuery dbq = translator.Translate(model);
                    ctx.RaiseSqlGenerated(dbq.Sql);
        
                    int affected = 0;
                    try
                    {
                        ctx.RaiseSqlDispatch(dbq.Sql);
                        affected = await Update(ctx, dbq.Sql, dbq.Parameters, Ct).ConfigureAwait(false);
                        ctx.RaiseSuccess(dbq.Sql);
                    }
                    catch(Exception ex) { ctx.RaiseError(dbq.Sql, ex); affected = -1; }
                    return affected;
                }
        
                #endregion
        
                #region DTO API (strong typed, no IL fallback)
        
                public async Task<List<T>> GetDto<T>(QueryExecutionContext ctx,QueryBuilder Builder , CancellationToken Ct = default) where T : new()
                {
                    if(Builder == null) throw new ArgumentNullException(nameof(Builder));
                    if(ctx == null) throw new ArgumentNullException(nameof(ctx));
                    
                    QueryModel model = Builder.Build();
                    DbQuery dbq = ctx.Translator.Translate(model);
                    ctx.RaiseSqlGenerated(dbq.Sql);
        
                    List<T> list = new List<T>();
        
                    await WithCommandAsync(ctx,dbq.Sql,dbq.Parameters, async delegate (DbCommand cmd)
                    {
                        using(DbDataReader reader = await ExecuteReaderSafeAsync(cmd, Ct).ConfigureAwait(false))
                        {
                            Type type = typeof(T);
                            PropertyInfo[] props = type.GetProperties(BindingFlags.Public | BindingFlags.Instance);
        
                            while(await ReadSafeAsync(reader, Ct).ConfigureAwait(false))
                            {
                                Ct.ThrowIfCancellationRequested();
                                T inst = new T();
                                for(int i = 0; i < props.Length; i++)
                                {
                                    PropertyInfo p = props[i];
                                    if(!reader.HasColumn(p.Name))
                                        continue;
        
                                    object val = reader[p.Name];
                                    if(val is DBNull) continue;
        
                                    try
                                    {
                                        object converted = Convert.ChangeType(val, p.PropertyType, CultureInfo.InvariantCulture);
                                        p.SetValue(inst, converted, null);
                                    }
                                    catch
                                    {
                                    }
                                }
                                list.Add(inst);
                            }
                        }
        
                        return 0;
                    }, Ct).ConfigureAwait(false);
        
                    return list;
                }
        
                public async Task ReadDto<T>(QueryExecutionContext ctx,QueryBuilder Builder , Action<T> Callback,CancellationToken Ct = default)where T : new()
                {
                    if(Builder == null) throw new ArgumentNullException(nameof(Builder));
                    if(Callback == null) throw new ArgumentNullException(nameof(Callback));
                    if(ctx == null) throw new ArgumentNullException(nameof(ctx));

QueryModel model = Builder.Build();
                    DbQuery dbq = ctx.Translator.Translate(model);
        
                    await WithCommandAsync(ctx,dbq.Sql, dbq.Parameters, async delegate (DbCommand cmd)
                    {
                        using(DbDataReader reader = await ExecuteReaderSafeAsync(cmd, Ct).ConfigureAwait(false))
                        {
                            Type type = typeof(T);
                            PropertyInfo[] props = type.GetProperties(BindingFlags.Public | BindingFlags.Instance);
        
                            while(await ReadSafeAsync(reader, Ct).ConfigureAwait(false))
                            {
                                Ct.ThrowIfCancellationRequested();
                                T inst = new T();
                                for(int i = 0; i < props.Length; i++)
                                {
                                    PropertyInfo p = props[i];
                                    if(!reader.HasColumn(p.Name))
                                        continue;
        
                                    object val = reader[p.Name];
                                    if(val is DBNull) continue;
        
                                    try
                                    {
                                        object converted = Convert.ChangeType(val, p.PropertyType, CultureInfo.InvariantCulture);
                                        p.SetValue(inst, converted, null);
                                    }
                                    catch
                                    {
                                    }
                                }
        
                                Callback(inst);
                            }
                        }
        
                        return 0;
                    }, Ct).ConfigureAwait(false);
                }
        
                #endregion
        
                #region DataStreaming

public IAsyncEnumerable<T> StreamDto<T>(QueryExecutionContext ctx, QueryBuilder builder, CancellationToken ct = default) where T : new()
                {
                    if(ctx == null) throw new ArgumentNullException(nameof(ctx));
                    if(builder == null) throw new ArgumentNullException(nameof(builder));
        
                    QueryModel model = builder.Build();
                    DbQuery dbq = ctx.Translator.Translate(model);
        
                    ctx.RaiseSqlGenerated(dbq.Sql);
        
                    try
                    {
                        return StreamDtoCore<T>(ctx, dbq, ct);
                    }
                    catch(Exception ex)
                    {
                        ctx.RaiseError(dbq.Sql, ex);
                        throw;
                    }
                }
        
                private async IAsyncEnumerable<T> StreamDtoCore<T>(QueryExecutionContext ctx, DbQuery dbq, [System.Runtime.CompilerServices.EnumeratorCancellation] CancellationToken ct) where T : new()
                {
                    DbConnection conn = null;
                    DbCommand cmd = null;
                    DbDataReader reader = null;
        
                    try
                    {
                        conn = await ctx.ConnectionFactory.Create().ConfigureAwait(false);
                        try { await conn.OpenAsync(ct).ConfigureAwait(false); }
                        catch(NotSupportedException) { conn.Open(); }
        
                        cmd = conn.CreateCommand();
                        cmd.CommandText = dbq.Sql;
                        ApplyParameters(cmd, dbq.Parameters);
        
                        reader = await ExecuteReaderSafeAsync(cmd, ct).ConfigureAwait(false);
                        var schema = ExtractSchema(reader);
        
                        while(await ReadSafeAsync(reader, ct).ConfigureAwait(false))
                        {
                            ct.ThrowIfCancellationRequested();
        
                            var record = new Dictionary<string, RecordItem>(StringComparer.OrdinalIgnoreCase);
        
                            foreach(string col in schema.Columns)
                            {
                                record[col] = new RecordItem
                                {
                                    Name = col,
                                    Type = schema.ColumnTypes[col]?.FullName,
                                    Value = Convert.ToString(reader[col], CultureInfo.InvariantCulture)
                                };
                            }
        
                            yield return DataMapper.Map<T>(record);
                        }
        
                        ctx.RaiseSuccess(dbq.Sql);
                    }
                    finally
                    {
                        if(reader != null) reader.Dispose();
                        if(cmd != null) cmd.Dispose();
                        if(conn != null) conn.Dispose();
                    }
                }

#endregion DataStreaming
            }
        }
    #endregion

    #region File: DatabaseGateway.Universal.cs
        #nullable enable
        using NekoDatabaseGatewayModern.Mapping;
        using NekoDatabaseGatewayModern.Query;
        using System;
        using System.Collections.Generic;
        using System.Data.Common;
        using System.Globalization;
        using System.Linq;
        using System.Reflection;
        using System.Runtime.CompilerServices;
        using System.Threading;
        using System.Threading.Tasks;

public partial class DatabaseGateway
            {
                #region Universal GET (DTO → fallback Dynamic)
        
                public async Task<List<T>> Get<TTranslator, T>(QueryExecutionContext ctx, QueryBuilder Builder, CancellationToken Ct = default) where TTranslator : IDbQueryTranslator, new() where T : new()
                {
                    if(Builder == null) throw new ArgumentNullException(nameof(Builder));
                    if(ctx == null) throw new ArgumentNullException(nameof(ctx));
        
                    Type targetType = typeof(T);
        
                    if(targetType == typeof(DynamicRow) || targetType == typeof(object))
                    {
                        List<DynamicRow> dynRows = await GetDynamic(ctx, Builder, Ct).ConfigureAwait(false);
                        List<T> castResult = dynRows.Cast<T>().ToList();
                        return castResult;
                    
                    if(targetType.GetConstructor(Type.EmptyTypes) != null)
                    {
                        try
                        {
                            List<T> dtoResult = await GetDto<T>(ctx, Builder, Ct).ConfigureAwait(false);
                            return dtoResult;
                        }
                        catch
                        {
                        }
                    }
        
                    List<DynamicRow> dynFallback = await GetDynamic(ctx, Builder, Ct).ConfigureAwait(false);
                    List<T> fallbackCast = dynFallback.Cast<T>().ToList();
                    return fallbackCast;
                }
        
                #endregion
        
                #region Universal READ (no <T> required + typed overload)

public Task Read(QueryExecutionContext ctx,QueryBuilder builder,Delegate handler,CancellationToken ct = default)
                {
                    if(builder == null) throw new ArgumentNullException(nameof(builder));
                    if(ctx == null) throw new ArgumentNullException(nameof(ctx));
                    if(handler == null) throw new ArgumentNullException(nameof(handler));
        
                    return ReadUniversalDispatch(ctx, builder, handler, ct);
                }

public Task Read<T>(QueryExecutionContext ctx,QueryBuilder builder,Action<T> callback,CancellationToken ct = default)
                {
                    if(callback == null) throw new ArgumentNullException(nameof(callback));
                    if(ctx == null) throw new ArgumentNullException(nameof(ctx));
        
                    return Read(ctx, builder, (Delegate)callback, ct);
                }
        
                private async Task ReadUniversalDispatch(QueryExecutionContext ctx,QueryBuilder builder,Delegate handler,CancellationToken ct)
                {
                    ParameterInfo[] pars = handler.Method.GetParameters();
                    if(pars.Length != 1)
                        throw new InvalidOperationException(
                            "The handler must have exactly one parameter.");
        
                    Type targetType = pars[0].ParameterType;
                    QueryModel model = builder.Build();
                    DbQuery dbq = ctx.Translator.Translate(model);
                    ctx.RaiseSqlGenerated(dbq.Sql);
        
                    try
                    {
                        await WithCommandAsync(ctx, dbq.Sql, dbq.Parameters, async cmd => {
                            using(DbDataReader reader = await ExecuteReaderSafeAsync(cmd, ct))
                            {
                                SchemaInfo schema = ExtractSchema(reader);
        
                                bool wantsDynamic = targetType == typeof(DynamicRow) || targetType == typeof(object);
                                bool wantsDto = !wantsDynamic && targetType.GetConstructor(Type.EmptyTypes) != null;
        
                                Type ilType = wantsDynamic ? RuntimeTypeFactory.GetOrCreate(schema) : null;
        
                                while(await ReadSafeAsync(reader, ct))
                                {
                                    ct.ThrowIfCancellationRequested();
        
                                    if(wantsDto)
                                    {

var record = new Dictionary<string, RecordItem>(StringComparer.OrdinalIgnoreCase);                               
                                        foreach(var col in schema.Columns)

record[col] = new RecordItem
                                            {
                                                Name = col,
                                                Type = schema.ColumnTypes[col].FullName,
                                                Value = Convert.ToString(reader[col], CultureInfo.InvariantCulture)
                                            };

object dto = DataMapper.Map(record, targetType);
                                        handler.DynamicInvoke(dto);
                                        continue;
                                    }
                                    
                                    if(ilType == null)
                                        ilType = RuntimeTypeFactory.GetOrCreate(schema);

object inst = Activator.CreateInstance(ilType);
                                    FillDynamicObject(inst, ilType, schema, reader);

try
                                    {
                                        handler.DynamicInvoke((object)new DynamicRow(inst));
                                    }
                                    catch { }
                                }
                            }
        
                            return 0;
                        }, ct);

}
                    catch(Exception ex)
                    {
                        ctx.RaiseError(dbq.Sql, ex);
                        throw;
                    }
                }

#region DataStreaming
                public IAsyncEnumerable<dynamic> StreamData(QueryExecutionContext ctx, QueryBuilder builder, CancellationToken ct = default)
                {
                    if(ctx == null) throw new ArgumentNullException(nameof(ctx));
                    if(builder == null) throw new ArgumentNullException(nameof(builder));
        
                    QueryModel model = builder.Build();
                    DbQuery dbq = ctx.Translator.Translate(model);
        
                    ctx.RaiseSqlGenerated(dbq.Sql);
        
                    try
                    {
                        return StreamDataCore<dynamic>(ctx, dbq, ct);
                    }
                    catch(Exception ex)
                    {
                        ctx.RaiseError(dbq.Sql, ex);
                        throw;
                    }
                }
        
                public IAsyncEnumerable<T> StreamData<T>(QueryExecutionContext ctx, QueryBuilder builder, CancellationToken ct = default)
                {
                    if(ctx == null) throw new ArgumentNullException(nameof(ctx));
                    if(builder == null) throw new ArgumentNullException(nameof(builder));
        
                    QueryModel model = builder.Build();
                    DbQuery dbq = ctx.Translator.Translate(model);
        
                    ctx.RaiseSqlGenerated(dbq.Sql);
        
                    try
                    {
                        return StreamDataCore<T>(ctx, dbq, ct);
                    }
                    catch(Exception ex)
                    {
                        ctx.RaiseError(dbq.Sql, ex);
                        throw;
                    }
                }
        
                private async IAsyncEnumerable<T> StreamDataCore<T>(QueryExecutionContext ctx, DbQuery dbq,[EnumeratorCancellation] CancellationToken ct)
                {
                    DbConnection conn = null;
                    DbCommand cmd = null;
                    DbDataReader reader = null;
        
                    try
                    {
                        conn = await ctx.ConnectionFactory.Create().ConfigureAwait(false);
                        try { await conn.OpenAsync(ct).ConfigureAwait(false); }
                        catch(NotSupportedException) { conn.Open(); }
        
                        cmd = conn.CreateCommand();
                        cmd.CommandText = dbq.Sql;
                        ApplyParameters(cmd, dbq.Parameters);
        
                        reader = await ExecuteReaderSafeAsync(cmd, ct).ConfigureAwait(false);
                        var schema = ExtractSchema(reader);
        
                        bool wantsDynamic =
                            typeof(T) == typeof(object) ||
                            typeof(T) == typeof(DynamicRow);
        
                        bool wantsDto =
                            !wantsDynamic &&
                            typeof(T).GetConstructor(Type.EmptyTypes) != null;
        
                        Type ilType = null;
                        if(wantsDynamic || !wantsDto)
                            ilType = RuntimeTypeFactory.GetOrCreate(schema);
        
                        while(await ReadSafeAsync(reader, ct).ConfigureAwait(false))
                        {
                            ct.ThrowIfCancellationRequested();
        
                            if(wantsDto)
                            {
                                var record = new Dictionary<string, RecordItem>(StringComparer.OrdinalIgnoreCase);
        
                                foreach(string col in schema.Columns)
                                {
                                    record[col] = new RecordItem
                                    {
                                        Name = col,
                                        Type = schema.ColumnTypes[col]?.FullName,
                                        Value = Convert.ToString(reader[col], CultureInfo.InvariantCulture)
                                    };
                                }
        
                                yield return (T)DataMapper.Map(record, typeof(T));
                            }
                            else
                            {
                                object inst = Activator.CreateInstance(ilType);
                                FillDynamicObject(inst, ilType, schema, reader);
        
                                yield return (T)(object)new DynamicRow(inst);
                            }
                        }
        
                        ctx.RaiseSuccess(dbq.Sql);
                    }
                    finally
                    {
                        if(reader != null) reader.Dispose();
                        if(cmd != null) cmd.Dispose();
                        if(conn != null) conn.Dispose();
                    }
                }

private async IAsyncEnumerable<object> StreamDataCore<T>(QueryExecutionContext ctx, DbQuery dbq, Type targetType, [System.Runtime.CompilerServices.EnumeratorCancellation] CancellationToken ct)
                {
                    DbConnection conn = null;
                    DbCommand cmd = null;
                    DbDataReader reader = null;
        
                    try
                    {
                        conn = await ctx.ConnectionFactory.Create().ConfigureAwait(false);
                        try { await conn.OpenAsync(ct).ConfigureAwait(false); }
                        catch(NotSupportedException) { conn.Open(); }
        
                        cmd = conn.CreateCommand();
                        cmd.CommandText = dbq.Sql;
                        ApplyParameters(cmd, dbq.Parameters);
        
                        reader = await ExecuteReaderSafeAsync(cmd, ct).ConfigureAwait(false);
                        var schema = ExtractSchema(reader);
        
                        bool wantsDynamic = targetType == typeof(DynamicRow) || targetType == typeof(object);
                        bool wantsDto = !wantsDynamic && targetType.GetConstructor(Type.EmptyTypes) != null;
        
                        Type ilType = null;
                        if(wantsDynamic || !wantsDto)
                            ilType = RuntimeTypeFactory.GetOrCreate(schema);
        
                        while(await ReadSafeAsync(reader, ct).ConfigureAwait(false))
                        {
                            ct.ThrowIfCancellationRequested();
        
                            if(wantsDto)
                            {
                                var record = new Dictionary<string, RecordItem>(StringComparer.OrdinalIgnoreCase);
        
                                foreach(string col in schema.Columns)
                                {
                                    record[col] = new RecordItem
                                    {
                                        Name = col,
                                        Type = schema.ColumnTypes[col]?.FullName,
                                        Value = Convert.ToString(reader[col], CultureInfo.InvariantCulture)
                                    };
                                }
        
                                yield return DataMapper.Map(record, targetType);
                            }
                            else
                            {
                                object inst = Activator.CreateInstance(ilType);
                                FillDynamicObject(inst, ilType, schema, reader);
                                yield return new DynamicRow(inst);
                            }
                        }
        
                        ctx.RaiseSuccess(dbq.Sql);
                    }
                    finally
                    {
                        if(reader != null) reader.Dispose();
                        if(cmd != null) cmd.Dispose();
                        if(conn != null) conn.Dispose();
                    }
                }

#endregion
                #endregion
            }
        }
    #endregion

#endregion

#region Folder: Dynamic
    #region File: Dynamic\DynamicRow.cs
        #nullable enable
        using NekoDatabaseGatewayModern.Dynamic;
        using System;
        using System.Collections.Generic;
        using System.Dynamic;
        using System.Linq;
        using System.Reflection;
        using System.Text;
        using System.Threading.Tasks;

public sealed class DynamicRow : DynamicObject
            {
                private readonly object _instance;
                private readonly Dictionary<string, PropertyInfo> _props;

public DynamicRow(object instance)
                {
                    if(instance == null) throw new ArgumentNullException(nameof(instance));
                    _instance = instance;
        
                    PropertyInfo[] properties = instance
                        .GetType()
                        .GetProperties(BindingFlags.Public | BindingFlags.Instance);
        
                    _props = new Dictionary<string, PropertyInfo>(properties.Length, StringComparer.OrdinalIgnoreCase);
                    for(int i = 0; i < properties.Length; i++)
                    {
                        PropertyInfo p = properties[i];
                        string key = p.Name.ToLowerInvariant();
                        _props[key] = p;
                    
                }

public object? this[string name]
                {
                    get { return Get(name); }
                    set { Set(name, value); }
                }
        
                private object? Get(string name)
                {
                    if(string.IsNullOrEmpty(name)) return null;
                    string key = name.ToLowerInvariant();
                    PropertyInfo pi;
                    if(_props.TryGetValue(key, out pi))
                        return pi.GetValue(_instance, null);
                    return null;
                }
        
                private void Set(string name, object value)
                {
                    if(string.IsNullOrEmpty(name)) return;
                    string key = name.ToLowerInvariant();
                    PropertyInfo pi;
                    if(_props.TryGetValue(key, out pi) && pi.CanWrite)
                        pi.SetValue(_instance, value, null);
                }
        
                public override bool TryGetMember(GetMemberBinder binder, out object? result)
                {
                    result = Get(binder.Name);
                    return true;
                }
        
                public override bool TrySetMember(SetMemberBinder binder, object? value)
                {
                    Set(binder.Name, value);
                    return true;
                }
        
                public override bool TryGetIndex(GetIndexBinder binder, object[] indexes, out object? result)
                {
                    if(indexes != null && indexes.Length == 1 && indexes[0] is string)
                    {
                        string name = (string)indexes[0];
                        result = Get(name);
                        return true;
                    }
        
                    result = null;
                    return false;
                }
        
                public override bool TrySetIndex(SetIndexBinder binder, object[] indexes, object? value)
                {
                    if(indexes != null && indexes.Length == 1 && indexes[0] is string)
                    {
                        string name = (string)indexes[0];
                        Set(name, value);
                        return true;
                    }
        
                    return false;
                }
            }
        }
    #endregion

    #region File: Dynamic\RuntimeTypeFactory.cs
        #nullable enable
        using NekoDatabaseGatewayModern.Dynamic;
        using System;
        using System.Collections.Generic;
        using System.Data;
        using System.Data.Common;
        using System.Linq;
        using System.Reflection;
        using System.Reflection.Emit;
        using System.Text;
        using System.Threading;
        using System.Threading.Tasks;

public static class RuntimeTypeFactory
            {

public sealed class SchemaInfo
                {
                    public List<string> Columns { get; private set; 
                    public Dictionary<string, Type> ColumnTypes { get; private set; }
        
                    public SchemaInfo()
                    {
                        Columns = new List<string>();
                        ColumnTypes = new Dictionary<string, Type>(StringComparer.OrdinalIgnoreCase);
                    }
                }

public static SchemaInfo ExtractSchema(DbDataReader reader)
                {
                    SchemaInfo result = new SchemaInfo();
                    DataTable dt = reader.GetSchemaTable();
                    if(dt == null) return result;
        
                    foreach(DataRow row in dt.Rows)
                    {
                        string name = row["ColumnName"] != null ? row["ColumnName"].ToString() : "Col" + result.Columns.Count;
                        Type type = row["DataType"] as Type ?? typeof(string);
        
                        result.Columns.Add(name);
                        if(!result.ColumnTypes.ContainsKey(name))                
                            result.ColumnTypes[name] = type;
                        
                    }
        
                    return result;
                }
                private static readonly AssemblyName _assemblyName = new AssemblyName("DynamicRowTypesAsm");
                private static readonly ModuleBuilder _module;
                private static readonly Dictionary<string, Type> _cache = new Dictionary<string, Type>(StringComparer.Ordinal);
                private static readonly LinkedList<string> _lru = new LinkedList<string>();
                private const int MaxTypes = 256;
                private static int _typeCounter;
                private static readonly object _sync = new object();
        
                static RuntimeTypeFactory()
                {
                    AssemblyBuilder ab = AssemblyBuilder.DefineDynamicAssembly(_assemblyName, AssemblyBuilderAccess.Run);
                    _module = ab.DefineDynamicModule("MainModule");
                }

public static Type GetOrCreate(SchemaInfo schema)
                {
                    if(schema == null) throw new ArgumentNullException(nameof(schema));
        
                    string sig = BuildSignature(schema);
        
                    lock(_sync)
                    {
                        Type t;
                        if(_cache.TryGetValue(sig, out t))
                        {
                            MoveToTail(sig);
                            return t;
                        }
        
                        Type created = CreateType(schema);
                        _cache[sig] = created;
                        _lru.AddLast(sig);
                        EnforceCapacity();
                        return created;
                    }
                }
        
                private static string BuildSignature(SchemaInfo schema)
                {
                    StringBuilder sb = new StringBuilder();
        
                    List<string> ordered = schema.Columns.OrderBy(c => c, StringComparer.OrdinalIgnoreCase)
                                                         .ToList();
        
                    for(int i = 0; i < ordered.Count; i++)
                    {
                        string col = ordered[i];
                        Type t;
                        if(!schema.ColumnTypes.TryGetValue(col, out t) || t == null)
                            t = typeof(string);
        
                        sb.Append(col.ToLowerInvariant());
                        sb.Append(':');
                        sb.Append(t.FullName);
                        sb.Append('|');
                    }
        
                    return sb.ToString();
                }
        
                private static Type CreateType(SchemaInfo schema)
                {
                    string typeName = "DynamicRowType_" + Interlocked.Increment(ref _typeCounter);
                    TypeBuilder tb = _module.DefineType(typeName, TypeAttributes.Public | TypeAttributes.Class);
        
                    for(int i = 0; i < schema.Columns.Count; i++)
                    {
                        string propName = schema.Columns[i];
                        Type propType;
                        if(!schema.ColumnTypes.TryGetValue(propName, out propType) || propType == null)
                            propType = typeof(string);
        
                        FieldBuilder field = tb.DefineField("_" + propName, propType, FieldAttributes.Private);
                        PropertyBuilder prop = tb.DefineProperty(propName, PropertyAttributes.HasDefault, propType, null);

MethodBuilder getter = tb.DefineMethod(
                            "get_" + propName,
                            MethodAttributes.Public | MethodAttributes.SpecialName | MethodAttributes.HideBySig,
                            propType,
                            Type.EmptyTypes);
        
                        ILGenerator ilGet = getter.GetILGenerator();
                        ilGet.Emit(OpCodes.Ldarg_0);
                        ilGet.Emit(OpCodes.Ldfld, field);
                        ilGet.Emit(OpCodes.Ret);

MethodBuilder setter = tb.DefineMethod($"set_{propName}",
                            MethodAttributes.Public | MethodAttributes.SpecialName | MethodAttributes.HideBySig,
                            null,
                            new Type[] { propType });
        
                        ILGenerator ilSet = setter.GetILGenerator();
                        ilSet.Emit(OpCodes.Ldarg_0);
                        ilSet.Emit(OpCodes.Ldarg_1);
                        ilSet.Emit(OpCodes.Stfld, field);
                        ilSet.Emit(OpCodes.Ret);
        
                        prop.SetGetMethod(getter);
                        prop.SetSetMethod(setter);
                    }
        
                    Type createdType = tb.CreateType();
                    return createdType;
                }
        
                private static void MoveToTail(string key)
                {
                    LinkedListNode<string> node = _lru.Find(key);
                    if(node != null)
                    {
                        _lru.Remove(node);
                        _lru.AddLast(node);
                    }
                }
        
                private static void EnforceCapacity()
                {
                    while(_lru.Count > MaxTypes)
                    {
                        LinkedListNode<string> first = _lru.First;
                        if(first == null) break;
        
                        string key = first.Value;
                        _lru.RemoveFirst();
                        _cache.Remove(key);
                    }
                }
            }
        }
    #endregion

#endregion

#region Folder: Mapping
    #region File: Mapping\DataMapper.cs
        #nullable enable
        using NekoDatabaseGatewayModern.Mapping;
        using System;
        using System.Collections.Generic;
        using System.Globalization;
        using System.Linq;
        using System.Reflection;

public static class DataMapper
            {
                private static readonly Dictionary<Type, PropertyInfo[]> _cache = new();
        
                public static T Map<T>(Dictionary<string, RecordItem> Row) where T : new()
                {
                    if(Row == null) throw new ArgumentNullException(nameof(Row));
        
                    T obj = new T();
                    Type type = typeof(T);
        
                    PropertyInfo[] props;
                    if(!_cache.TryGetValue(type, out props))
                    {
                        props = type.GetProperties(BindingFlags.Public | BindingFlags.Instance)
                                    .Where(p => p.CanWrite)
                                    .ToArray();
        
                        _cache[type] = props;
                    
                    foreach(PropertyInfo prop in props)
                    {
                        KeyValuePair<string, RecordItem> kv = Row.FirstOrDefault(r =>string.Equals(r.Key, prop.Name, StringComparison.OrdinalIgnoreCase));
        
                        if(kv.Key == null)
                            continue;
        
                        RecordItem record = kv.Value;
                        object? converted = ConvertValue(record, prop.PropertyType);
        
                        try
                        {
                            prop.SetValue(obj, converted, null);
                        }
                        catch {  }
                    }
        
                    return obj;
                }
        
                public static object Map(Dictionary<string, RecordItem> row,Type targetType)
                {
                    if(row == null)
                        throw new ArgumentNullException(nameof(row));
                    if(targetType == null)
                        throw new ArgumentNullException(nameof(targetType));
        
                    ConstructorInfo ctor = targetType.GetConstructor(Type.EmptyTypes);
                    if(ctor == null)
                        throw new InvalidOperationException($"Type '{targetType.FullName}' must have a parameterless constructor.");
        
                    object instance = ctor.Invoke(null);
                    MapInto(instance, row);
                    return instance;
                }
                private static void MapInto(object instance,Dictionary<string, RecordItem> row)
                {
                    Type type = instance.GetType();
                    PropertyInfo[] props = type
                        .GetProperties(BindingFlags.Public | BindingFlags.Instance)
                        .Where(p => p.CanWrite)
                        .ToArray();
        
                    for(int i = 0; i < props.Length; i++)
                    {
                        PropertyInfo prop = props[i];
        
                        KeyValuePair<string, RecordItem> kv = row.FirstOrDefault(r =>string.Equals(r.Key, prop.Name,StringComparison.OrdinalIgnoreCase));
        
                        if(kv.Key == null)
                            continue;
        
                        RecordItem record = kv.Value;
        
                        try
                        {
                            object? converted = ConvertValue(record, prop.PropertyType);
                            prop.SetValue(instance, converted, null);
                        }
                        catch {  }
                    }
                }
        
                private static object? ConvertValue(RecordItem Record, Type Target)
                {
                    if(Target == typeof(string)) return Record.As<string>();
        
                    if(Target == typeof(int) || Target == typeof(int?))
                        return Record.As<int>();
        
                    if(Target == typeof(long) || Target == typeof(long?))
                        return Record.As<long>();
        
                    if(Target == typeof(double) || Target == typeof(double?))
                        return Record.As<double>();
        
                    if(Target == typeof(decimal) || Target == typeof(decimal?))
                    {
                        decimal d;
                        if(decimal.TryParse(Record.Value, NumberStyles.Any, CultureInfo.InvariantCulture, out d))
                            return d;
                        return default(decimal);
                    }
        
                    if(Target == typeof(bool) || Target == typeof(bool?))
                        return Record.As<bool>();
        
                    if(Target == typeof(DateTime) || Target == typeof(DateTime?))
                        return Record.As<DateTime>();
        
                    try
                    {
                        return Convert.ChangeType(Record.Value, Target, CultureInfo.InvariantCulture);
                    }
                    catch { return null; }
                     
                }
            }
        }
    #endregion

    #region File: Mapping\RecordItem.cs
        #nullable enable
        using NekoDatabaseGatewayModern.Mapping;
        using System;
        using System.Globalization;
        using System.Text;

public class RecordItem
            {
                public string Type = string.Empty;
                public string Name = string.Empty;
                public string Value = string.Empty;
        
                public RecordItem() { 
                public RecordItem(int V)
                {
                    Type = typeof(int).FullName;
                    Value = V.ToString(CultureInfo.InvariantCulture);
                }
        
                public RecordItem(string V)
                {
                    Type = typeof(string).FullName;
                    Value = V;
                }
        
                public RecordItem(double V)
                {
                    Type = typeof(double).FullName;
                    Value = V.ToString(CultureInfo.InvariantCulture);
                }
        
                public T As<T>(T DefaultValue = default)
                {
                    if(string.IsNullOrWhiteSpace(Value))
                        return DefaultValue;
        
                    try
                    {
                        Type target = typeof(T);
        
                        if(target == typeof(string))
                            return (T)(object)Value;
        
                        if(target == typeof(int) || target == typeof(int?))
                        {
                            int i;
                            if(int.TryParse(Value, NumberStyles.Any, CultureInfo.InvariantCulture, out i))
                                return (T)(object)i;
                            return DefaultValue;
                        }
        
                        if(target == typeof(long) || target == typeof(long?))
                        {
                            long i;
                            if(long.TryParse(Value, NumberStyles.Any, CultureInfo.InvariantCulture, out i))
                                return (T)(object)i;
                            return DefaultValue;
                        }
        
                        if(target == typeof(double) || target == typeof(double?))
                        {
                            double d;
                            if(double.TryParse(Value, NumberStyles.Any, CultureInfo.InvariantCulture, out d))
                                return (T)(object)d;
                            return DefaultValue;
                        }
        
                        if(target == typeof(DateTime) || target == typeof(DateTime?))
                        {
                            DateTime dt;
                            if(DateTime.TryParse(Value, CultureInfo.InvariantCulture, DateTimeStyles.None, out dt))
                                return (T)(object)dt;
                            return DefaultValue;
                        }
        
                        if(target == typeof(bool) || target == typeof(bool?))
                        {
                            bool b;
                            if(bool.TryParse(Value, out b))
                                return (T)(object)b;
        
                            if(Value == "0") return (T)(object)false;
                            if(Value == "1") return (T)(object)true;
                            return DefaultValue;
                        }
        
                        try
                        {
                            return (T)Convert.ChangeType(Value, typeof(T), CultureInfo.InvariantCulture);
                        }
                        catch
                        {
                            return DefaultValue;
                        }
                    }
                    catch
                    {
                        return DefaultValue;
                    }
                }
        
                public override string ToString()
                {
                    return Value ?? string.Empty;
                }
        
                public string ToString(string Format, IFormatProvider FormatProvider)
                {
                    if(string.IsNullOrEmpty(Format))
                        return ToString();
        
                    if(string.Equals(Format, "tnv", StringComparison.Ordinal))
                        return "[type: " + Type + ", name: " + Name + ", value: " + Value + "]";
                    if(string.Equals(Format, "nv", StringComparison.Ordinal))
                        return "[name: " + Name + ", value: " + Value + "]";
        
                    StringBuilder sb = new StringBuilder();
                    sb.Append('[');
        
                    for(int i = 0; i < Format.Length; i++)
                    {
                        char c = Format[i];
                        switch(c)
                        {
                            case 't': sb.Append(Type); break;
                            case 'n': sb.Append(Name); break;
                            case 'v': sb.Append(Value); break;
        
                            case 'T': sb.Append("Type: ").Append(Type); break;
                            case 'N': sb.Append("Name: ").Append(Name); break;
                            case 'V': sb.Append("Value: ").Append(Value); break;
        
                            case ',': sb.Append(", "); break;
                            case ' ': sb.Append(' '); break;
        
                            case '[':
                            case ']':
                                sb.Append(c);
                                break;
        
                            default:
                                sb.Append(c);
                                break;
                        }
                    }
        
                    sb.Append(']');
                    return sb.ToString();
                }
        
                public static explicit operator int(RecordItem Item)
                {
                    return Item.As<int>();
                }
        
                public static explicit operator double(RecordItem Item)
                {
                    return Item.As<double>();
                }
        
                public static implicit operator string(RecordItem Item)
                {
                    return Item.As<string>();
                }
            }
        }
    #endregion

#endregion

#region Folder: Query
    #region File: Query\DbQuery.cs
        #nullable enable
        using NekoDatabaseGatewayModern.Query;
        using NekoDbGatewayModern;
        using System;
        using System.Collections.Generic;
        using System.Linq;
        using System.Text;
        using System.Threading.Tasks;

public sealed class DbQuery
            {
                public string Sql { get; 

public Dictionary<string, object?> Parameters { get; }
        
                public DbQuery(string sql, Dictionary<string, object?> parameters)
                {
                    if(sql == null) throw new ArgumentNullException("sql");
                    Sql = sql;
                    Parameters = parameters ?? new Dictionary<string, object?>();
                }
            }

}
    #endregion

    #region File: Query\QueryBuilder.cs
        #nullable enable
        using NekoDatabaseGatewayModern.Query;
        using System;
        using System.Collections.Generic;
        using System.Linq;
        using System.Text;
        using System.Text.RegularExpressions;

public class QueryBuilder
            {
                internal enum QueryType
                {
                    Select,
                    Insert,
                    Update
                
                private QueryType _queryType;
                private string? _table;
        
                private readonly List<string> _columns = new List<string>();
                private readonly List<string> _conditions = new List<string>();
                private readonly List<string> _groupByColumns = new List<string>();
                private readonly List<string> _orderByColumns = new List<string>();
                private readonly List<string> _joins = new List<string>();
        
                private readonly Dictionary<string, object?> _insertValues = new Dictionary<string, object?>();
                private readonly Dictionary<string, object?> _updateValues = new Dictionary<string, object?>();
        
                private readonly Dictionary<string, object?> _parameters = new Dictionary<string, object?>();
                private int _paramIndex;

public IReadOnlyDictionary<string, object?> Parameters
                {
                    get => _parameters;
                }
        
                private int? _top;
        
                private bool _isDistinctSelect;
                private string? _countColumn;
                private bool _isDistinctCount;
        
                private string NewParamName()
                {
                    _paramIndex++;
                    return "@p" + _paramIndex;
                }
        
                #region TOP

public QueryBuilder Top(int N)
                {
                    if(N > 0)
                        _top = N;
                    return this;
                }
        
                #endregion
        
                #region SELECT / DISTINCT / COUNT
        
                public QueryBuilder Select(params string[] Columns)
                {
                    _queryType = QueryType.Select;
                    if(Columns != null && Columns.Length > 0)
                        _columns.AddRange(Columns);
                    return this;
                }
        
                public QueryBuilder SelectDistinct(params string[] Columns)
                {
                    _queryType = QueryType.Select;
                    _isDistinctSelect = true;
                    if(Columns != null && Columns.Length > 0)
                        _columns.AddRange(Columns);
                    return this;
                }
        
                public QueryBuilder Distinct()
                {
                    _queryType = QueryType.Select;
                    _isDistinctSelect = true;
                    return this;
                }
        
                public QueryBuilder Count()
                {
                    _queryType = QueryType.Select;
                    _countColumn = "*";
                    _isDistinctCount = false;
                    return this;
                }
        
                public QueryBuilder Count(string Column)
                {
                    _queryType = QueryType.Select;
                    _countColumn = Column;
                    _isDistinctCount = false;
                    return this;
                }
        
                public QueryBuilder DistinctCount(string Column)
                {
                    _queryType = QueryType.Select;
                    _countColumn = Column;
                    _isDistinctCount = true;
                    return this;
                }
        
                #endregion
        
                #region FROM / JOIN
        
                public QueryBuilder From(string Table)
                {
                    _table = Table;
                    return this;
                }

public QueryBuilder Join(string Table, string OnExpression, string Type = "INNER")
                {
                    _joins.Add(Type + " JOIN " + Table + " ON " + OnExpression);
                    return this;
                }
        
                #endregion
        
                #region WHERE
        
                public QueryBuilder Where(string Condition, params object[] Values)
                {
                    if(!string.IsNullOrWhiteSpace(Condition) && Values != null && Values.Length > 0)
                    {
                        for(int i = 0; i < Values.Length; i++)
                        {
                            string placeholder = "@p" + (i + 1);
                            string paramName = NewParamName();
        
                            Condition = Regex.Replace(
                                Condition,
                                Regex.Escape(placeholder) + @"\b",
                                paramName);
        
                            _parameters[paramName] = Values[i];
                        }
                    }
        
                    if(!string.IsNullOrWhiteSpace(Condition))
                        _conditions.Add(Condition);
        
                    return this;
                }
        
                public QueryBuilder WhereIn(string Column, IEnumerable<object> Values)
                {
                    if(string.IsNullOrEmpty(Column) || Values == null)
                        return this;
        
                    List<object> list = new List<object>(Values);
                    if(list.Count == 0) return this;
        
                    List<string> prmNames = new List<string>();
        
                    foreach(object value in list)
                    {
                        string paramName = NewParamName();
                        prmNames.Add(paramName);
                        _parameters[paramName] = value;
                    }
        
                    _conditions.Add(Column + " IN (" + string.Join(", ", prmNames) + ")");
                    return this;
                }
        
                public QueryBuilder WhereNotIn(string Column, IEnumerable<object> Values)
                {
                    if(string.IsNullOrEmpty(Column) || Values == null)
                        return this;
        
                    List<object> list = new List<object>(Values);
                    if(list.Count == 0) return this;
        
                    List<string> prmNames = new List<string>();
        
                    foreach(object value in list)
                    {
                        string paramName = NewParamName();
                        prmNames.Add(paramName);
                        _parameters[paramName] = value;
                    }
        
                    _conditions.Add(Column + " NOT IN (" + string.Join(", ", prmNames) + ")");
                    return this;
                }
        
                public QueryBuilder WhereBetween(string Column, object Start, object End)
                {
                    string p1 = NewParamName();
                    string p2 = NewParamName();
        
                    _parameters[p1] = Start;
                    _parameters[p2] = End;
        
                    _conditions.Add(Column + " BETWEEN " + p1 + " AND " + p2);
                    return this;
                }
        
                public QueryBuilder WhereLike(string Column, string Pattern)
                {
                    string p = NewParamName();
                    _parameters[p] = Pattern;
                    _conditions.Add(Column + " LIKE " + p);
                    return this;
                }
        
                public QueryBuilder WhereExists(QueryBuilder SubQuery)
                {
                    if(SubQuery == null) return this;
        
                    QueryModel model = SubQuery.Build();
                    _conditions.Add("EXISTS (" + model.Sql + ")");
        
                    foreach(KeyValuePair<string, object> kv in model.Parameters)
                        _parameters[kv.Key] = kv.Value;
        
                    return this;
                }
        
                public QueryBuilder WhereNotExists(QueryBuilder SubQuery)
                {
                    if(SubQuery == null) return this;
        
                    QueryModel model = SubQuery.Build();
                    _conditions.Add("NOT EXISTS (" + model.Sql + ")");
        
                    foreach(KeyValuePair<string, object> kv in model.Parameters)
                        _parameters[kv.Key] = kv.Value;
        
                    return this;
                }
        
                #endregion
        
                #region GROUP BY / ORDER BY
        
                public QueryBuilder GroupBy(params string[] Columns)
                {
                    if(Columns != null && Columns.Length > 0)
                        _groupByColumns.AddRange(Columns);
                    return this;
                }
        
                public QueryBuilder OrderBy(params string[] Columns)
                {
                    if(Columns != null && Columns.Length > 0)
                        _orderByColumns.AddRange(Columns);
                    return this;
                }
        
                #endregion
        
                #region INSERT / UPDATE
        
                public QueryBuilder InsertInto(string Table, Dictionary<string, object?> Values)
                {
                    _queryType = QueryType.Insert;
                    _table = Table;
                    _insertValues.Clear();
        
                    if(Values != null)
                    {
                        foreach(KeyValuePair<string, object> kv in Values)
                            _insertValues[kv.Key] = kv.Value;
                    }
        
                    return this;
                }
        
                public QueryBuilder Update(string Table, Dictionary<string, object?> Values)
                {
                    _queryType = QueryType.Update;
                    _table = Table;
                    _updateValues.Clear();
        
                    if(Values != null)
                    {
                        foreach(KeyValuePair<string, object> kv in Values)
                            _updateValues[kv.Key] = kv.Value;
                    }
        
                    return this;
                }
        
                #endregion
        
                #region BUILD
        
                public QueryModel Build()
                {
                    string sql;
        
                    switch(_queryType)
                    {
                        case QueryType.Select:
                            sql = BuildSelect();
                            break;
        
                        case QueryType.Insert:
                            sql = BuildInsert();
                            break;
        
                        case QueryType.Update:
                            sql = BuildUpdate();
                            break;
        
                        default:
                            throw new InvalidOperationException("Query type was not defined. Call Select/Insert/Update first.");
                    }
        
                    return new QueryModel(sql, new Dictionary<string, object?>(_parameters), _top);
                }
        
                private string BuildSelect()
                {
                    if(string.IsNullOrEmpty(_table))
                        throw new InvalidOperationException("FROM table not specified.");
        
                    string cols;
        
                    if(!string.IsNullOrEmpty(_countColumn))
                    {
                        if(_isDistinctCount)
                            cols = "COUNT(DISTINCT " + _countColumn + ")";
                        else
                            cols = "COUNT(" + _countColumn + ")";
                    }
                    else
                    {
                        if(_isDistinctSelect)
                        {
                            if(_columns.Count > 0)
                                cols = "DISTINCT " + string.Join(", ", _columns);
                            else
                                cols = "DISTINCT *";
                        }
                        else
                        {
                            cols = _columns.Count > 0 ? string.Join(", ", _columns) : "*";
                        }
                    }
        
                    StringBuilder sb = new StringBuilder();
                    sb.Append("SELECT ").Append(cols).Append(" FROM ").Append(_table);
        
                    if(_joins.Count > 0)
                        sb.Append(" ").Append(string.Join(" ", _joins));
        
                    if(_conditions.Count > 0)
                        sb.Append(" WHERE ").Append(string.Join(" AND ", _conditions));
        
                    if(_groupByColumns.Count > 0)
                        sb.Append(" GROUP BY ").Append(string.Join(", ", _groupByColumns));
        
                    if(_orderByColumns.Count > 0)
                        sb.Append(" ORDER BY ").Append(string.Join(", ", _orderByColumns));

return sb.ToString();
                }
        
                private string BuildInsert()
                {
                    if(string.IsNullOrEmpty(_table))
                        throw new InvalidOperationException("INSERT table not specified.");
        
                    if(_insertValues.Count == 0)
                        throw new InvalidOperationException("No values specified for INSERT.");
        
                    List<string> cols = new List<string>(_insertValues.Keys);
                    List<string> paramNames = new List<string>();
        
                    for(int i = 0; i < cols.Count; i++)
                    {
                        string column = cols[i];
                        string paramName = NewParamName();
                        paramNames.Add(paramName);
                        _parameters[paramName] = _insertValues[column];
                    }
        
                    string sql = "INSERT INTO " + _table +
                                 " (" + string.Join(", ", cols) + ")" +
                                 " VALUES (" + string.Join(", ", paramNames) + ")";
        
                    return sql;
                }
        
                private string BuildUpdate()
                {
                    if(string.IsNullOrEmpty(_table))
                        throw new InvalidOperationException("UPDATE table not specified.");
        
                    if(_updateValues.Count == 0)
                        throw new InvalidOperationException("No values specified for UPDATE.");
        
                    List<string> sets = new List<string>();
        
                    foreach(KeyValuePair<string, object> kv in _updateValues)
                    {
                        string paramName = NewParamName();
                        sets.Add(kv.Key + " = " + paramName);
                        _parameters[paramName] = kv.Value;
                    }
        
                    StringBuilder sb = new StringBuilder();
                    sb.Append("UPDATE ").Append(_table).Append(" SET ").Append(string.Join(", ", sets));
        
                    if(_conditions.Count > 0)
                        sb.Append(" WHERE ").Append(string.Join(" AND ", _conditions));
        
                    return sb.ToString();
                }
        
                #endregion
            }
        }
    #endregion

    #region File: Query\QueryExecutionContext.cs
        #nullable enable
        using NekoDatabaseGatewayModern.Connection;
        using NekoDatabaseGatewayModern.Query;
        using System;
        using System.Collections.Generic;
        using System.Linq;
        using System.Text;
        using System.Threading.Tasks;

public class QueryExecutionContext : IDisposable
            {
                private bool disposedValue;
        
                public event Action<DbQueryEventArgs>? OnSqlGenerated;
                public event Action<DbQueryEventArgs>? OnSqlDispatch;
                public event Action<DbQuerySuccessEventArgs>? OnSuccess;
                public event Action<DbQueryFailureEventArgs>? OnError;
                public IDbConnectionFactory ConnectionFactory { get; 
                public IDbQueryTranslator Translator { get; }
                public QueryExecutionContext(IDbConnectionFactory connectionFactory, IDbQueryTranslator queryTranslator)
                {
                    ConnectionFactory = connectionFactory;
                    Translator = queryTranslator;
                }

internal void RaiseSqlGenerated(string sql)
                {
                    OnSqlGenerated?.Invoke(new DbQueryEventArgs(sql, DbQueryEventType.SqlGenerated));
                }
                internal void RaiseSqlDispatch(string sql)=> OnSqlDispatch?.Invoke(new DbQueryEventArgs(sql, DbQueryEventType.SqlDispatched));
                internal void RaiseSuccess(string sql, object? result = null) => OnSuccess?.Invoke(new DbQuerySuccessEventArgs(sql, result));
                internal void RaiseError(string sql, Exception ex)=> OnError?.Invoke(new DbQueryFailureEventArgs(sql, ex));
        
                protected virtual void Dispose(bool disposing)
                {
                    if(!disposedValue)
                    {
                        if(disposing)
                        {
                            if(ConnectionFactory!= null)
                                ConnectionFactory.Dispose();
                        }              
                        disposedValue = true;
                    }
                }
        
                public void Dispose()
                {
                    
                    Dispose(disposing: true);
                    GC.SuppressFinalize(this);
                }
            }
            [Flags]
            public enum DbQueryEventType { SqlGenerated=1, SqlDispatched=2, Success=4, Error=8}
            public class DbQueryEventArgs : EventArgs
            {
                public string RawSqlQuery { get; }
                public DbQueryEventType EventType { get; }
                public DbQueryEventArgs(string sql, DbQueryEventType type = DbQueryEventType.SqlGenerated)
                {
                    EventType = type;
                    RawSqlQuery = sql;
                }
        
            }
            public class DbQuerySuccessEventArgs : DbQueryEventArgs
            {
                public object? Result { get; }
                public DbQuerySuccessEventArgs(string sql) : base(sql, DbQueryEventType.SqlDispatched | DbQueryEventType.Success)
                { }
                public DbQuerySuccessEventArgs(string sql, object? result) : base(sql, DbQueryEventType.SqlDispatched | DbQueryEventType.Success)
                {
                    Result = result;
                }
            }
            public class DbQueryFailureEventArgs : DbQueryEventArgs
            {
                public Exception Ex { get; }
        
                public DbQueryFailureEventArgs(string sql, Exception ex) : base(sql, DbQueryEventType.SqlDispatched | DbQueryEventType.Error)
                {
                    Ex = ex;
                }

}
        
        }
    #endregion

    #region File: Query\QueryModel.cs
        #nullable enable
        using NekoDatabaseGatewayModern.Query;
        using System;
        using System.Collections.Generic;

public sealed class QueryModel
            {

public string Sql { get; 

public IReadOnlyDictionary<string, object?> Parameters { get; }

public int? Top { get; }
        
                public QueryModel(string Sql, Dictionary<string, object?> Parameters, int? Top = null)
                {
                    if(Sql == null) throw new ArgumentNullException(nameof(Sql));
                    if(Parameters == null) throw new ArgumentNullException(nameof(Parameters));
        
                    this.Sql = Sql;
                    this.Parameters = new Dictionary<string, object?>(Parameters);
                    this.Top = Top;
                }
            }

public interface IDbQueryTranslator
            {

DbQuery Translate(QueryModel Model);
            }
        }
    #endregion

    #region File: Query\Translators.cs
        #nullable enable
        using NekoDatabaseGatewayModern.Query;
        using System;
        using System.Collections.Generic;
        using System.Linq;

public sealed class SqlServerQueryTranslator : IDbQueryTranslator
            {
                public DbQuery Translate(QueryModel Model)
                {
                    if(Model == null) throw new ArgumentNullException(nameof(Model));
        
                    string sql = Model.Sql;
        
                    if(Model.Top.HasValue)
                    {
                        int top = Model.Top.Value;
        
                        const string selectDistinct = "SELECT DISTINCT ";
                        const string select = "SELECT ";
        
                        if(sql.StartsWith(selectDistinct, StringComparison.OrdinalIgnoreCase))
                        {
                            string rest = sql.Substring(selectDistinct.Length);
                            sql = "SELECT DISTINCT TOP (" + top + ") " + rest;
                        
                        else if(sql.StartsWith(select, StringComparison.OrdinalIgnoreCase))
                        {
                            string rest = sql.Substring(select.Length);
                            sql = "SELECT TOP (" + top + ") " + rest;
                        }
                    }
        
                    Dictionary<string, object?> parameters = new Dictionary<string, object?>(Model.Parameters.ToDictionary(k=>k.Key,k=>k.Value));
                    return new DbQuery(sql, parameters);
                }
            }

public sealed class AccessQueryTranslator : IDbQueryTranslator
            {
                public DbQuery Translate(QueryModel Model)
                {
                    if(Model == null) throw new ArgumentNullException(nameof(Model));
        
                    string sql = Model.Sql;
        
                    if(Model.Top.HasValue)
                    {
                        int top = Model.Top.Value;
        
                        const string selectDistinct = "SELECT DISTINCT ";
                        const string select = "SELECT ";
        
                        if(sql.StartsWith(selectDistinct, StringComparison.OrdinalIgnoreCase))
                        {
                            string rest = sql.Substring(selectDistinct.Length);
                            sql = "SELECT TOP " + top + " DISTINCT " + rest;
                        }
                        else if(sql.StartsWith(select, StringComparison.OrdinalIgnoreCase))
                        {
                            string rest = sql.Substring(select.Length);
                            sql = "SELECT TOP " + top + " " + rest;
                        }
                    }
        
                    Dictionary<string, object?> parameters = new Dictionary<string, object?>(Model.Parameters.ToDictionary(k => k.Key, k => k.Value));
                    return new DbQuery(sql, parameters);
                }
            }
        }
    #endregion

#endregion

