﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NekoDbGateway.Query
{
    public class QueryExecutionContext : IDisposable
    {
        private bool disposedValue;

        public event Action<DbQueryEventArgs> OnSqlGenerated;
        public event Action<DbQueryEventArgs> OnSqlDispatch;
        public event Action<DbQuerySuccessEventArgs> OnSuccess;
        public event Action<DbQueryFailureEventArgs> OnError;
        public IDbConnectionFactory ConnectionFactory { get; }
        public IDbQueryTranslator Translator { get; }
        public QueryExecutionContext(IDbConnectionFactory connectionFactory, IDbQueryTranslator queryTranslator)
        {
            ConnectionFactory = connectionFactory;
            Translator = queryTranslator;
        }
        

        internal void RaiseSqlGenerated(string sql)
        {
            OnSqlGenerated?.Invoke(new DbQueryEventArgs(sql, DbQueryEventType.SqlGenerated));
        }
        internal void RaiseSqlDispatch(string sql)=> OnSqlDispatch?.Invoke(new DbQueryEventArgs(sql, DbQueryEventType.SqlDispatched));
        internal void RaiseSuccess(string sql, object result = null)=>OnSuccess?.Invoke(new DbQuerySuccessEventArgs(sql, result));
        internal void RaiseError(string sql, Exception ex)=> OnError?.Invoke(new DbQueryFailureEventArgs(sql, ex));

        protected virtual void Dispose(bool disposing)
        {
            if(!disposedValue)
            {
                if(disposing)
                {
                    if(ConnectionFactory!= null)
                        ConnectionFactory.Dispose();
                }              
                disposedValue = true;
            }
        }

        public void Dispose()
        {
            // Não altere este código. Coloque o código de limpeza no método 'Dispose(bool disposing)'
            Dispose(disposing: true);
            GC.SuppressFinalize(this);
        }
    }
    [Flags]
    public enum DbQueryEventType { SqlGenerated=1, SqlDispatched=2, Success=4, Error=8}
    public class DbQueryEventArgs : EventArgs
    {
        public string RawSqlQuery { get; }
        public DbQueryEventType EventType { get; }
        public DbQueryEventArgs(string sql, DbQueryEventType type = DbQueryEventType.SqlGenerated)
        {
            EventType = type;
            RawSqlQuery = sql;
        }

    }
    public class DbQuerySuccessEventArgs : DbQueryEventArgs
    {
        public object Result { get; }
        public DbQuerySuccessEventArgs(string sql) : base(sql, DbQueryEventType.SqlDispatched | DbQueryEventType.Success)
        { }
        public DbQuerySuccessEventArgs(string sql, object result) : base(sql, DbQueryEventType.SqlDispatched | DbQueryEventType.Success)
        {
            Result = result;
        }
    }
    public class DbQueryFailureEventArgs : DbQueryEventArgs
    {
        public Exception Ex { get; }

        public DbQueryFailureEventArgs(string sql, Exception ex) : base(sql, DbQueryEventType.SqlDispatched | DbQueryEventType.Error)
        {
            Ex = ex;
        }
       

    }

}
