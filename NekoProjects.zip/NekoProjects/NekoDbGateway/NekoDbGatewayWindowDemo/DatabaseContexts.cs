﻿using NekoDbGateway.Query;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NekoDbGateway
{
    public static  class DatabaseContexts
    {
        //private static readonly IDbConnectionFactory _oleDbFactory = new AccessConnectionFactory();
        private static readonly IDbConnectionFactory _oleDbFactory = null;
        private static readonly IDbConnectionFactory _sqlDbFactory = new SqlConnectionFactory("Server=SQL5111.site4now.net;Database=db_a45fb2_dmretiradanew;User Id=db_a45fb2_dmretiradanew_admin;Password=##DMRetiradaLab220##;");

        private static readonly IDbQueryTranslator _oleTranslator = new AccessQueryTranslator();
        private static readonly IDbQueryTranslator _sqlTranslator = new SqlServerQueryTranslator();

        public static QueryExecutionContext Local { get => new QueryExecutionContext(_oleDbFactory, _oleTranslator); }
        public static QueryExecutionContext Remote { get => new QueryExecutionContext(_sqlDbFactory, _sqlTranslator); }

    }
}
