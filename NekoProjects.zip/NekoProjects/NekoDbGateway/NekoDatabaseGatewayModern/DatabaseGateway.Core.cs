#nullable enable
using NekoDatabaseGatewayModern.Query;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Common;
using System.Data.OleDb;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

namespace NekoDbGatewayModern
{
    /// <summary>
    /// Gateway genérico para acesso a dados baseado em SQL bruto e em <see cref="QueryBuilder"/>.
    /// 
    /// Exposição pública em quatro camadas:
    /// <list type="bullet">
    ///   <item><b>Raw</b>: RecordItem (GetRaw/ReadRaw).</item>
    ///   <item><b>DTO</b>: GetDto/ReadDto (tipado forte via reflexão).</item>
    ///   <item><b>Dynamic</b>: DynamicRow + IL.</item>
    ///   <item><b>Universal</b>: Get/Read com fallback DTO → Dynamic.</item>
    /// </list>
    /// </summary>
    public partial class DatabaseGateway
    {

        #region ctor

        /// <summary>
        /// Cria um <see cref="DatabaseGateway"/>
        /// </summary>
        public DatabaseGateway()
        {
            
        }

        #endregion

        #region Connection / command helpers

        private async Task<DbConnection> OpenConnectionAsync(QueryExecutionContext ctx,CancellationToken Ct)
        {
            var conn = await ctx.ConnectionFactory.Create().ConfigureAwait(false);


            try
            {
                await conn.OpenAsync(Ct).ConfigureAwait(false);
            }
            catch(NotSupportedException)
            {
                conn.Open();
            }

            return conn;

            
        }

        private async Task<T> WithCommandAsync<T>(QueryExecutionContext ctx, string Sql, Dictionary<string, object?>? Parameters, Func<DbCommand, Task<T>> work, CancellationToken Ct)
        {
            if(Sql == null) throw new ArgumentNullException(nameof(Sql));
            if(work == null) throw new ArgumentNullException(nameof(work));
            if(ctx == null) throw new ArgumentNullException(nameof(ctx));
            using(DbConnection conn = await OpenConnectionAsync(ctx,Ct).ConfigureAwait(false))
            {
                using(DbCommand cmd = conn.CreateCommand())
                {
                    cmd.CommandText = Sql;
                    cmd.CommandType = CommandType.Text;

                    ApplyParameters(cmd, Parameters);
                    T result = default;
                    try
                    {
                        
                        ctx.RaiseSqlDispatch(Sql);
                        result = await work(cmd).ConfigureAwait(false);
                        ctx.RaiseSuccess(Sql);
                    }
                    catch(Exception ex) { ctx.RaiseError(Sql,ex); }
                    return result;
                    
                }
            }
        }

        private Task<T> WithCommandAsync<T>(QueryExecutionContext ctx, string Sql, Func<DbCommand, Task<T>> work, CancellationToken Ct)
        {
            return WithCommandAsync(ctx, Sql, null, work, Ct);
        }

        private static async Task<DbDataReader> ExecuteReaderSafeAsync(DbCommand Cmd, CancellationToken Ct)
        {
            try
            {
                DbDataReader reader = await Cmd.ExecuteReaderAsync(Ct).ConfigureAwait(false);
                return reader;
            }
            catch(NotSupportedException)
            {
                return Cmd.ExecuteReader();
            }
        }

        private static async Task<int> ExecuteNonQuerySafeAsync(DbCommand Cmd, CancellationToken Ct)
        {
            try
            {
                int count = await Cmd.ExecuteNonQueryAsync(Ct).ConfigureAwait(false);
                return count;
            }
            catch(NotSupportedException)
            {
                return Cmd.ExecuteNonQuery();
            }
        }

        private static async Task<bool> ReadSafeAsync(DbDataReader Reader, CancellationToken Ct)
        {          
            try
            {
                bool has = await Reader.ReadAsync(Ct).ConfigureAwait(false);
                return has;
            }
            catch(NotSupportedException)
            {
                return Reader.Read();
            }
        }

        private static void ApplyParameters(DbCommand Cmd, Dictionary<string, object?>? Parameters)
        {
            if(Parameters == null || Parameters.Count == 0)
                return;

            bool isAccess = Cmd is OleDbCommand;

            IEnumerable<KeyValuePair<string, object>> ordered;

            if(isAccess)
                ordered = new List<KeyValuePair<string, object>>(Parameters).OrderBy(p => p.Key, StringComparer.Ordinal);
            else
                ordered = Parameters;

            foreach(KeyValuePair<string, object> kv in ordered)
            {
                DbParameter p = Cmd.CreateParameter();
                if(!isAccess)
                    p.ParameterName = kv.Key;

                p.Value = kv.Value ?? DBNull.Value;
                Cmd.Parameters.Add(p);
            }
        }

        #endregion

        
    }
}
