﻿namespace _2024
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if(disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            ToolStripLabel toolStripLabel1;
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            toolStrip1 = new ToolStrip();
            toolStripDropDownButton1 = new ToolStripDropDownButton();
            startToolStripMenuItem = new ToolStripMenuItem();
            quitToolStripMenuItem = new ToolStripMenuItem();
            devToolsToolStripMenuItem = new ToolStripMenuItem();
            moveToolStripMenuItem1 = new ToolStripMenuItem();
            toolStripMenuItem7 = new ToolStripMenuItem();
            toolStripMenuItem9 = new ToolStripMenuItem();
            toolStripMenuItem10 = new ToolStripMenuItem();
            toolStripMenuItem11 = new ToolStripMenuItem();
            toolStripMenuItem8 = new ToolStripMenuItem();
            toolStripDropDownButton2 = new ToolStripDropDownButton();
            cbSize = new ToolStripMenuItem();
            lbScore = new ToolStripLabel();
            pnCanvas = new Panel();
            startAutoToolStripMenuItem = new ToolStripMenuItem();
            toolStripLabel1 = new ToolStripLabel();
            toolStrip1.SuspendLayout();
            SuspendLayout();
            // 
            // toolStripLabel1
            // 
            toolStripLabel1.Name = "toolStripLabel1";
            toolStripLabel1.RightToLeft = RightToLeft.No;
            toolStripLabel1.Size = new Size(0, 22);
            // 
            // toolStrip1
            // 
            toolStrip1.AutoSize = false;
            toolStrip1.CanOverflow = false;
            toolStrip1.GripStyle = ToolStripGripStyle.Hidden;
            toolStrip1.Items.AddRange(new ToolStripItem[] { toolStripDropDownButton1, toolStripDropDownButton2, toolStripLabel1, lbScore });
            toolStrip1.Location = new Point(0, 0);
            toolStrip1.Name = "toolStrip1";
            toolStrip1.Size = new Size(436, 25);
            toolStrip1.TabIndex = 0;
            toolStrip1.Text = "toolStrip1";
            // 
            // toolStripDropDownButton1
            // 
            toolStripDropDownButton1.DisplayStyle = ToolStripItemDisplayStyle.Text;
            toolStripDropDownButton1.DropDownItems.AddRange(new ToolStripItem[] { startToolStripMenuItem, quitToolStripMenuItem, devToolsToolStripMenuItem, startAutoToolStripMenuItem });
            toolStripDropDownButton1.Image = (Image)resources.GetObject("toolStripDropDownButton1.Image");
            toolStripDropDownButton1.ImageTransparentColor = Color.Magenta;
            toolStripDropDownButton1.Name = "toolStripDropDownButton1";
            toolStripDropDownButton1.Size = new Size(51, 22);
            toolStripDropDownButton1.Text = "Game";
            // 
            // startToolStripMenuItem
            // 
            startToolStripMenuItem.Name = "startToolStripMenuItem";
            startToolStripMenuItem.Size = new Size(180, 22);
            startToolStripMenuItem.Text = "Restart";
            startToolStripMenuItem.Click += startToolStripMenuItem_Click;
            // 
            // quitToolStripMenuItem
            // 
            quitToolStripMenuItem.Name = "quitToolStripMenuItem";
            quitToolStripMenuItem.Size = new Size(180, 22);
            quitToolStripMenuItem.Text = "Quit";
            quitToolStripMenuItem.Click += quitToolStripMenuItem_Click;
            // 
            // devToolsToolStripMenuItem
            // 
            devToolsToolStripMenuItem.DropDownItems.AddRange(new ToolStripItem[] { moveToolStripMenuItem1, toolStripMenuItem8 });
            devToolsToolStripMenuItem.Name = "devToolsToolStripMenuItem";
            devToolsToolStripMenuItem.Size = new Size(180, 22);
            devToolsToolStripMenuItem.Text = "DevTools";
            // 
            // moveToolStripMenuItem1
            // 
            moveToolStripMenuItem1.DropDownItems.AddRange(new ToolStripItem[] { toolStripMenuItem7, toolStripMenuItem9, toolStripMenuItem10, toolStripMenuItem11 });
            moveToolStripMenuItem1.Name = "moveToolStripMenuItem1";
            moveToolStripMenuItem1.Size = new Size(127, 22);
            moveToolStripMenuItem1.Text = "Move";
            // 
            // toolStripMenuItem7
            // 
            toolStripMenuItem7.Name = "toolStripMenuItem7";
            toolStripMenuItem7.Size = new Size(105, 22);
            toolStripMenuItem7.Text = "Top";
            // 
            // toolStripMenuItem9
            // 
            toolStripMenuItem9.Name = "toolStripMenuItem9";
            toolStripMenuItem9.Size = new Size(105, 22);
            toolStripMenuItem9.Text = "Down";
            // 
            // toolStripMenuItem10
            // 
            toolStripMenuItem10.Name = "toolStripMenuItem10";
            toolStripMenuItem10.Size = new Size(105, 22);
            toolStripMenuItem10.Text = "Left";
            // 
            // toolStripMenuItem11
            // 
            toolStripMenuItem11.Name = "toolStripMenuItem11";
            toolStripMenuItem11.Size = new Size(105, 22);
            toolStripMenuItem11.Text = "Right";
            // 
            // toolStripMenuItem8
            // 
            toolStripMenuItem8.Name = "toolStripMenuItem8";
            toolStripMenuItem8.Size = new Size(127, 22);
            toolStripMenuItem8.Text = "SpawnTile";
            toolStripMenuItem8.Click += toolStripMenuItem8_Click;
            // 
            // toolStripDropDownButton2
            // 
            toolStripDropDownButton2.DisplayStyle = ToolStripItemDisplayStyle.Text;
            toolStripDropDownButton2.DropDownItems.AddRange(new ToolStripItem[] { cbSize });
            toolStripDropDownButton2.Image = (Image)resources.GetObject("toolStripDropDownButton2.Image");
            toolStripDropDownButton2.ImageTransparentColor = Color.Magenta;
            toolStripDropDownButton2.Name = "toolStripDropDownButton2";
            toolStripDropDownButton2.Size = new Size(62, 22);
            toolStripDropDownButton2.Text = "Options";
            // 
            // cbSize
            // 
            cbSize.Name = "cbSize";
            cbSize.Size = new Size(127, 22);
            cbSize.Text = "Game size";
            // 
            // lbScore
            // 
            lbScore.Alignment = ToolStripItemAlignment.Right;
            lbScore.Font = new Font("Arial Rounded MT Bold", 10F);
            lbScore.Name = "lbScore";
            lbScore.Size = new Size(62, 22);
            lbScore.Text = "Score: 0";
            // 
            // pnCanvas
            // 
            pnCanvas.AutoSizeMode = AutoSizeMode.GrowAndShrink;
            pnCanvas.BackColor = Color.FromArgb(225, 225, 225);
            pnCanvas.Location = new Point(0, 25);
            pnCanvas.MinimumSize = new Size(100, 100);
            pnCanvas.Name = "pnCanvas";
            pnCanvas.Size = new Size(100, 100);
            pnCanvas.TabIndex = 1;
            // 
            // startAutoToolStripMenuItem
            // 
            startAutoToolStripMenuItem.Name = "startAutoToolStripMenuItem";
            startAutoToolStripMenuItem.Size = new Size(180, 22);
            startAutoToolStripMenuItem.Text = "StartAuto";
            startAutoToolStripMenuItem.Click += startAutoToolStripMenuItem_Click;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            AutoSize = true;
            AutoSizeMode = AutoSizeMode.GrowAndShrink;
            ClientSize = new Size(436, 175);
            Controls.Add(pnCanvas);
            Controls.Add(toolStrip1);
            MinimumSize = new Size(100, 100);
            Name = "Form1";
            Text = "Form1";
            Click += Form1_Click;
            toolStrip1.ResumeLayout(false);
            toolStrip1.PerformLayout();
            ResumeLayout(false);
        }

        #endregion

        private ToolStrip toolStrip1;
        private ToolStripDropDownButton toolStripDropDownButton1;
        private ToolStripDropDownButton toolStripDropDownButton2;
        private Panel pnCanvas;
        private ToolStripMenuItem startToolStripMenuItem;
        private ToolStripMenuItem quitToolStripMenuItem;
        private ToolStripMenuItem cbSize;
        private ToolStripLabel lbScore;
        private ToolStripMenuItem devToolsToolStripMenuItem;
        private ToolStripMenuItem moveToolStripMenuItem1;
        private ToolStripMenuItem toolStripMenuItem7;
        private ToolStripMenuItem toolStripMenuItem9;
        private ToolStripMenuItem toolStripMenuItem10;
        private ToolStripMenuItem toolStripMenuItem11;
        private ToolStripMenuItem toolStripMenuItem8;
        private ToolStripMenuItem startAutoToolStripMenuItem;
    }
}
