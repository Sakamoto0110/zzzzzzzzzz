using System.Windows.Forms;

namespace _2024
{
    public partial class Form1 : Form
    {
        Game Game;

        public Form1()
        {
            InitializeComponent();
            Game = new Game(pnCanvas);
            Game.AfterMove += Game.GenerateOneTile;
            foreach(var gs in Game.AvailableGameSizes)
            {
                var tsmi = new ToolStripButton($"{gs.ColumnCount} x {gs.RowCount}", null,
                   new EventHandler((s, e) => {
                       var _s = (ToolStripButton)s;
                       Game.GameSize = (GameSize)_s.Tag;
                       Game.Start(2);
                   }));
                tsmi.Tag = gs;
                cbSize.DropDownItems.Add(tsmi);
            }
            Game.GameSize = Game.AvailableGameSizes[2];
            Game.Start(2);
            Game.Scored += (s, e) => {
                lbScore.Text = $"Score: {e.Score} ({e.Delta})";
            };
            this.KeyUp += Form1_KeyDown;
            System.Windows.Forms.Timer t = new System.Windows.Forms.Timer();
            t.Interval = 1000;
            t.Tick += (s, e) => {
                var str = new[]
                {
                    "top","right","left","down"
                };
                int i = new Random().Next(0, 4);
                Console.Write($"{i} ");
                if(i < 0 || i > 4)
                    return;
                Console.Write($"- {str[i]}\n");
                Game.MoveButtons(i);
                //Color old = pnCanvas.BackColor;
                //var hsl = pnCanvas.BackColor.ToHsl();
                //hsl.L = hsl.L - 0.04;
                //if(hsl.L < 0.5)
                //{
                //    hsl.L = 0.8;
                //    hsl.H = (hsl.H + 8) % 360;
                //}
                //pnCanvas.BackColor = ColorExtensions.FromHsl(hsl);
                //Console.WriteLine($"[old: {old.R},{old.G},{old.B}]");
                //Console.WriteLine($"[new: {pnCanvas.BackColor.R},{pnCanvas.BackColor.G},{pnCanvas.BackColor.B}]\n");
            };

        }

        private void Form1_KeyDown(object? sender, KeyEventArgs e)
        {
            var keys = new[]{
                Keys.W,
                Keys.D,
                Keys.S,
                Keys.A,
            };
            if(e.KeyCode == Keys.W ||
e.KeyCode == Keys.D ||
e.KeyCode == Keys.S ||
e.KeyCode == Keys.A)
            {
                if(e.KeyCode == Keys.W) Game.MoveButtons(1);
                else if(e.KeyCode == Keys.D) Game.MoveButtons(2);
                else if(e.KeyCode == Keys.S) Game.MoveButtons(3);
                else if(e.KeyCode == Keys.A) Game.MoveButtons(4);
                //Game.AddRandomCells(2, 1, 3);
            }

            if(e.KeyCode == Keys.Space) Game.AddRandomCells(1, 1, 1);

        }






        private void topToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Game.MoveButtons(1);
        }

        private void downToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Game.MoveButtons(3);
        }

        private void leftToolStripMenuItem_Click(object sender, EventArgs e)
        {

            Game.MoveButtons(4);
        }
        // 1 top
        // 2 right
        // 3 bottom
        // 4 left
        private void rightToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Game.MoveButtons(2);
        }



        private void spawnTileToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            Random rand = new Random();
            var x = rand.Next(0, Game.GameSize.ColumnCount);
            var y = rand.Next(0, Game.GameSize.RowCount);
            var v = rand.Next(1, 3);
            Game.AddButton(x, y, 1);
        }

        private void startToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Game.Start(2);
        }

        private void quitToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void toolStripMenuItem8_Click(object sender, EventArgs e)
        {
            Game.AddRandomCells(1, 1, 3);
        }

        private void Form1_Click(object sender, EventArgs e)
        {

        }

        private void startAutoToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Game.AddToQueue(new[] { 4,4,3,2,1,1, 2, 3 });
        }
    }


}
