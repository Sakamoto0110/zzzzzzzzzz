﻿using PageNav.Core.Abstractions;
using PageNav.Core.Plataform;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace PageNav.Core.Services
{
    public static partial class NavigationService
    {
        private static IPageHost _host;

        public static IPageView Current { get; private set; }
        private static IInteractionBlocker _blocker;
        private static IEventDispatcherAdapter _events;
        private static IPageMask _mask;
        //private static ChildWindowManager _childManager;


        public static void SetEventDispatcher(IEventDispatcherAdapter dispatcher)
        {
            _events = dispatcher;
        }
        public static void SetInteractionBlocker(IInteractionBlocker blocker)
        {
            _blocker = blocker;
        }
        public static void Initialize(object nativeHost, int timeoutSeconds = 60)
        {
            if(nativeHost == null)
                throw new ArgumentNullException(nameof(nativeHost));

            // Resolve platform
            var adapter = PlatformRegistry.ResolveHost(nativeHost);
            
            _host = adapter.CreateHost(nativeHost);

            // Retrieve platform-specific services (mask, event dispatcher, etc)
            _mask = adapter.CreateMask(nativeHost);
            _events = adapter.CreateEventDispatcher(nativeHost);
            _blocker = adapter.CreateInteractionBlocker(nativeHost);
            var timer = adapter.CreateTimerAdapter();

            // Init timeout + mask service
            PageMaskService.Initialize(_mask);
            TimeoutService.Initialize(timer, timeoutSeconds);

            TimeoutService.TimeoutReached += OnTimeout;
        }




        public readonly struct NavigationArgs
        {
            public readonly object Payload;
            public readonly bool UseMask;
            public readonly bool UseCache;

            public NavigationArgs(object payload = null, bool useMask = true, bool useCache = true)
            {
                Payload = payload;
                UseMask = useMask;
                UseCache = useCache;
            }

            public T PayloadAs<T>() => Payload is T t ? t : default;
        }
        // -------------------------------------------------------------------------
        // 1) CACHED NAVIGATION (Persistent pages)
        // -------------------------------------------------------------------------
        public static Task SwitchPage<T>(object args = null) where T : IPageView => SwitchInternal(typeof(T), new NavigationArgs(useCache: true, payload: args));

        // -------------------------------------------------------------------------
        // 2) TRANSIENT NAVIGATION (New instance every time)
        // -------------------------------------------------------------------------
        public static Task SwitchTransient<T>(object args = null) where T : IPageView => SwitchInternal(typeof(T), new NavigationArgs(useCache: false, payload: args));


        // -------------------------------------------------------------------------
        // 1) CACHED NAVIGATION (Persistent pages)
        // -------------------------------------------------------------------------
        public static Task SwitchPage(Type type, object args = null) => SwitchInternal(type, new NavigationArgs(useCache: true, payload: args));

        // -------------------------------------------------------------------------
        // 2) TRANSIENT NAVIGATION (New instance every time)
        // -------------------------------------------------------------------------
        public static Task SwitchTransient(Type type, object args = null) => SwitchInternal(type, new NavigationArgs(useCache: false, payload: args));


        public static async Task GoHomeAsync(object args = null)
        {
            var target = PageRegistry.ResolveTimeoutTarget();

            if(target == null)
                return; // or throw/log depending on design

            await SwitchInternal(target.GetType(), new NavigationArgs(args));
        }


        //// New stuff
        //public static Task<IPageView> OpenChildAsync<T>(ChildWindowArgs args = null) where T : IPageView => _childManager.OpenChildAsync(typeof(T), args ?? new ChildWindowArgs());
        //public static Task CloseChildAsync(IPageView childPage) => _childManager.CloseChildAsync(childPage);
    }
}
