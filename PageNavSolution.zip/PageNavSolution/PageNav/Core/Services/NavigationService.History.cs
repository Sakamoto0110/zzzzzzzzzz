﻿using PageNav.Core.Abstractions;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PageNav.Core.Services
{
    public static partial class NavigationService
    {
        public sealed class PageHistoryEntry
        {
            public readonly IPageView Instance;
            public readonly DateTime Timestamp;

            public PageHistoryEntry(IPageView instance)
            {
                Instance = instance;
                Timestamp = DateTime.Now;
            }

            public override string ToString() => $"{Instance.Name} ({Timestamp:HH:mm:ss})";
        }

        public static class NavigationHistory
        {
            private static readonly Stack<PageHistoryEntry> _back = new Stack<PageHistoryEntry>();
            private static readonly Stack<PageHistoryEntry> _forward = new Stack<PageHistoryEntry>();

            public static bool CanGoBack => _back.Count > 0;
            public static bool CanGoForward => _forward.Count > 0;

            internal static void Record(IPageView fromPage)
            {
                if(fromPage == null) return;

                _back.Push(new PageHistoryEntry(fromPage));
                _forward.Clear();
            }

            public static void Clear()
            {
                _back.Clear();
                _forward.Clear();
            }

            public static IEnumerable<PageHistoryEntry> HistoryBack => _back.ToList();
            public static IEnumerable<PageHistoryEntry> HistoryForward => _forward.ToList();
        }
    }
}
