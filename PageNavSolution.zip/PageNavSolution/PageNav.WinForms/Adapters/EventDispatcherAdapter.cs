﻿using PageNav.Core.Abstractions;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PageNav.WinForms.Adapters
{
 
    public class EventDispatcherAdapter : IEventDispatcherAdapter
    {
        public void AttatchEvent<THandler>(object reciever, string eventName, THandler handler) where THandler : Delegate
        {
            if(reciever is System.Windows.Forms.Control c)
                AttatchEventInternal(c, eventName, handler);
        }

        public void DetatchEvent<THandler>(object reciever, string eventName, THandler handler) where THandler : Delegate
        {
            if(reciever is System.Windows.Forms.Control c)
                DetatchEventInternal(c, eventName, handler);
        }



        static int i=0;
        private void AttatchEventInternal<THandler>(System.Windows.Forms.Control reciever, string eventName, THandler handler) where THandler : Delegate
        {
            var ev = reciever.GetType().GetEvent(eventName) ?? throw new ArgumentException($"Event not found: {eventName}");
            ev.AddEventHandler(reciever, handler);
            Console.WriteLine($"++{i++}, {ev}");
            foreach(System.Windows.Forms.Control c in reciever.Controls)
                AttatchEventInternal(c, eventName, handler);
        }
        private void DetatchEventInternal<THandler>(System.Windows.Forms.Control reciever, string eventName, THandler handler) where THandler : Delegate
        {
            var ev = reciever.GetType().GetEvent(eventName) ?? throw new ArgumentException($"Event not found: {eventName}");
            ev.RemoveEventHandler(reciever, handler);
            Console.WriteLine($"--{i--}, {ev}");
            foreach(System.Windows.Forms.Control c in reciever.Controls)
                DetatchEventInternal(c, eventName, handler);

        }
    }
}
