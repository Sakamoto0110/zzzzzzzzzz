﻿//using System;
//using System.Collections.Generic;
//using System.Linq;
//using System.Text;
//using System.Threading.Tasks;
//using static PageNav.NavigationService;

//namespace PageNav
//{
//    public enum ChildWindowMode
//    {
//        NonModal,  // Floating tools, side panels, auxiliary views
//        Modal      // Blocks interaction until closed
//    }

//    public sealed class ChildWindowArgs
//    {
//        public object Payload { get; }
//        public ChildWindowMode Mode { get; }
//        public ViewLayer Layer { get; }

//        public ChildWindowArgs(
//            object payload = null,
//            ChildWindowMode mode = ChildWindowMode.NonModal,
//            ViewLayer layer = ViewLayer.Overlay)
//        {
//            Payload = payload;
//            Mode = mode;
//            Layer = layer;
//        }
//    }
//    internal sealed class ChildWindowManager : IChildViewHost
//    {
//        private readonly Dictionary<ViewLayer, Stack<IPageView>> _layers =
//            new()
//            {
//            { ViewLayer.Content, new Stack<IPageView>() },
//            { ViewLayer.Overlay, new Stack<IPageView>() },
//            { ViewLayer.Modal, new Stack<IPageView>() },
//            { ViewLayer.System, new Stack<IPageView>() }
//            };

//        private readonly IInteractionBlocker _blocker;
//        private readonly IPageHost _host;

//        public ChildWindowManager(IPageHost host, IInteractionBlocker blocker)
//        {
//            _host = host;
//            _blocker = blocker;
//        }

//        public IReadOnlyList<IPageView> ActiveChildren =>
//            _layers.SelectMany(x => x.Value).ToList();

//        public async Task<IPageView> OpenChildAsync(Type type, ChildWindowArgs args)
//        {
//            var page = PageRegistry.Resolve(type, type.Name);

//            page.OnAttach(_host);
//            page.IsVisible = true;

//            await page.ReloadAsync(args.Payload);

//            _layers[args.Layer].Push(page);
//            ApplyRules();

//            return page;
//        }

//        public async Task CloseChildAsync(IPageView page)
//        {
//            foreach(var layer in _layers.Values)
//            {
//                if(layer.Contains(page))
//                {
//                    RemoveFromStack(layer, page);
//                    await DestroyInstance(page);
//                    ApplyRules();
//                    return;
//                }
//            }
//        }

//        private async Task DestroyInstance(IPageView page)
//        {
//            await page.ReleaseResources();
//            page.OnDetach();
//            page.Dispose();
//        }

//        private void RemoveFromStack(Stack<IPageView> stack, IPageView target)
//        {
//            var tmp = new Stack<IPageView>();
//            while(stack.Peek() != target)
//                tmp.Push(stack.Pop());

//            stack.Pop(); // remove target

//            while(tmp.Count > 0)
//                stack.Push(tmp.Pop());
//        }

//        private void ApplyRules()
//        {
//            bool modalActive = _layers[ViewLayer.Modal].Count > 0;
//            bool systemActive = _layers[ViewLayer.System].Count > 0;

//            if(modalActive || systemActive)
//                _blocker?.Block(NavigationService.Current.NativeView);
//            else
//                _blocker?.Unblock(NavigationService.Current.NativeView);
//        }
//    }

//    public static class NavigationHistory
//    {
//        private static readonly Stack<IPageView> _backStack =    new Stack<IPageView>();
//        private static readonly Stack<IPageView> _forwardStack = new Stack<IPageView>();

//        internal static void RecordNavigation(IPageView from, IPageView to)
//        {
//            if(from != null)
//            {
//                _backStack.Push(from);
//                _forwardStack.Clear();
//            }
//        }

//        public static bool CanGoBack => _backStack.Count > 0;
//        public static bool CanGoForward => _forwardStack.Count > 0;

//        public static async Task GoBackAsync()
//        {
//            if(!CanGoBack)
//                return;

//            var target = _backStack.Pop();
//            _forwardStack.Push(NavigationService.Current);
//            await NavigationService.SwitchPage(target);
//        }

//        public static async Task GoForwardAsync()
//        {
//            if(!CanGoForward)
//                return;

//            var target = _forwardStack.Pop();
//            _backStack.Push(NavigationService.Current);
//            await NavigationService.NavigateToExistingAsync(target);
//        }
//    }



//}
