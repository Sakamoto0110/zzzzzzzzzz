﻿using PageNav.WinForms;
using PageNav.Wpf;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace PageNav
{
    public static class PageAdapterFactory
    {
        public static IPageHost CreateHost(object nativeHost)
        {

            if(nativeHost is System.Windows.Controls.Panel panelHost) return new Wpf.PageHost(panelHost);
            if(nativeHost is System.Windows.Forms.Control controlHost) return new WinForms.PageHost(controlHost);
            throw new NotSupportedException($"Unsupported host type {nativeHost}");
        }

        public static IPageView CreatePageView(Type type)
        {
            object instance = Activator.CreateInstance(type);
            if(instance is IPageView page) return page;
            throw new InvalidOperationException($"Type {type.Name} does not implement IPageView");
        }
    }
}
