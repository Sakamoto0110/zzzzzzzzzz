﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PageNav
{
    public static class PageMaskService
    {
        private static IPageMask _mask;

        public static void Initialize(IPageMask mask)
        {
            _mask = mask ?? throw new ArgumentNullException(nameof(mask));
        }

        public static void Show(string message = "")
        {
            _mask?.Show(message);
        }

        public static void Hide()
        {
            _mask?.Hide();
        }
    }
}
