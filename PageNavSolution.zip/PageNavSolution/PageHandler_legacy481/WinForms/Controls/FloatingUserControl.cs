﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PageNav.WinForms.Controls
{
    public partial class FloatingUserControl : UserControl
    {
        public FloatingUserControl()
        {
            InitializeComponent();
        }
        public static class MovableControlHelper
        {
            private class HandlerSet
            {
                public MouseEventHandler MouseDown;
                public MouseEventHandler MouseMove;
                public MouseEventHandler MouseUp;
                public ControlEventHandler ControlAdded;
                public ControlEventHandler ControlRemoved;
            }

            // Stores handlers per control
            private static readonly Dictionary<Control, HandlerSet> HandlerMap = new Dictionary<Control, HandlerSet>();

            public static void MakeMovable(Control movableControl)
            {
                if(HandlerMap.ContainsKey(movableControl)) return;

                Point offset = Point.Empty;
                bool isDragging = false;

                var handlers = new HandlerSet();

                handlers.MouseDown = (s, e) => {
                    if(e.Button == MouseButtons.Left)
                    {
                        isDragging = true;
                        offset = movableControl.PointToClient(Control.MousePosition);
                    }
                };

                handlers.MouseMove = (s, e) => {
                    if(!isDragging) return;

                    Point mousePos = movableControl.Parent.PointToClient(Control.MousePosition);

                    int newX = mousePos.X - offset.X;
                    int newY = mousePos.Y - offset.Y;

                    newX = Math.Max(0, Math.Min(newX, movableControl.Parent.ClientSize.Width - movableControl.Width));
                    newY = Math.Max(0, Math.Min(newY, movableControl.Parent.ClientSize.Height - movableControl.Height));

                    movableControl.Location = new Point(newX, newY);
                    movableControl.Invalidate();
                    if(movableControl.Parent != null)
                    {
                        movableControl.Parent.Invalidate();
                    }
                };

                handlers.MouseUp = (s, e) => {
                    if(e.Button == MouseButtons.Left)
                        isDragging = false;
                };

                handlers.ControlAdded = (s, e) => {
                    AttachHandlers(e.Control, handlers);
                };

                handlers.ControlRemoved = (s, e) => {
                    DetachHandlers(e.Control, handlers);
                };


                AttachHandlers(movableControl, handlers);


                movableControl.ControlAdded += handlers.ControlAdded;
                movableControl.ControlRemoved += handlers.ControlRemoved;

                HandlerMap[movableControl] = handlers;
            }

            public static void RemoveMovable(Control movableControl)
            {
                if(!HandlerMap.TryGetValue(movableControl, out var handlerSet))
                    return;

                DetachHandlers(movableControl, handlerSet);
                HandlerMap.Remove(movableControl);
            }

            private static void AttachHandlers(Control parent, HandlerSet handlers)
            {
                parent.MouseDown += handlers.MouseDown;
                parent.MouseMove += handlers.MouseMove;
                parent.MouseUp += handlers.MouseUp;
                foreach(Control child in parent.Controls)
                {
                    AttachHandlers(child, handlers);
                }
            }

            private static void DetachHandlers(Control parent, HandlerSet handlers)
            {
                parent.MouseDown -= handlers.MouseDown;
                parent.MouseMove -= handlers.MouseMove;
                parent.MouseUp -= handlers.MouseUp;

                foreach(Control child in parent.Controls)
                {
                    DetachHandlers(child, handlers);
                }
            }
        }
    }
}
