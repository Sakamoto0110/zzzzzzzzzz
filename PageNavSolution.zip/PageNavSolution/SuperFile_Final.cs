﻿
namespace PageNav
{
    
    
    
    
    public interface IPageHost
    {
        

        
        
        
        
        void AddView(object frameworkView);

        
        
        
        void RemoveView(object frameworkView);

        
        
        
        void BringToFront(object frameworkView);

        
        
        
        void Focus(object frameworkView);
    }

    
    
    
    
    public interface IPageView : IDisposable
    {
        bool DesignMode { get; }
        event Action<object> ChildViewAdded;
        event Action<object> ChildViewRemoved;
        
        
        
        string Name { get; }

        
        
        
        
        bool IsVisible { get; set; }

        
        
        
        bool IsLocked { get; set; }

        
        
        
        
        void OnAttach(IPageHost host);

        
        
        
        void OnDetach();

        event Action OnDetachEvent;

        
        
        
        
        Task ReloadAsync(object args);

        
        
        
        void Enable();

        
        
        
        void Disable();

        
        
        
        
        Task ReleaseResources();
        object NativeView { get; }
    }

    public interface IPageMask
    {
        void Show(string message = "");
        void Hide();
    }
    public interface ITimerAdapter : IDisposable
    {
        void Start(int intervalMilliseconds, Action tick);
        void Stop();
    }
    public interface IEventDispatcherAdapter
    {
        void AttatchEvent<THandler>(object reciever, string eventName, THandler handler) where THandler : Delegate;
        void DetatchEvent<THandler>(object reciever, string eventName, THandler handler) where THandler : Delegate;
       

    }
    public interface IInteractionBlocker
    {
        void Block(object view);
        void Unblock(object view);
    }
}

namespace PageNav
{
    internal class DesignTimeHost : IPageHost
    {
        public void AddView(object view) { }
        public void RemoveView(object view) { }
        public void BringToFront(object view) { }
        public void Focus(object view) { }
    }
}

namespace PageNav
{
    public  static partial class NavigationService
    {
        private static IPageHost _host;
        
        public static IPageView Current { get; private set; }
        private static IInteractionBlocker _blocker;
        private static IEventDispatcherAdapter _events;
        private static IPageMask _mask;
 
      
        public static void SetEventDispatcher(IEventDispatcherAdapter dispatcher)
        {
            _events = dispatcher;
        }
        public static void SetInteractionBlocker(IInteractionBlocker blocker)
        {
            _blocker = blocker;
        }
        public static void Initialize(object nativeHost,
                                      ITimerAdapter timer,
                                      IPageMask mask,
                                      IEventDispatcherAdapter events,
                                      IInteractionBlocker blocker)
        {
            _host = PageAdapterFactory.CreateHost(nativeHost);
            _events = events;
            _mask = mask;
            _blocker = blocker;           
            
            TimeoutService.Initialize(timer, timeoutSeconds: 60);
            PageMaskService.Initialize(mask);
            TimeoutService.TimeoutReached += OnTimeout;
        }

        
        

        public readonly struct NavigationArgs
        {
            public readonly object Payload;
            public readonly bool UseMask;
            public readonly bool UseCache;

            public NavigationArgs(object payload = null, bool useMask = true, bool useCache = true)
            {
                Payload = payload;
                UseMask = useMask;
                UseCache = useCache;
            }

            public T PayloadAs<T>() => Payload is T t ? t : default;
        }
        
        
        
        public static Task SwitchPage<T>(object args=null) where T : IPageView => SwitchInternal(typeof(T), new NavigationArgs(useCache: true,payload: args));

        
        
        
        public static Task SwitchTransient<T>(object args=null) where T : IPageView => SwitchInternal(typeof(T), new NavigationArgs(useCache: false,payload: args));

        public static async Task GoHomeAsync(object args = null)
        {
            var target = PageRegistry.ResolveTimeoutTarget();

            if(target == null)
                return; 

            await SwitchInternal(target.GetType(), new NavigationArgs(args));
        }

    }
}

namespace PageNav
{
    public static partial class NavigationService
    {
        private static void OnChildViewAdded(object obj)
        {
            
            if(_events != null)
                _events.AttatchEvent<EventHandler>(obj, "Click", TimeoutService.Reset);

        }

        private static void OnChildViewRemoved(object obj)
        {
            if(_events != null)
                _events.DetatchEvent<EventHandler>(obj, "Click", TimeoutService.Reset);

        }

        
        
        
        private static async void OnTimeout()
        {

            if(Current != null)
            {
                var desc = PageRegistry.GetDescriptor(Current.GetType());

                switch(desc.Timeout)
                {
                    case TimeoutBehavior.IgnoreTimeout:
                        return;

                    case TimeoutBehavior.OverrideHome:
                        await SwitchInternal(desc.PageType, new NavigationArgs());
                        return;
                }
            }
            
            try
            {
                var target = PageRegistry.ResolveTimeoutTarget();

                if(target == null)
                    return; 

                await SwitchInternal(target.GetType(), new NavigationArgs(null));
            }
            catch(Exception ex)
            {
                PageLogger.LogError($"Timeout navigation failed: {ex.Message}");
            }

        }
    }
}

namespace PageNav
{
    public static partial class NavigationService
    {

        
        
        

        
        
        
        
        [Flags]
        public enum PageKind
        {
            Home = 1,
            Default = 2,
            Modal = 4,
            Popup = 8
        }

        
        
        
        public enum PageCachePolicy
        {
            None = 0,
            Disabled = 1,
            WeakSingleton = 2,
            StrongSingleton = 4,
            Stackable = 8
        }

        
        
        

        
        
        
        
        public sealed class PageDescriptor
        {
            
            public Type PageType { get; set; }

            
            public string Name { get; set; }

            
            public PageKind Kind { get; set; }

            
            public PageCachePolicy CachePolicy { get; set; }

            
            public IPageView CachedInstance { get; set; }

            
            public Stack<IPageView> StackInstances { get; private set; }

            
            public HashSet<string> Tags { get; set; }
            public TimeoutBehavior Timeout { get; set; } = TimeoutBehavior.Default;

            
            
            
            public PageDescriptor()
            {
                StackInstances = new Stack<IPageView>();
                Tags = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
            }
        }

        
        
        

        
        
        
        [AttributeUsage(AttributeTargets.Class, AllowMultiple = false)]
        public sealed class PageBehaviorAttribute : Attribute
        {
            public TimeoutBehavior Timeout { get; set; } = TimeoutBehavior.Default;

            
            public PageKind Kind { get; private set; }

            
            public PageCachePolicy CachePolicy { get; private set; }

            
            
            
            public string NameOverride { get; set; }

            
            
            
            public string[] Tags { get; set; }

            
            
            
            public PageBehaviorAttribute(
                PageKind kind = PageKind.Default,
                PageCachePolicy cachePolicy = PageCachePolicy.Disabled)
            {
                Kind = kind;
                CachePolicy = cachePolicy;
            }
        }

        
        
        

        
        
        
        
        public static class PageRegistry
        {
            private static readonly Dictionary<string, PageDescriptor> _registry =
                new Dictionary<string, PageDescriptor>(StringComparer.OrdinalIgnoreCase);

            
            
            

            
            
            
            public static void Register<T>() where T : IPageView
            {
                Register(typeof(T));
            }

            
            
            
            public static void RegisterFromAssembly(Assembly asm)
            {
                foreach(Type t in asm.GetTypes())
                {
                    if(IsPageType(t))
                        Register(t);
                }
            }

            
            
            
            
            public static bool TryRegisterFromCurrentAssembly()
            {
                Assembly asm = Assembly.GetExecutingAssembly();
                List<Type> found = new List<Type>();

                foreach(Type t in asm.GetTypes())
                {
                    if(IsPageType(t))
                    {
                        Register(t);
                        found.Add(t);
                    }
                }
                PageLogger.LogInfo("Auto-registered " + found.Count + " pages from executing assembly.");

                return found.Count > 0;
            }

            private static bool IsPageType(Type t)
            {
                return typeof(IPageView).IsAssignableFrom(t) && !t.IsAbstract;
            }

            
            
            
            public static void Register(Type pageType)
            {
                if(!IsPageType(pageType))
                    throw new ArgumentException("Type must implement IPageView.", "pageType");

                PageBehaviorAttribute attr =
                    (PageBehaviorAttribute)pageType.GetCustomAttributes(typeof(PageBehaviorAttribute), true)
                        .FirstOrDefault();

                string name = attr != null && attr.NameOverride != null
                    ? attr.NameOverride
                    : pageType.Name;

                if(_registry.ContainsKey(name))
                {
                    PageLogger.LogWarn("Attempt to register duplicate page '" + name + "' ignored.");
                    return;
                }

                PageDescriptor d = new PageDescriptor();
                d.PageType = pageType;
                d.Name = name;
                d.Kind = attr != null ? attr.Kind : PageKind.Default;
                d.CachePolicy = attr != null ? attr.CachePolicy : PageCachePolicy.Disabled;
                d.Timeout = attr != null ? attr.Timeout : TimeoutBehavior.Default;
                if(attr != null && attr.Tags != null)
                {
                    foreach(string s in attr.Tags)
                        d.Tags.Add(s);
                }

                _registry[name] = d;
                PageLogger.LogInfo($"Registered Page '{name}' (Type={pageType.Name}), Kind={d.Kind}, CachePolicy={d.CachePolicy}, Tags=[{string.Join(",", d.Tags.ToArray())}])");

            }

            
            
            

            
            public static void AddTag(string pageName, string tag)
            {
                PageDescriptor d;
                if(_registry.TryGetValue(pageName, out d))
                {
                    d.Tags.Add(tag);
                    PageLogger.LogInfo("Tag '" + tag + "' added to page '" + pageName + "'.");
                }
            }

            
            public static bool HasTag(string pageName, string tag)
            {
                PageDescriptor d;
                return _registry.TryGetValue(pageName, out d) && d.Tags.Contains(tag);
            }

            
            public static IEnumerable<string> GetTags(string pageName)
            {
                PageDescriptor d;
                if(_registry.TryGetValue(pageName, out d))
                    return d.Tags;

                return new string[0];
            }

            
            
            

            
            
            
            public static IPageView FirstByTag(string tag)
            {
                foreach(PageDescriptor d in _registry.Values)
                {
                    if(d.Tags.Contains(tag))
                    {
                        PageLogger.LogInfo("FirstByTag('" + tag + "') resolved page '" + d.Name + "'.");
                        return Resolve(d.PageType, d.Name);
                    }
                }
                PageLogger.LogWarn("FirstByTag('" + tag + "') found no matching page.");

                return null;
            }

            
            
            
            public static IEnumerable<IPageView> AllByTag(string tag)
            {
                foreach(PageDescriptor d in _registry.Values)
                {
                    if(d.Tags.Contains(tag))
                    {
                        PageLogger.LogInfo("AllByTag('" + tag + "') yielding page '" + d.Name + "'.");
                        yield return Resolve(d.PageType, d.Name);
                    }
                }
            }

            
            
            

            
            
            
            public static IPageView Resolve(Type type, string name)
            {
                PageDescriptor info;
                if(!_registry.TryGetValue(name, out info))
                {
                    PageLogger.LogWarn("Resolve('" + name + "') triggered auto-registration.");

                    
                    info = new PageDescriptor();
                    info.Name = name;
                    info.PageType = type;
                    info.Kind = PageKind.Default;
                    info.CachePolicy = PageCachePolicy.Disabled;
                    _registry[name] = info;
                }
                PageLogger.LogInfo("Resolve('" + name + "') using CachePolicy=" + info.CachePolicy);
                switch(info.CachePolicy)
                {
                    case PageCachePolicy.Disabled:
                        return Create(info);

                    case PageCachePolicy.WeakSingleton:
                        if(info.CachedInstance == null)
                            info.CachedInstance = Create(info);
                        return info.CachedInstance;

                    case PageCachePolicy.StrongSingleton:
                        if(info.CachedInstance == null)
                            info.CachedInstance = Create(info);
                        return info.CachedInstance;

                    case PageCachePolicy.Stackable:
                        return PushStack(info);
                }

                return Create(info);
            }
            public static PageDescriptor GetDescriptor(Type type) => _registry.Values.First(x => x.PageType == type);
            private static IPageView Create(PageDescriptor d)
            {
                var page = (IPageView)Activator.CreateInstance(d.PageType);
                PageLogger.LogInfo("Created new instance of page '" + d.Name + "'.");
                return page;
            }
            public static IPageView CreateNew(Type type, string name)
            {
                var info = new PageDescriptor
                {
                    PageType = type,
                    Name = name,
                    Kind = PageKind.Default,
                    CachePolicy = PageCachePolicy.Disabled
                };
                return Create(info);
            }
            private static IPageView PushStack(PageDescriptor d)
            {
                IPageView page = Create(d);
                d.StackInstances.Push(page);
                PageLogger.LogInfo("Stack PUSH for page '" + d.Name + "'. Stack count now: " + d.StackInstances.Count);
                page.OnDetachEvent += async ()=>
                {
                    if(d.StackInstances.Count > 0 &&
                        Object.ReferenceEquals(d.StackInstances.Peek(), page))
                    {
                        await PopStackAsync(d.Name);
                        
                        PageLogger.LogInfo($"Auto Stack POP on detach ('{d.Name}') Stack count now:  {d.StackInstances.Count}");
                    }
                };

                return page;
            }
            public static IPageView ResolveTimeoutTarget()
            {
                
                var byKind = _registry.Values
                    .FirstOrDefault(x => x.Kind == PageKind.Home);

                if(byKind != null)
                    return Resolve(byKind.PageType, byKind.Name);

                
                var byTag = _registry.Values
                    .FirstOrDefault(x => x.Tags.Contains("home", StringComparer.OrdinalIgnoreCase));

                if(byTag != null)
                    return Resolve(byTag.PageType, byTag.Name);

                
                return null;
            }
            
            
            
            public static void PopStack(string name)
            {
                PageDescriptor d;
                if(!_registry.TryGetValue(name, out d))
                    throw new InvalidOperationException("Page '" + name + "' not registered.");

                if(d.CachePolicy != PageCachePolicy.Stackable)
                    throw new InvalidOperationException("Page '" + name + "' is not stackable.");

                if(d.StackInstances.Count > 0)
                {
                    d.StackInstances.Pop();
                    PageLogger.LogInfo($"Manual Stack POP for page '{name}'. New count: {d.StackInstances.Count}");
                }
                else
                {
                    PageLogger.LogWarn($"PopStack('{name}') did nothing (stack empty).");

                }
            }

            public static async Task PopStackAsync(string name)
            {
                var d = _registry[name];

                if(d.CachePolicy != PageCachePolicy.Stackable)
                    throw new InvalidOperationException("Not stackable.");

                if(d.StackInstances.Count == 0)
                    return;

                var page = d.StackInstances.Pop();

                await page.ReleaseResources();
                page.Dispose();
            }

        }
    }

}

namespace PageNav
{
    public static partial class NavigationService
    {
        
        
        
        private static bool _isNavigating;
        
        
        
        
        
        
        
        
        
        
        
        
        
        

        

        
        
        
        

        
        
        
        
        

        
        
        

        
        

        
        
        
        
        
        
        
        
        

        
        

        
        
        
        
        
        
        
        
        
        

        

        private static async Task SwitchInternal(Type pageType, NavigationArgs navArgs)
        {
            if(_isNavigating)
                return; 

            _isNavigating = true;
            Task preloadTask = null;

            if(navArgs.UseMask)
                PageMaskService.Show("Carregando...");

            try
            {  
                async void Safe()
                {
                    
                    
                    
                    if(Current != null)
                    {
                        
                        if(_events != null)
                            _events.DetatchEvent<EventHandler>(Current.NativeView, "Click", TimeoutService.Reset);

                        
                        Current.ChildViewAdded -= OnChildViewAdded;
                        Current.ChildViewRemoved -= OnChildViewRemoved;

                        
                        await CleanupPageAsync(Current);

                        
                        Current.OnDetach();
                        _blocker?.Block(Current);
                    }

                    
                    
                    
                    IPageView newPage = navArgs.UseCache
                        ? PageRegistry.Resolve(pageType, pageType.Name)
                        : PageRegistry.CreateNew(pageType, pageType.Name);

                    PageLoggerService.LogNavigation(Current, newPage, navArgs);

                    
                    
                    
                    newPage.OnAttach(_host);
                    newPage.IsVisible = true;
                    Current = newPage;

                    
                    
                    
                    
                    if(_events != null)
                        _events.AttatchEvent<EventHandler>(newPage.NativeView, "Click", TimeoutService.Reset);

                    
                    newPage.ChildViewAdded += OnChildViewAdded;
                    newPage.ChildViewRemoved += OnChildViewRemoved;

                    
                    
                    
                    await newPage.ReloadAsync(navArgs.Payload);

                    _host.BringToFront(newPage);
                    _blocker?.Unblock(Current);
                }
                async Task Paralel()
                {
                    
                    
                    
                    IPageView newPage = navArgs.UseCache
                        ? PageRegistry.Resolve(pageType, pageType.Name)
                        : PageRegistry.CreateNew(pageType, pageType.Name);

                    PageLoggerService.LogNavigation(Current, newPage, navArgs);

                     
                    
                    
                    
                    preloadTask = newPage.ReloadAsync(navArgs.Payload);

                    

                     
                    
                    
                    
                    if(Current != null)
                    {
                        
                        if(_events != null)
                            _events.DetatchEvent<EventHandler>(Current.NativeView, "Click", TimeoutService.Reset);

                        Current.ChildViewAdded -= OnChildViewAdded;
                        Current.ChildViewRemoved -= OnChildViewRemoved;

                        await CleanupPageAsync(Current);

                        Current.OnDetach();
                        _blocker?.Block(Current);
                    }

                     
                    
                    
                    
                    newPage.OnAttach(_host);
                    newPage.IsVisible = true;
                    Current = newPage;

                     
                    
                    
                    
                    if(_events != null)
                        _events.AttatchEvent<EventHandler>(newPage.NativeView, "Click", TimeoutService.Reset);

                    newPage.ChildViewAdded += OnChildViewAdded;
                    newPage.ChildViewRemoved += OnChildViewRemoved;

                     
                    
                    
                    
                    if(preloadTask != null)
                        await preloadTask;

                    _host.BringToFront(newPage);
                   
                }
                await Paralel();
            }
            finally
            {
                if(navArgs.UseMask)
                    PageMaskService.Hide();
                _blocker?.Unblock(Current);
                _isNavigating = false;
            }
        }

        private static async Task CleanupPageAsync(IPageView page)
        {
            if(page == null) return;

            var desc = PageRegistry.GetDescriptor(page.GetType());

            switch(desc.CachePolicy)
            {
                case PageCachePolicy.Disabled:
                    await page.ReleaseResources();
                    page.Dispose();
                    break;

                case PageCachePolicy.WeakSingleton:
                    await page.ReleaseResources();
                    break;

                case PageCachePolicy.StrongSingleton:
                    
                    break;

                case PageCachePolicy.Stackable:
                    
                    break;
            }
        }

    }
}

namespace PageNav
{
    public static class PageAdapterFactory
    {
        public static IPageHost CreateHost(object nativeHost)
        {

            if(nativeHost is System.Windows.Controls.Panel panelHost) return new Wpf.PageHost(panelHost);
            if(nativeHost is System.Windows.Forms.Control controlHost) return new WinForms.PageHost(controlHost);
            throw new NotSupportedException($"Unsupported host type {nativeHost}");
        }

        public static IPageView CreatePageView(Type type)
        {
            object instance = Activator.CreateInstance(type);
            if(instance is IPageView page) return page;
            throw new InvalidOperationException($"Type {type.Name} does not implement IPageView");
        }
    }
}

namespace PageNav
{
    public readonly struct PageLogEntry
    {
        public readonly string From;
        public readonly string To;
        public readonly DateTime Timestamp;
        public readonly NavigationArgs Args;

        public PageLogEntry(string from, string to, NavigationArgs args)
        {
            From = from;
            To = to;
            Args = args;
            Timestamp = DateTime.Now;
        }
    }
    public static class PageLoggerService
    {
        private static readonly List<PageLogEntry> _entries = new List<PageLogEntry>();

        public static void LogNavigation(IPageView from, IPageView to, NavigationArgs args)
        {
            _entries.Add(new PageLogEntry(
                from?.Name ?? "null",
                to?.Name ?? "null",
                args
            ));
        }

        public static IEnumerable<PageLogEntry> All => _entries;

        public static IEnumerable<PageLogEntry> Last(int count) =>
            _entries.Count <= count ? _entries : _entries.GetRange(_entries.Count - count, count);
    }

        
        
        
        
        public static class PageLogger
        {
            private static readonly object _lock = new object();
            private static string _logPath = "page_registry.log";

            
            
            
            public static void SetLogFile(string path)
            {
                lock(_lock)
                {
                    _logPath = path;
                }
            }

            
            
            
            public static void Log(string category, string message)
            {
                lock(_lock)
                {
                var str = $"[{DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss.fff")}][{category}]{message}\n";
                Console.WriteLine(str);
                    File.AppendAllText(_logPath,str);
                }
            }

            public static void LogInfo(string msg) { Log("INFO", msg); }
            public static void LogWarn(string msg) { Log("WARN", msg); }
            public static void LogError(string msg) { Log("ERROR", msg); }
        }
    

}

namespace PageNav
{
    public static class PageMaskService
    {
        private static IPageMask _mask;

        public static void Initialize(IPageMask mask)
        {
            _mask = mask ?? throw new ArgumentNullException(nameof(mask));
        }

        public static void Show(string message = "")
        {
            _mask?.Show(message);
        }

        public static void Hide()
        {
            _mask?.Hide();
        }
    }
}

namespace PageNav
{
    public static class TimeoutService
    {
        public enum TimeoutBehavior
        {
            Default,
            OverrideHome,
            IgnoreTimeout
        }
        private static ITimerAdapter _timer;
        private static int _ticks;
        private static int _thresholdTicks;

        public static event Action TimeoutReached;

        public static void Initialize(ITimerAdapter timerAdapter, int timeoutSeconds)
        {
            _timer = timerAdapter ?? throw new ArgumentNullException(nameof(timerAdapter));

            
            _thresholdTicks = timeoutSeconds;

            _timer.Start(1000, OnTick); 
        }

        private static void OnTick()
        {
            _ticks++;
            Console.WriteLine("+" + _ticks);
            if(_ticks >= _thresholdTicks)
            {
                _ticks = 0;
                TimeoutReached?.Invoke();
            }
        }

        public static void Reset(object s, EventArgs e) 
        {
            _ticks = 0;
            Console.WriteLine("timer reseted");
        } 

        public static void Pause() => _timer.Stop();

        public static void Continue() => _timer.Start(1000, OnTick);
    }
}

[assembly: AssemblyTitle("PageHandler_legacy481")]
[assembly: AssemblyDescription("")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("")]
[assembly: AssemblyProduct("PageHandler_legacy481")]
[assembly: AssemblyCopyright("Copyright ©  2025")]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyCulture("")]

[assembly: ComVisible(false)]

[assembly: Guid("aa11c4f4-8f95-4afe-98f7-ff816c207194")]

[assembly: AssemblyVersion("1.0.0.0")]
[assembly: AssemblyFileVersion("1.0.0.0")]

namespace PageNav.WinForms
{
    public static class DesignModeTools
    {
        public static bool IsInDesignMode(Control c)
        {
            if(LicenseManager.UsageMode == LicenseUsageMode.Designtime)
                return true;

            while(c != null)
            {
                if(c.Site?.DesignMode == true)
                    return true;

                c = c.Parent;
            }

            return false;
        }
    }
}

namespace PageNav.WinForms
{
    public class PageHost : IPageHost
    {
        private readonly Control _container;

        public PageHost(Control container)
        {
            _container = container;
        }

        public void AddView(object view)
        {
            if(view is Control ctrl)
                _container.Controls.Add(ctrl);
        }

        public void RemoveView(object view)
        {
            if(view is Control ctrl)
                _container.Controls.Remove(ctrl);
        }

        public void BringToFront(object view)
        {
            if(view is Control ctrl)
                ctrl.BringToFront();
        }

        public void Focus(object view)
        {
            if(view is Control ctrl)
                ctrl.Focus();
        }
    }
}

namespace PageNav.WinForms
{
    public class PageView : UserControl, IPageView
    {
        
        private bool _designMode;

        public event Action<object> ChildViewAdded;
        public event Action<object> ChildViewRemoved;
        public event Action OnDetachEvent;
        
        protected PageView()
        {
            _designMode = DesignMode || LicenseManager.UsageMode == LicenseUsageMode.Designtime;

            if(!_designMode)
            {
                
                this.Visible = false;
                this.Dock = DockStyle.Fill;
            }
            
        }

        
        [Browsable(false)]
        public virtual object NativeView => this;

        [Browsable(false)]
        public bool IsVisible { get => this.Visible; set => this.Visible = value; }

        [Browsable(false)]
        public bool IsLocked { get; set; }

        protected override void OnControlAdded(ControlEventArgs e)
        {
            base.OnControlAdded(e);
            ChildViewAdded?.Invoke(e.Control);
        }

        protected override void OnControlRemoved(ControlEventArgs e)
        {
            base.OnControlRemoved(e);
            ChildViewRemoved?.Invoke(e.Control);
        }

        bool IPageView.DesignMode => DesignMode;

        
        public virtual void OnAttach(IPageHost host)
        {
            if(_designMode) return; 
            host.AddView(this);
        }

        public virtual void OnDetach()
        {
            if(_designMode) return;
            OnDetachEvent?.Invoke();
            this.Parent?.Controls.Remove(this);
        }

        public virtual Task ReloadAsync(object args)
        {
            return Task.CompletedTask;
        }

        public virtual void Enable() { if(_designMode) return; }

        public virtual void Disable() { if(_designMode) return; }

        public virtual async Task ReleaseResources() { if(_designMode) return; }

        
        protected override void Dispose(bool disposing)
        {
            if(!_designMode)
                base.Dispose(disposing);
        }
    }
}

namespace PageNav.Wpf
{
    public abstract class PageView : UserControl, IPageView
    {
        protected IPageHost Host;
        public event Action<object> ChildViewAdded;
        public event Action<object> ChildViewRemoved;
        public event Action OnDetachEvent;

        public abstract string Name { get; }

        public bool IsVisible
        {
            get => Visibility == System.Windows.Visibility.Visible;
            set => Visibility = value ? System.Windows.Visibility.Visible : System.Windows.Visibility.Collapsed;
        }

        public bool IsLocked { get; set; }

        public object NativeView => this;

        public bool DesignMode=>false;

        protected override void OnInitialized(EventArgs e)
        {
            base.OnInitialized(e);
            AddLogicalTreeHandlers(this);
        }

        private void AddLogicalTreeHandlers(DependencyObject root)
        {
            this.AddHandler(FrameworkElement.LoadedEvent, new RoutedEventHandler((s, e) =>
            {
                if(e.Source is FrameworkElement fe)
                    ChildViewAdded?.Invoke(fe);
            }));

            this.AddHandler(FrameworkElement.UnloadedEvent, new RoutedEventHandler((s, e) =>
            {
                if(e.Source is FrameworkElement fe)
                    ChildViewRemoved?.Invoke(fe);
            }));
        }
        public virtual void OnAttach(IPageHost host)
        {
            Host = host;
            host.AddView(this);
        }

        public virtual void OnDetach()
        {
            Host?.RemoveView(this);
        }

        public abstract Task ReloadAsync(object args);

        public virtual void Enable() => IsEnabled = true;
        public virtual void Disable() => IsEnabled = false;

        public virtual async Task ReleaseResources()
        {
            
        }

        public abstract void Dispose();
    }
}

namespace PageNav.Wpf
{
    public class PageHost : IPageHost
    {
        private readonly Panel _panel;

        public PageHost(Panel panel)
        {
            _panel = panel;
        }

        public void AddView(object view)
        {
            if(view is UIElement elem)
                _panel.Children.Add(elem);
        }

        public void RemoveView(object view)
        {
            if(view is UIElement elem)
                _panel.Children.Remove(elem);
        }

        public void BringToFront(object view)
        {
            
            if(view is UIElement elem)
                Panel.SetZIndex(elem, 9999);
        }

        public void Focus(object view)
        {
            if(view is UIElement elem)
                elem.Focus();
        }
    }
}

[assembly: global::System.Runtime.Versioning.TargetFrameworkAttribute(".NETFramework,Version=v4.8.1", FrameworkDisplayName = ".NET Framework 4.8.1")]

namespace PageNav.WinForms.Adapters
{
 
    public class EventDispatcherAdapter : IEventDispatcherAdapter
    {
        public void AttatchEvent<THandler>(object reciever, string eventName, THandler handler) where THandler : Delegate
        {
            if(reciever is System.Windows.Forms.Control c)
                AttatchEventInternal(c, eventName, handler);
        }

        public void DetatchEvent<THandler>(object reciever, string eventName, THandler handler) where THandler : Delegate
        {
            if(reciever is System.Windows.Forms.Control c)
                DetatchEventInternal(c, eventName, handler);
        }

        static int i=0;
        private void AttatchEventInternal<THandler>(System.Windows.Forms.Control reciever, string eventName, THandler handler) where THandler : Delegate
        {
            var ev = reciever.GetType().GetEvent(eventName) ?? throw new ArgumentException($"Event not found: {eventName}");
            ev.AddEventHandler(reciever, handler);
            Console.WriteLine($"++{i++}, {ev}");
            foreach(System.Windows.Forms.Control c in reciever.Controls)
                AttatchEventInternal(c, eventName, handler);
        }
        private void DetatchEventInternal<THandler>(System.Windows.Forms.Control reciever, string eventName, THandler handler) where THandler : Delegate
        {
            var ev = reciever.GetType().GetEvent(eventName) ?? throw new ArgumentException($"Event not found: {eventName}");
            ev.RemoveEventHandler(reciever, handler);
            Console.WriteLine($"--{i--}, {ev}");
            foreach(System.Windows.Forms.Control c in reciever.Controls)
                DetatchEventInternal(c, eventName, handler);

        }
    }
}

namespace PageNav.WinForms.Adapters
{
    public class InteractionBlocker : IInteractionBlocker
    {
        public void Block(object view)
        {
            if(view is System.Windows.Forms.Control c)
                SetChildrenEnabled(c, false);
        }

        public void Unblock(object view)
        {
            if(view is System.Windows.Forms.Control c)
                SetChildrenEnabled(c, true);
        }

        private void SetChildrenEnabled(System.Windows.Forms.Control c, bool state)
        {
            foreach(System.Windows.Forms.Control child in c.Controls)
                child.Enabled = state;
        }
    }
}

namespace PageNav.WinForms.Adapters
{
    public class PageMaskAdapter : IPageMask
    {
        private readonly Panel _mask = new Panel();
        private readonly Label _label = new Label();

        public PageMaskAdapter(Control host)
        {
            
            _mask.BackColor = Color.FromArgb(180, Color.Black); 
            _mask.Dock = DockStyle.Fill;
            _mask.Visible = false;

            _label.Dock = DockStyle.Fill;
            _label.TextAlign = ContentAlignment.MiddleCenter;
            _label.ForeColor = Color.White;
            _label.Font = new Font("Segoe UI", 16, FontStyle.Bold);

            _mask.Controls.Add(_label);
            host.Controls.Add(_mask);
            _mask.BringToFront();
        }

        public void Show(string message = "")
        {
            _label.Text = message;
            _mask.Visible = true;
            _mask.BringToFront();
        }

        public void Hide()
        {
            _mask.Visible = false;
        }
    }

}

namespace PageNav.WinForms.Adapters
{
    public class TimerAdapter : ITimerAdapter
    {
        private Timer _timer;
        private Action _tick;

        public void Start(int intervalMilliseconds, Action tick)
        {
            _tick = tick;

            _timer = new Timer();
            _timer.Interval = intervalMilliseconds;
            _timer.Tick -= TimerTick;
            _timer.Tick += TimerTick;
            _timer.Start();
        }

        private void TimerTick(object sender, EventArgs e) => _tick?.Invoke();

        public void Stop() => _timer?.Stop();

        public void Dispose() => _timer?.Dispose();
    }
}

namespace PageNav.Wpf.Adapters
{
    public class EventDispatcherAdapter : IEventDispatcherAdapter
    {
        public void AttatchEvent<THandler>(object receiver, string eventName, THandler handler)
           where THandler : Delegate
        {
            if(receiver is DependencyObject d)
                AttatchEventInternal(d, eventName, handler);
        }

        public void DetatchEvent<THandler>(object receiver, string eventName, THandler handler)
            where THandler : Delegate
        {
            if(receiver is DependencyObject d)
                DetatchEventInternal(d, eventName, handler);
        }

        
        
        

        private void AttatchEventInternal<THandler>(DependencyObject receiver, string eventName, THandler handler)
            where THandler : Delegate
        {
            AttachSingle(receiver, eventName, handler);

            int count = VisualTreeHelper.GetChildrenCount(receiver);
            for(int i = 0; i < count; i++)
            {
                var child = VisualTreeHelper.GetChild(receiver, i);
                AttatchEventInternal(child, eventName, handler);
            }
        }

        private void DetatchEventInternal<THandler>(DependencyObject receiver, string eventName, THandler handler)
            where THandler : Delegate
        {
            DetachSingle(receiver, eventName, handler);

            int count = VisualTreeHelper.GetChildrenCount(receiver);
            for(int i = 0; i < count; i++)
            {
                var child = VisualTreeHelper.GetChild(receiver, i);
                DetatchEventInternal(child, eventName, handler);
            }
        }

        
        
        

        private void AttachSingle<THandler>(DependencyObject obj, string eventName, THandler handler)
            where THandler : Delegate
        {
            
            var targetType = obj.GetType();
            var ev = targetType.GetEvent(eventName);

            if(ev != null)
            {
                try
                {
                    ev.AddEventHandler(obj, handler);
                }
                catch(Exception ex)
                {
                    throw new Exception($"Failed attaching event '{eventName}' on {targetType.Name}: {ex.Message}", ex);
                }
            }
        }
        private void DetachSingle<THandler>(DependencyObject obj, string eventName, THandler handler)
            where THandler : Delegate
        {
            var targetType = obj.GetType();
            var ev = targetType.GetEvent(eventName);

            if(ev != null)
            {
                try
                {
                    ev.RemoveEventHandler(obj, handler);
                }
                catch(Exception ex)
                {
                    throw new Exception($"Failed detaching event '{eventName}' on {targetType.Name}: {ex.Message}", ex);
                }
            }
        }
    }
}

 

namespace PageNav.Wpf.Adapters
{
    public class InteractionBlocker : IInteractionBlocker
    {
        public void Block(object view)
        {
            if(view is UIElement e)
                e.IsEnabled = false;
        }

        public void Unblock(object view)
        {
            if(view is UIElement e)
                e.IsEnabled = true;
        }
    }
}

namespace PageNav.Wpf.Adapters
{
    public class PageMaskAdapter : IPageMask
    {
        private readonly Grid _overlay;
        private readonly TextBlock _text;

        public PageMaskAdapter(Panel host)
        {
            _overlay = new Grid
            {
                Background = new SolidColorBrush(Color.FromArgb(160, 0, 0, 0)),
                Visibility = Visibility.Collapsed
            };

            _text = new TextBlock
            {
                HorizontalAlignment = HorizontalAlignment.Center,
                VerticalAlignment = VerticalAlignment.Center,
                TextAlignment = TextAlignment.Center,
                Foreground = Brushes.White,
                FontSize = 22,
                FontWeight = FontWeights.Bold
            };

            _overlay.Children.Add(_text);

            
            host.Children.Add(_overlay);

            
            if(host is Grid)
            {
                Grid.SetRowSpan(_overlay, int.MaxValue);
                Grid.SetColumnSpan(_overlay, int.MaxValue);
            }
        }

        public void Show(string message = "")
        {
            _text.Text = message;
            _overlay.Visibility = Visibility.Visible;
        }

        public void Hide()
        {
            _overlay.Visibility = Visibility.Collapsed;
        }
    }

}

namespace PageNav.Wpf.Adapters
{
    public class TimerAdapter : ITimerAdapter
    {
        private DispatcherTimer _timer;
        private Action _tick;

        public void Start(int intervalMilliseconds, Action tick)
        {
            _tick = tick;
            _timer = new DispatcherTimer();
            _timer.Interval = TimeSpan.FromMilliseconds(intervalMilliseconds);
            _timer.Tick -= TimerTick;
            _timer.Tick += TimerTick;
            _timer.Start();
        }

        private void TimerTick(object s, EventArgs e) => _tick?.Invoke();

        public void Stop() => _timer.Stop();

        public void Dispose() => _timer.Stop();
    }
}

