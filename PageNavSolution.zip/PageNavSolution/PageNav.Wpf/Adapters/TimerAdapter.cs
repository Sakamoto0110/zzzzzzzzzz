﻿using PageNav;
using PageNav.Core.Abstractions;
using System;
using System.Windows.Threading;

namespace PageNav.Wpf.Adapters
{
    public class TimerAdapter : ITimerAdapter
    {
        private DispatcherTimer _timer;
        private Action _tick;

        public void Start(int intervalMilliseconds, Action tick)
        {
            _tick = tick;
            _timer = new DispatcherTimer();
            _timer.Interval = TimeSpan.FromMilliseconds(intervalMilliseconds);
            _timer.Tick -= TimerTick;
            _timer.Tick += TimerTick;
            _timer.Start();
        }

        private void TimerTick(object s, EventArgs e) => _tick?.Invoke();

        public void Stop() => _timer.Stop();

        public void Dispose() => _timer.Stop();
    }
}