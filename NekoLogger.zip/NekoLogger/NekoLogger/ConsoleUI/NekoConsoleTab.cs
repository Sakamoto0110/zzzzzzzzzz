﻿using NekoLogger.Abstractions;
using NekoLogger.Core;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml.Linq;

namespace NekoLogger.ConsoleUI
{

    public partial class NekoConsoleTab : UserControl, IConsoleTabView, ILogCollector
    {


        private bool _AllowZoom = true;
        private bool _AllowInput = true;
        private bool _ShowBottomMenu = true;

        public bool ShowBottomMenu
        {
            get => _ShowBottomMenu;
            set
            {
                if(_ShowBottomMenu != value)
                {
                    SuspendLayout();
                    _ShowBottomMenu = BottomMenu.Visible = value;
                    Invalidate(true);
                    Refresh();
                    ResumeLayout(true);
                }
            }
        }

        public bool AllowZoom
        {
            get => _AllowZoom;
            set
            {
                if(_AllowZoom != value)
                {
                    SuspendLayout();
                    _AllowZoom = ZoomTrackbar.Visible = value;
                    Invalidate(true);
                    Refresh();
                    ResumeLayout(true);
                }
            }
        }

        public bool AllowInput
        {
            get => _AllowInput;
            set
            {
                SuspendLayout();
                _AllowInput = value;
                Input.Visible = Input.Enabled = value;
                Invalidate(true);
                Refresh();
                ResumeLayout(true);
            }
        }



        private float zoomFactor = 3.3f / 50;
        private int MaxLines = 20;
        private string[] _AllowedTags = null;
        public string[] AllowedTags
        {
            get => _AllowedTags ?? new[] { "all" };
            set => _AllowedTags = value;
        }
        public delegate void SafeInvoke(object sender, LoggerEventArgs e);



        public NekoConsoleTab()
        {

            InitializeComponent();
            ZoomTrackbar.ValueChanged += (s, e) => Output.ZoomFactor = ZoomTrackbar.Value * zoomFactor;
            Output.TextChanged += (s, e) => Output.ScrollToCaret();
            Logger.AddCollector(this);
        }
        //public NekoConsoleTab(Control owner, string name, string[] logType = null)
        //{
        //    InitializeComponent();
        //    ZoomTrackbar.ValueChanged += (s, e) => Output.ZoomFactor = ZoomTrackbar.Value * zoomFactor;
        //    Output.TextChanged += (s, e) => Output.ScrollToCaret();
        //    AllowedTags = logType ?? new string[] { "ALL" };

        //    owner.Controls.Add(Panel);

        //}




        public void OnLogReceived(object sender, LoggerEventArgs e)
        {
            var entry = new[]
            {
                string.IsNullOrEmpty(e.TimeString) ? "" : $"[{e.TimeString}]",
                string.IsNullOrEmpty(e.Prefix) ? "" : $"[{e.Prefix}]",
                e.Sender == null ? "" : $"[{e.Sender}]",
                string.IsNullOrEmpty(e.Message) ? "" : $"{e.Message}",
                "\n"
            };
            Output.SelectionColor = e.Color;
            if(e.Tags.Any(f => f.Equals("ALL", StringComparison.OrdinalIgnoreCase)))
                Output.SelectedText = string.Join(" ", entry);
            else if(e.Tags.Any(tag => AllowedTags.Any(f => string.Equals(f, tag, StringComparison.OrdinalIgnoreCase))))
                Output.SelectedText = string.Join(" ", entry);
        }
    }
}

