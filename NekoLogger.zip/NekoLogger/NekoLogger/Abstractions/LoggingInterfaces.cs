﻿using NekoLogger.Core;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NekoLogger.Abstractions
{
    public interface IConsoleTabView
    {
        bool AllowZoom { get; set; }
        bool AllowInput { get; set; }
        bool ShowBottomMenu { get; set; }
    }
    public interface ILogCollector
    {
        void OnLogReceived(object sender, LoggerEventArgs e);
    }
    public interface ILoggerDestination
    {
        void Write(LoggerEventArgs e);
    }
    public interface ILoggerHandler
    {
        void Log(object content, Func<object, string> ToStringOverride = null, Severity severity = Severity.Info, string[] tags = null);
        void LogEx(object sender, object content, Func<object, string> ToStringOverride = null, Severity severity = Severity.Info, string[] tags = null);
    }
    public interface ILogProducer
    {
        ILoggerHandler Logger { get; set; }
    }
    public interface INekoConsoleWindow
    {
        IConsoleTabView ActiveWindow { get; }
        void Show();
        void Hide();
    }














}
