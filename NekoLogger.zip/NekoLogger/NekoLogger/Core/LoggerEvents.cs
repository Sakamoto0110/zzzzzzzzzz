﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NekoLogger.Core
{
    public class LoggerEventArgs : EventArgs
    {
        public Severity Severity { get; set; }
        public Color Color { get; set; }
        public string Prefix { get; set; }
        public string Message { get; set; }
        public string[] Tags { get; set; }
        public object Sender { get; set; }
        public DateTime Timestamp { get; private set; }

        public string TimeString => Timestamp.ToString("HH:mm:ss");

        public string FullMessage =>
            $"[{TimeString}] [{Prefix}] {Message}";

        public LoggerEventArgs()
        {
            Timestamp = DateTime.Now;
        }
    }
    public class LoggerEventHandler
    {

        private static LoggerEventHandler loggerEventHandler = null;

        public List<string> LogBuffer = new List<string>();

        private LoggerEventHandler()
        {

        }


        public static LoggerEventHandler GetHandler()
        {
            loggerEventHandler = loggerEventHandler ?? new LoggerEventHandler();
            return loggerEventHandler;
        }
        public void Handle(EventHandler<LoggerEventArgs> @event, object sender, LoggerEventArgs e)
        {



            @event?.Invoke(sender, e);
        }

    }
}
