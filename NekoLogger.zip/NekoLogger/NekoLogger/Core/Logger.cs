﻿
using NekoLogger.Abstractions;
using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NekoLogger.Core
{
    public enum Severity
    {

        Info,
        Warn,
        Done,
        Error,
        Unknown,
    }

    public static class Logger
    {
        private static readonly Dictionary<Severity, Color> severityColors = new Dictionary<Severity, Color>()
        {
            { Severity.Info, SystemColors.ControlText },
            { Severity.Done, Color.Green },
            { Severity.Warn, Color.DarkOrange },
            { Severity.Error, Color.Red },
            { Severity.Unknown, SystemColors.GrayText }
        };

        private static event EventHandler<LoggerEventArgs> _collectors;
        private static readonly List<ILoggerDestination> _destinations = new List<ILoggerDestination>();
        private static readonly object _lock = new object();
        public static void AddCollector(ILogCollector collector) => _collectors += collector.OnLogReceived;
        public static void RemoveCollector(ILogCollector collector) => _collectors -= collector.OnLogReceived;
        public static void AddDestination(ILoggerDestination dest)
        {
            lock(_lock)
            {
                if(!_destinations.Contains(dest))
                    _destinations.Add(dest);
            }
        }

        public static void RemoveDestination(ILoggerDestination dest)
        {
            lock(_lock)
            {
                _destinations.Remove(dest);
            }
        }

        public static void Log(object content, Func<object, string> toStringOverride = null, Severity severity = Severity.Info, string[] tags = null)
        {
            Log(null, content, toStringOverride, severity, tags);
        }

        public static void Log(object sender, object content, Func<object, string> toStringOverride = null, Severity severity = Severity.Info, string[] tags = null)
        {
            string msg = toStringOverride != null ? toStringOverride(content) : content?.ToString();

            var args = new LoggerEventArgs()
            {
                Sender = sender,
                Severity = severity,
                Color = severityColors[severity],
                Prefix = severity.ToString().ToUpper(),
                Message = msg,
                Tags = tags ?? new[] { "ALL" }
            };

            Dispatch(args);
        }

         
        private static void Dispatch(LoggerEventArgs args)
        {
            // UI Collectors
            _collectors?.Invoke(args.Sender, args);

            // Destinations
            ILoggerDestination[] copy;
            lock(_lock)
            {
                copy = _destinations.ToArray();
            }

            foreach(var dest in copy)
            {
                try { dest.Write(args); } catch { /* prevent crashes */ }
            }
        }

        //public static class ToStringOverloads
        //{
        //    public static string IntArray(object o)
        //    {
        //        var str = "";
        //        if(o is int[] _index)
        //            foreach(int i in _index)
        //                str += $"[{i}]";
        //        else
        //            str = "Invalid conversion";
        //        return str;
        //    }
        //}
        //private static event EventHandler<LoggerEventArgs> OnLog;
        //public static void AttachLogCollector(ILogCollector target) => OnLog += new EventHandler<LoggerEventArgs>(target.DumpLog);
        //public static void DetachLogCollector(ILogCollector target) => OnLog -= target.DumpLog;

        //public static void FlushEventList()
        //{
        //    Delegate[] EventList = OnLog.GetInvocationList();
        //    int n = EventList.Length;
        //    for(int i = 0; i < n; i++)
        //        OnLog -= (EventHandler<LoggerEventArgs>)EventList[i];

        //}//}

        //private static Dictionary<Severity, Color> keyValues = new Dictionary<Severity, Color>()
        //{
        //    { Severity.Info, SystemColors.ControlText},
        //    { Severity.Done, Color.Green },
        //    { Severity.Error, Color.Red },
        //    { Severity.Warn, Color.DarkOrange },
        //    { Severity.Unknow, SystemColors.GrayText },

        //};
        //public static void Log(object content, Func<object, string> ToStringOverride = null, Severity severity = Severity.Info, string[] tags = null)
        //{
        //    string msg = "";

        //    if(ToStringOverride == null)
        //        msg = $"{content}";
        //    else
        //        msg = ToStringOverride?.Invoke(content);
        //    tags = tags ?? new string[] { "ALL" };
        //    var args = new LoggerEventArgs()
        //    {
        //        AllowedTags = severity,
        //        TextColor = keyValues[severity],
        //        Prefix = $"{severity}".ToUpper(),
        //        Message = msg,
        //        Tags = tags,
        //    };
        //    OnLog?.Invoke(null, args);
        //}
        //public static void Log(object sender, object content, Func<object, string> ToStringOverride = null, Severity severity = Severity.Info, string[] tags = null)
        //{
        //    string msg = "";

        //    if(ToStringOverride == null)
        //        msg = $"{content}";
        //    else
        //        msg = ToStringOverride?.Invoke(content);
        //    tags = tags ?? new string[] { "ALL" };
        //    var args = new LoggerEventArgs()
        //    {
        //        AllowedTags = severity,
        //        TextColor = keyValues[severity],
        //        Prefix = $"{severity}".ToUpper(),
        //        Message = msg,
        //        Sender = sender,
        //        Tags = tags,
        //    };
        //    OnLog?.Invoke(sender, args);

        



    }


}