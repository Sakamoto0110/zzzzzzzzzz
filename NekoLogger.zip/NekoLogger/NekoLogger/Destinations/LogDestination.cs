﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NekoLogger.Destinations
{
    public abstract class LogDestination
    {
        protected LogDestination() { }
        protected LogDestination(params string[] tags) { AllowedTags = tags; }
        public string[] AllowedTags { get; set; }


    }
}
