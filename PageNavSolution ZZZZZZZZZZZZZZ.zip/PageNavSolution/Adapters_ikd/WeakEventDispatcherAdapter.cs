﻿//using PageNav.Core.Abstractions;
//using System;
//using System.Collections.Generic;
//using System.Linq;
//using System.Reflection;
//using System.Text;
//using System.Threading.Tasks;

//namespace PageNav.Core.Adapters
//{
    //public sealed class WeakEventDispatcherAdapter : IEventDispatcherAdapter
    //{
    //    private class WeakHandler
    //    {
    //        public WeakReference Receiver;
    //        public WeakReference Handler;
    //        public EventInfo EventInfo;
    //        public Delegate Proxy;
    //    }

    //    private readonly List<WeakHandler> _handlers = new List<WeakHandler>();
    //    private readonly object _lock = new object();

    //    public  void AttatchEvent<THandler>(object receiver, string eventName, THandler handler) where THandler : Delegate
    //    {
    //        if(receiver == null || handler==null) return; 
    //        var ev = receiver.GetType().GetEvent(eventName);

    //        // Create a proxy delegate that routes calls to the weak instance
    //        Delegate proxy = CreateProxy(ev.EventHandlerType, handler);

    //        lock(_lock)
    //        {
    //            _handlers.Add(new WeakHandler
    //            {
    //                Receiver = new WeakReference(receiver),
    //                Handler = new WeakReference(handler),
    //                EventInfo = ev,
    //                Proxy = proxy
    //            });
    //        }

    //        ev.AddEventHandler(receiver, proxy);
    //    }

      
    //    public   void DetatchEvent<THandler>(object receiver, string eventName, THandler handler) where THandler : Delegate

    //    {
    //        lock(_lock)
    //        {
    //            var target = _handlers.FirstOrDefault(x =>
    //                x.Receiver.Target == receiver &&
    //                x.EventInfo.Name == eventName &&
    //                x.Handler.Target == (object)handler);

    //            if(target == null) return;

    //            target.EventInfo.RemoveEventHandler(receiver, target.Proxy);
    //            _handlers.Remove(target);
    //        }
    //    }

    //    private Delegate CreateProxy(Type eventType, Delegate originalHandler)
    //    {
    //        return Delegate.CreateDelegate(eventType, this,
    //            GetType().GetMethod(nameof(InvokeWeak), BindingFlags.NonPublic | BindingFlags.Instance)
    //            .MakeGenericMethod(originalHandler.GetType()));
    //    }

    //    private void InvokeWeak<THandler>(object sender, EventArgs e) where THandler : Delegate
    //    {
    //        CleanupDead();

    //        lock(_lock)
    //        {
    //            foreach(var entry in _handlers.ToArray())
    //            {
                    
    //                if(entry.Handler.IsAlive && entry.Handler.Target != null )
    //                {
    //                    ((Delegate)entry.Handler.Target).DynamicInvoke(sender, e);
    //                }
    //            }
    //        }
    //    }

    //    private void CleanupDead()
    //    {
    //        lock(_lock)
    //        {
    //            _handlers.RemoveAll(h => !h.Receiver.IsAlive || !h.Handler.IsAlive);
    //        }
    //    }
    //}
//}
