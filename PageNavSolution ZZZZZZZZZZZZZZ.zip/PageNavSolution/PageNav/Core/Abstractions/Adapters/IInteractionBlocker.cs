﻿namespace PageNav.Core.Abstractions
{
    public interface IInteractionBlocker
    {
        void Block(object view);
        void Unblock(object view);
    }
}
