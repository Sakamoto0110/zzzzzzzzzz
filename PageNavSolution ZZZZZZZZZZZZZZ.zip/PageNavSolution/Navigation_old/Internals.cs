﻿using PageNav.Core.Abstractions;
using PageNav.Core.Models;
using PageNav.Diagnostics;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
 

namespace PageNav.Core.Services.Navigation
{
    public static partial class NavigationService
    {
        // -------------------------------------------------------------------------
        // INTERNAL CORE NAVIGATION LOGIC
        // -------------------------------------------------------------------------     
        private static bool _isNavigating;



        private static async Task SwitchInternal(Type pageType, NavigationArgs navArgs, bool recordHistory = true)
        {
            if(_host == null)
                throw new InvalidOperationException("NavigationService.Initialize must be called before switching pages.");
            if(_isNavigating)
                return; // Or: throw; or queue logic depending on app philosophy.

            _isNavigating = true;
            Task preloadTask = null;
            IPageView fromPage = Current;
            if(navArgs.UseMask)
                PageMaskService.Show("Carregando...");
            PageDescriptor desc = PageRegistry.GetDescriptor(pageType);
            TimeoutService.Reset(fromPage, EventArgs.Empty);

            try
            {
                // ---------------------------------------------------------
                // 1) Construct or resolve target page FIRST
                // ---------------------------------------------------------
                Navigating?.Invoke(Current, pageType, navArgs);
                //IPageView newPage = navArgs.UseCache ? PageRegistry.Resolve(pageType, pageType.Name) : 
                //                                       PageRegistry.CreateNew(pageType, pageType.Name);
                IPageView newPage = PageRegistry.Resolve(pageType, pageType.Name);
                PageLoggerService.LogNavigation(Current, newPage, navArgs);


                // ---------------------------------------------------------
                // 2) Start loading its data IN PARALLEL (but not awaited yet)
                // ---------------------------------------------------------
                newPage.IsVisible = false;
                switch(desc.WaitCompletionBeforeShow)
                {
                    case NavigationLoadMode.LoadBeforeShow:
                        await newPage.Reload(navArgs.Payload);
                        break;

                    case NavigationLoadMode.LoadInBackground:
                        _ = Task.Run(() => newPage.Reload(navArgs.Payload));
                        break;

                    case NavigationLoadMode.ShowImmediately:
                    default:
                        preloadTask = newPage.Reload(navArgs.Payload);
                        break;
                }
                // (We do NOT await yet.)


                // ---------------------------------------------------------
                // 3) Cleanup old page while new page is preparing
                // ---------------------------------------------------------
                if(Current != null)
                {
                    // detach events from old page
                    if(_events != null)
                        _events.DetatchEvent<EventHandler>(Current.NativeView, "Click", TimeoutService.Reset);

                    Current.ChildViewAdded -= OnChildViewAdded;
                    Current.ChildViewRemoved -= OnChildViewRemoved;

                    await CleanupPageAsync(Current);

                    Current.OnDetach();
                    _blocker?.Block(Current);
                }


                // ---------------------------------------------------------
                // 4) Attach the new page to UI
                // ---------------------------------------------------------
                newPage.OnAttach(_host);
                newPage.IsVisible = true;
                Current = newPage;



                // ---------------------------------------------------------
                // 5) Hook events AFTER attaching
                // ---------------------------------------------------------
                if(_events != null)
                    _events.AttatchEvent<EventHandler>(newPage.NativeView, "Click", TimeoutService.Reset);

                newPage.ChildViewAdded += OnChildViewAdded;
                newPage.ChildViewRemoved += OnChildViewRemoved;


                // ---------------------------------------------------------
                // 6) Now we await the preload safely
                // ---------------------------------------------------------
                //if(preloadTask != null)
                //   await preloadTask.ContinueWith((t)=> {
                //        if(navArgs.UseMask)
                //            PageMaskService.Hide();
                //            });

                _host.BringToFront(newPage);

                if(ReferenceEquals(Current, newPage))
                    CurrentChanged?.Invoke(Current);
                else throw new Exception("Navigation failed");
                //History.RecordNavigation(Current, newPage);
                if(recordHistory && fromPage != null)
                {
                    History.Record(fromPage);
                    HistoryChanged?.Invoke();
                }

            }
            catch(Exception ex) { NavigationFailed?.Invoke(fromPage, pageType, ex); }
            finally
            {
                if(navArgs.UseMask)
                    PageMaskService.Hide();
                _blocker?.Unblock(Current);
                _isNavigating = false;
            }
        }



        private static async Task CleanupPageAsync(IPageView page)
        {
            if(page == null) return;

            var desc = PageRegistry.GetDescriptor(page.GetType());

            switch(desc.CachePolicy)
            {
                case PageCachePolicy.Disabled:
                    await page.ReleaseResources();
                    page.Dispose();
                    break;

                case PageCachePolicy.WeakSingleton:
                    await page.ReleaseResources();
                    break;

                case PageCachePolicy.StrongSingleton:
                    // Keep intact — do nothing
                    break;

                case PageCachePolicy.Stackable:
                    // Cleanup only when popped
                    break;
            }
        }


    }
}
