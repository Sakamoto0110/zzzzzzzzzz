﻿using PageNav.Core.Abstractions;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PageNav.WinForms.Adapters
{
    public class InteractionBlocker : IInteractionBlocker
    {
        public void Block(object view)
        {
            if(view is System.Windows.Forms.Control c)
                SetChildrenEnabled(c, false);
        }

        public void Unblock(object view)
        {
            if(view is System.Windows.Forms.Control c)
                SetChildrenEnabled(c, true);
        }

        private void SetChildrenEnabled(System.Windows.Forms.Control c, bool state)
        {
            foreach(System.Windows.Forms.Control child in c.Controls)
                child.Enabled = state;
        }
    }
}
