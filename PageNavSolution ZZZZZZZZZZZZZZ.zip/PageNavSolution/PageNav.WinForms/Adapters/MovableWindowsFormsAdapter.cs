﻿using PageNav.Core.Abstractions;
using System;
using System.Collections.Generic;
using System.Drawing;
using System.Windows.Forms;

namespace PageNav.WinForms.Adapters
{
    public sealed class MovableWindowsFormsAdapter : IMovableAdapter
    {
        private class HandlerSet
        {
            public MouseEventHandler MouseDown;
            public MouseEventHandler MouseMove;
            public MouseEventHandler MouseUp;
            public ControlEventHandler ControlAdded;
            public ControlEventHandler ControlRemoved;
        }

        private readonly Dictionary<Control, HandlerSet> _handlerMap = new Dictionary<Control, HandlerSet>();

        public void MakeMovable(object view)
        {
            if(!(view is Control ctrl))
                throw new ArgumentException("WinForms movable target must be a Control.");

            if(_handlerMap.ContainsKey(ctrl))
                return;

            Point offset = Point.Empty;
            bool isDragging = false;

            var handlers = new HandlerSet();

            handlers.MouseDown = (s, e) => {
                if(e.Button == MouseButtons.Left)
                {
                    isDragging = true;
                    offset = ctrl.PointToClient(Control.MousePosition);
                }
            };

            handlers.MouseMove = (s, e) => {
                if(!isDragging || ctrl.Parent == null) return;

                var mousePos = ctrl.Parent.PointToClient(Control.MousePosition);
                int x = mousePos.X - offset.X;
                int y = mousePos.Y - offset.Y;

                x = Math.Max(0, Math.Min(x, ctrl.Parent.ClientSize.Width - ctrl.Width));
                y = Math.Max(0, Math.Min(y, ctrl.Parent.ClientSize.Height - ctrl.Height));

                ctrl.Location = new Point(x, y);
            };

            handlers.MouseUp = (s, e) => {
                if(e.Button == MouseButtons.Left)
                    isDragging = false;
            };

            handlers.ControlAdded = (s, e) => AttachHandlers(e.Control, handlers);
            handlers.ControlRemoved = (s, e) => DetachHandlers(e.Control, handlers);

            AttachHandlers(ctrl, handlers);

            ctrl.ControlAdded += handlers.ControlAdded;
            ctrl.ControlRemoved += handlers.ControlRemoved;

            _handlerMap[ctrl] = handlers;
        }

        public void RemoveMovable(object view)
        {
            if(!(view is   Control ctrl)) return;

            if(!_handlerMap.TryGetValue(ctrl, out var handlers))
                return;

            DetachHandlers(ctrl, handlers);
            ctrl.ControlAdded -= handlers.ControlAdded;
            ctrl.ControlRemoved -= handlers.ControlRemoved;

            _handlerMap.Remove(ctrl);
        }

        private void AttachHandlers(Control parent, HandlerSet handlers)
        {
            parent.MouseDown += handlers.MouseDown;
            parent.MouseMove += handlers.MouseMove;
            parent.MouseUp += handlers.MouseUp;

            foreach(Control child in parent.Controls)
                AttachHandlers(child, handlers);
        }

        private void DetachHandlers(Control parent, HandlerSet handlers)
        {
            parent.MouseDown -= handlers.MouseDown;
            parent.MouseMove -= handlers.MouseMove;
            parent.MouseUp -= handlers.MouseUp;

            foreach(Control child in parent.Controls)
                DetachHandlers(child, handlers);
        }
    }
}
