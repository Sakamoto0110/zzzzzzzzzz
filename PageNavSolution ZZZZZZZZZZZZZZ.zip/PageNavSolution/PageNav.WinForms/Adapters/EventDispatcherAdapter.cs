﻿using PageNav.Core.Abstractions;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PageNav.WinForms.Adapters
{
 
    public class EventDispatcherAdapter : IEventDispatcherAdapter
    {

        protected readonly Dictionary<object, HashSet<string>> _attachedEvents = new Dictionary<object, HashSet<string>>();
        protected readonly static Dictionary<(Type, string), EventInfo> _eventCache = new Dictionary<(Type, string), EventInfo>();
       
        public void AttatchEvent<THandler>(object reciever, string eventName, THandler handler) where THandler : Delegate
        {
            if(reciever is System.Windows.Forms.Control c)
                AttatchEventInternal(c, eventName, handler);
        }

        public void DetatchEvent<THandler>(object reciever, string eventName, THandler handler) where THandler : Delegate
        {
            if(reciever is System.Windows.Forms.Control c)
                DetatchEventInternal(c, eventName, handler);
        }



     
        private void AttatchEventInternal<THandler>(System.Windows.Forms.Control reciever, string eventName, THandler handler) where THandler : Delegate
        {
            if(!_attachedEvents.TryGetValue(reciever, out var events))
                _attachedEvents[reciever] = events = new HashSet<string>();

            // Prevent duplicate binding
            if(events.Contains(eventName))
                return;

            var ev = GetEvent(reciever.GetType(), eventName);
            ev.AddEventHandler(reciever, handler);
            events.Add(eventName);

           
            foreach(System.Windows.Forms.Control c in reciever.Controls)
                AttatchEventInternal(c, eventName, handler);
        }
        private void DetatchEventInternal<THandler>(System.Windows.Forms.Control reciever, string eventName, THandler handler) where THandler : Delegate
        {
            if(_attachedEvents.TryGetValue(reciever, out var events) && events.Contains(eventName))
            {
                var ev = GetEvent(reciever.GetType(), eventName);
                ev.RemoveEventHandler(reciever, handler);
                events.Remove(eventName);

                if(events.Count == 0)
                    _attachedEvents.Remove(reciever);
            }

            foreach(Control child in reciever.Controls)
                DetatchEventInternal(child, eventName, handler);

        }
        protected EventInfo GetEvent(Type type, string name)
        {
            if(!_eventCache.TryGetValue((type, name), out var info))
            {
                info = type.GetEvent(name)
                    ?? throw new ArgumentException($"Event '{name}' not found on type '{type.Name}'.");
                _eventCache[(type, name)] = info;
            }
            return info;
        }
    }
}
