﻿using PageNav.Core.Abstractions;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PageNav.WinForms
{
    public class PageHost : IPageHost
    {
        private readonly Control _container;

        public PageHost(Control container)
        {
            _container = container;
        }

        public void AddView(object view)
        {
            if(view is Control ctrl)
                _container.Controls.Add(ctrl);
        }

        public void RemoveView(object view)
        {
            if(view is Control ctrl)
                _container.Controls.Remove(ctrl);
        }

        public void BringToFront(object view)
        {
            if(view is Control ctrl)
                ctrl.BringToFront();
        }

        public void Focus(object view)
        {
            if(view is Control ctrl)
                ctrl.Focus();
        }
    }
}
