﻿using PageNav.Core.Services;
using PageNav.WinForms;
using PageNav.WinForms;
using System.Threading.Tasks;
using System.Windows.Forms;

[PageBehavior(PageKind.Default, PageCachePolicy.WeakSingleton, Tags = new[] { "Tag" },Timeout = TimeoutService.TimeoutBehavior.IgnoreTimeout)]

public class PageB : PageView
{
 
    public PageB()
    {
        Name = "Páge b";
        this.BackColor = System.Drawing.Color.LightGreen;
        this.Controls.Add(new Label { Text = "PAGE B", AutoSize = true, Font = new System.Drawing.Font("Segoe UI", 16F) });

        this.Controls.Add(new Button());
        this.Controls.Add(new Button());
        this.Controls.Add(new Button());
    }

    public override Task Reload(object args)
    {
        return Task.CompletedTask;
    }
}
