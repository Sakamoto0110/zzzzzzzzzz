﻿using PageNav;
using PageNav.Core.Services;
using PageNav.WinForms.Adapters;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Dummy
{
    public partial class Form1 : Form
    {
        private Panel winFormsHostPanel;
        private Button btnPageA;
        private Button btnPageB;
        private Button btnPageC;
        void PostInit()
        {
            // NAV INIT
            NavigationService.Initialize(winFormsHostPanel,10);

            if(PageRegistry.TryRegisterFromCurrentAssembly())
            {
                Console.WriteLine("ok");
            }
            else
            {
                Console.WriteLine("not ok");
            }
                // EVENT dispatcher
    

            // NAV BUTTONS
            btnPageA.Click += (s, e) => NavigationService.SwitchPage<PageA>();
            btnPageB.Click += (s, e) => NavigationService.SwitchPage<PageB>();
            btnPageC.Click += (s, e) => NavigationService.SwitchPage<PageC>();
        }
        public Form1()
        {
            InitializeComponent();
            this.winFormsHostPanel = new System.Windows.Forms.Panel();
            this.btnPageA = new System.Windows.Forms.Button();
            this.btnPageB = new System.Windows.Forms.Button();
            this.btnPageC = new System.Windows.Forms.Button();
            this.SuspendLayout();

            // host panel (the “frame” for your pages)
            this.winFormsHostPanel.BackColor = System.Drawing.Color.WhiteSmoke;
            this.winFormsHostPanel.Location = new System.Drawing.Point(12, 49);
            this.winFormsHostPanel.Name = "winFormsHostPanel";
            this.winFormsHostPanel.Size = new System.Drawing.Size(560, 340);
            this.winFormsHostPanel.TabIndex = 0;

            // Button A
            this.btnPageA.Location = new System.Drawing.Point(12, 12);
            this.btnPageA.Name = "btnPageA";
            this.btnPageA.Size = new System.Drawing.Size(75, 23);
            this.btnPageA.Text = "Page A";

            // Button B
            this.btnPageB.Location = new System.Drawing.Point(93, 12);
            this.btnPageB.Name = "btnPageB";
            this.btnPageB.Size = new System.Drawing.Size(75, 23);
            this.btnPageB.Text = "Page B";

            // Button C
            this.btnPageC.Location = new System.Drawing.Point(174, 12);
            this.btnPageC.Name = "btnPageC";
            this.btnPageC.Size = new System.Drawing.Size(75, 23);
            this.btnPageC.Text = "Page C";

            // MainWindow
            this.ClientSize = new System.Drawing.Size(584, 401);
            this.Controls.Add(this.btnPageA);
            this.Controls.Add(this.btnPageB);
            this.Controls.Add(this.btnPageC);
            this.Controls.Add(this.winFormsHostPanel);
            this.Name = "MainWindow";
            this.Text = "Demo Navigation Framework";
            this.ResumeLayout(false);
            PostInit();
        }

        private void pageView1_Load(object sender, EventArgs e)
        {

        }
    }
}
