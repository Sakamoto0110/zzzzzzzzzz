﻿using PageNav.WinForms;
using PageNav.WinForms;
using System.Threading.Tasks;
using System.Windows.Forms;

[PageNav.Core.Services.PageBehavior(WaitCompletionBeforeShow = PageNav.Core.Services.NavigationLoadMode.LoadInBackground)]
public class PageC : PageView
{
 
    public PageC()
    {
        Name = "Páge C";
        this.BackColor = System.Drawing.Color.LightCoral;
        this.Controls.Add(new Label { Text = "PAGE C", AutoSize = true, Font = new System.Drawing.Font("Segoe UI", 16F) });
    }

    public override async Task Reload(object args)
    {
        await Task.Delay(4000);
     }
}
