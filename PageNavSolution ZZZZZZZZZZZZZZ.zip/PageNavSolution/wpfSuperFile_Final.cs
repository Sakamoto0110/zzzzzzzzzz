﻿
namespace PageNav.Wpf.Adapters
{
    public class EventDispatcherAdapter : IEventDispatcherAdapter
    {
        public void AttatchEvent<THandler>(object receiver, string eventName, THandler handler)
           where THandler : Delegate
        {
            if(receiver is DependencyObject d)
                AttatchEventInternal(d, eventName, handler);
        }

        public void DetatchEvent<THandler>(object receiver, string eventName, THandler handler)
            where THandler : Delegate
        {
            if(receiver is DependencyObject d)
                DetatchEventInternal(d, eventName, handler);
        }

        
        
        

        private void AttatchEventInternal<THandler>(DependencyObject receiver, string eventName, THandler handler)
            where THandler : Delegate
        {
            AttachSingle(receiver, eventName, handler);

            int count = VisualTreeHelper.GetChildrenCount(receiver);
            for(int i = 0; i < count; i++)
            {
                var child = VisualTreeHelper.GetChild(receiver, i);
                AttatchEventInternal(child, eventName, handler);
            }
        }

        private void DetatchEventInternal<THandler>(DependencyObject receiver, string eventName, THandler handler)
            where THandler : Delegate
        {
            DetachSingle(receiver, eventName, handler);

            int count = VisualTreeHelper.GetChildrenCount(receiver);
            for(int i = 0; i < count; i++)
            {
                var child = VisualTreeHelper.GetChild(receiver, i);
                DetatchEventInternal(child, eventName, handler);
            }
        }

        
        
        

        private void AttachSingle<THandler>(DependencyObject obj, string eventName, THandler handler)
            where THandler : Delegate
        {
            
            var targetType = obj.GetType();
            var ev = targetType.GetEvent(eventName);

            if(ev != null)
            {
                try
                {
                    ev.AddEventHandler(obj, handler);
                }
                catch(Exception ex)
                {
                    throw new Exception($"Failed attaching event '{eventName}' on {targetType.Name}: {ex.Message}", ex);
                }
            }
        }
        private void DetachSingle<THandler>(DependencyObject obj, string eventName, THandler handler)
            where THandler : Delegate
        {
            var targetType = obj.GetType();
            var ev = targetType.GetEvent(eventName);

            if(ev != null)
            {
                try
                {
                    ev.RemoveEventHandler(obj, handler);
                }
                catch(Exception ex)
                {
                    throw new Exception($"Failed detaching event '{eventName}' on {targetType.Name}: {ex.Message}", ex);
                }
            }
        }
    }
}

namespace PageNav.Wpf.Adapters
{
    public class InteractionBlocker : IInteractionBlocker
    {
        public void Block(object view)
        {
            if(view is UIElement e)
                e.IsEnabled = false;
        }

        public void Unblock(object view)
        {
            if(view is UIElement e)
                e.IsEnabled = true;
        }
    }
}

namespace PageNav.Wpf.Adapters
{
    public sealed class MovableWpfAdapter : IMovableAdapter
    {
        private class HandlerSet
        {
            public MouseButtonEventHandler Down;
            public MouseEventHandler Move;
            public MouseButtonEventHandler Up;
        }

        private readonly Dictionary<UIElement, HandlerSet> _map = new Dictionary<UIElement, HandlerSet>();

        public void MakeMovable(object view)
        {
            if(!(view is UIElement elem))
                throw new ArgumentException("WPF movable target must be UIElement.");

            if(_map.ContainsKey(elem))
                return;

            bool dragging = false;
            Point startMouse = new Point(0,0);
            Point startPos = new Point(0, 0);

            FrameworkElement fe = elem as FrameworkElement;
            DependencyObject parent = fe.Parent;

            bool isCanvas = parent is Canvas;

            TranslateTransform transform = null;
            if(!isCanvas)
            {
                transform = fe.RenderTransform as TranslateTransform;
                if(transform == null)
                {
                    transform = new TranslateTransform();
                    fe.RenderTransform = transform;
                }
            }

            var handlers = new HandlerSet();

            handlers.Down = (s, e) => {
                if(e.LeftButton != MouseButtonState.Pressed)
                    return;

                dragging = true;

                startMouse = e.GetPosition((IInputElement)parent ?? fe);

                if(isCanvas)
                {
                    startPos = new Point(
                        Canvas.GetLeft(fe),
                        Canvas.GetTop(fe)
                    );

                    if(double.IsNaN(startPos.X)) startPos.X = 0;
                    if(double.IsNaN(startPos.Y)) startPos.Y = 0;
                }

                fe.CaptureMouse();
            };

            handlers.Move = (s, e) => {
                if(!dragging) return;

                var currentMouse = e.GetPosition((IInputElement)parent ?? fe);
                var delta = currentMouse - startMouse;

                if(isCanvas)
                {
                    Canvas.SetLeft(fe, startPos.X + delta.X);
                    Canvas.SetTop(fe, startPos.Y + delta.Y);
                }
                else
                {
                    transform.X = delta.X;
                    transform.Y = delta.Y;
                }
            };

            handlers.Up = (s, e) => {
                dragging = false;
                fe.ReleaseMouseCapture();
            };

            elem.MouseDown += handlers.Down;
            elem.MouseMove += handlers.Move;
            elem.MouseUp += handlers.Up;

            _map[elem] = handlers;
        }

        public void RemoveMovable(object view)
        {
            if(!(view is UIElement elem)) return;

            if(!_map.TryGetValue(elem, out var h)) return;

            elem.MouseDown -= h.Down;
            elem.MouseMove -= h.Move;
            elem.MouseUp -= h.Up;

            _map.Remove(elem);
        }
    }
}

namespace PageNav.Wpf.Adapters
{
    public class PageMaskAdapter : IPageMask
    {
        private readonly Grid _overlay;
        private readonly TextBlock _text;

        public PageMaskAdapter(Panel host)
        {
            _overlay = new Grid
            {
                Background = new SolidColorBrush(Color.FromArgb(160, 0, 0, 0)),
                Visibility = Visibility.Collapsed
            };

            _text = new TextBlock
            {
                HorizontalAlignment = HorizontalAlignment.Center,
                VerticalAlignment = VerticalAlignment.Center,
                TextAlignment = TextAlignment.Center,
                Foreground = Brushes.White,
                FontSize = 22,
                FontWeight = FontWeights.Bold
            };

            _overlay.Children.Add(_text);

            
            host.Children.Add(_overlay);

            
            if(host is Grid)
            {
                Grid.SetRowSpan(_overlay, int.MaxValue);
                Grid.SetColumnSpan(_overlay, int.MaxValue);
            }
        }

        public void Show(string message = "")
        {
            _text.Text = message;
            _overlay.Visibility = Visibility.Visible;
        }

        public void Hide()
        {
            _overlay.Visibility = Visibility.Collapsed;
        }
    }

}

namespace PageNav.Wpf.Adapters
{
    public class TimerAdapter : ITimerAdapter
    {
        private DispatcherTimer _timer;
        private Action _tick;

        public void Start(int intervalMilliseconds, Action tick)
        {
            _tick = tick;
            _timer = new DispatcherTimer();
            _timer.Interval = TimeSpan.FromMilliseconds(intervalMilliseconds);
            _timer.Tick -= TimerTick;
            _timer.Tick += TimerTick;
            _timer.Start();
        }

        private void TimerTick(object s, EventArgs e) => _tick?.Invoke();

        public void Stop() => _timer.Stop();

        public void Dispose() => _timer.Stop();
    }
}

namespace PageNav.Wpf
{
    public class PageHost : IPageHost
    {
        private readonly Panel _panel;

        public PageHost(Panel panel)
        {
            _panel = panel;
        }

        public void AddView(object view)
        {
            if(view is UIElement elem)
                _panel.Children.Add(elem);
        }

        public void RemoveView(object view)
        {
            if(view is UIElement elem)
                _panel.Children.Remove(elem);
        }

        public void BringToFront(object view)
        {
            
            if(view is UIElement elem)
                Panel.SetZIndex(elem, 9999);
        }

        public void Focus(object view)
        {
            if(view is UIElement elem)
                elem.Focus();
        }
    }
}

namespace PageNav.Wpf
{
    public class PlatformAdapter : IPlatformAdapter
    {
        public bool CanHandle(object host) => host is System.Windows.Controls.Panel;

        public IPageHost CreateHost(object host) =>
            new PageHost((Panel)host);

        public IPageMask CreateMask(object host) =>
            new PageMaskAdapter((Panel)host);

        public IEventDispatcherAdapter CreateEventDispatcher(object host) =>
            new EventDispatcherAdapter();

        public IInteractionBlocker CreateInteractionBlocker(object host) =>
            new InteractionBlocker();

        public ITimerAdapter CreateTimerAdapter() =>
            new TimerAdapter();
    }

    public static class WpfBootstrap
    {
        public static void Register() =>
            PlatformRegistry.Register(new PlatformAdapter());
    }
}

[assembly: AssemblyTitle("PageNav.Wpf")]
[assembly: AssemblyDescription("")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("")]
[assembly: AssemblyProduct("PageNav.Wpf")]
[assembly: AssemblyCopyright("Copyright ©  2025")]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyCulture("")]

[assembly: ComVisible(false)]

[assembly: Guid("50185016-c32c-4fc0-9c92-a77dc334586c")]

[assembly: AssemblyVersion("1.0.0.0")]
[assembly: AssemblyFileVersion("1.0.0.0")]

namespace PageNav.Wpf
{
    public abstract class PageView : UserControl, IPageView
    {
        protected IPageHost Host;
        public event Action<object> ChildViewAdded;
        public event Action<object> ChildViewRemoved;
        public event Action OnDetachEvent;

        public abstract string Name { get; }

        public bool IsVisible
        {
            get => Visibility == System.Windows.Visibility.Visible;
            set => Visibility = value ? System.Windows.Visibility.Visible : System.Windows.Visibility.Collapsed;
        }

        public bool IsLocked { get; set; }

        public object NativeView => this;

        public bool DesignMode => false;

        protected override void OnInitialized(EventArgs e)
        {
            base.OnInitialized(e);
            AddLogicalTreeHandlers(this);
        }

        private void AddLogicalTreeHandlers(DependencyObject root)
        {
            this.AddHandler(FrameworkElement.LoadedEvent, new RoutedEventHandler((s, e) => {
                if(e.Source is FrameworkElement fe)
                    ChildViewAdded?.Invoke(fe);
            }));

            this.AddHandler(FrameworkElement.UnloadedEvent, new RoutedEventHandler((s, e) => {
                if(e.Source is FrameworkElement fe)
                    ChildViewRemoved?.Invoke(fe);
            }));
        }
        public virtual void OnAttach(IPageHost host)
        {
            Host = host;
            host.AddView(this);
        }

        public virtual void OnDetach()
        {
            Host?.RemoveView(this);
        }

        public abstract Task ReloadAsync(object args);

        public virtual void Enable() => IsEnabled = true;
        public virtual void Disable() => IsEnabled = false;

        public virtual async Task ReleaseResources()
        {
            
        }

        public abstract void Dispose();
    }
}

[assembly: global::System.Runtime.Versioning.TargetFrameworkAttribute(".NETFramework,Version=v4.8.1", FrameworkDisplayName = ".NET Framework 4.8.1")]

