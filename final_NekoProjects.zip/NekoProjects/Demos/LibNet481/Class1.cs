﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LibNet481
{
    public class Class1
    {

        public static int Sum(int a, int b) => a + b;

    }
}
