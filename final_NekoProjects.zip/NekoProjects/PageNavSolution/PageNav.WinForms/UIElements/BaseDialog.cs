﻿using System;
using System.Drawing;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PageNav.WinForms.Controls
{
    public class BaseDialogForm : Form
    {
        private TaskCompletionSource<DialogResult> _tcs;
        private bool _initialized;

        public bool Draggable { get; set; } = true;
        public bool DimBackground { get; set; } = true;
        public int PaddingAmount { get; set; } = 20;

        private Panel _backgroundDim;
        private Control _dragSource;
        private Point _dragOffset;

        public BaseDialogForm()
        {
            FormBorderStyle = FormBorderStyle.None;
            StartPosition = FormStartPosition.Manual;
            BackColor = Color.White;
            DoubleBuffered = true;
            KeyPreview = true;
            MinimumSize = new Size(300, 180);

            KeyDown += (_, e) => {
                if(e.KeyCode == Keys.Escape)
                    CloseDialog(DialogResult.Cancel);
            };
        }

        public void BindDragArea(Control ctrl)
        {
            _dragSource = ctrl;
            ctrl.MouseDown += DragMouseDown;
            ctrl.MouseMove += DragMouseMove;
        }

        private void DragMouseDown(object sender, MouseEventArgs e)
        {
            if(!Draggable) return;
            _dragOffset = new Point(e.X, e.Y);
        }

        private void DragMouseMove(object sender, MouseEventArgs e)
        {
            if(!Draggable || e.Button != MouseButtons.Left) return;

            var screenPos = Cursor.Position;
            Location = new Point(screenPos.X - _dragOffset.X, screenPos.Y - _dragOffset.Y);
        }

        public async Task<DialogResult> ShowDialogAsync(Control host)
        {
            if(!_initialized)
            {
                _initialized = true;
                InitializeOverlay(host);
            }

            _tcs = new TaskCompletionSource<DialogResult>();

            base.Show(host);
            BringToFront();
            CenterOnHost(host);

            FadeInAsync();

            return await _tcs.Task;
        }

        private void InitializeOverlay(Control host)
        {
            if(!DimBackground) return;

            _backgroundDim = new Panel
            {
                BackColor = Color.FromArgb(120, 0, 0, 0),
                Dock = DockStyle.Fill,
                Visible = true
            };

            host.Controls.Add(_backgroundDim);
            _backgroundDim.BringToFront();
        }

        private void CenterOnHost(Control host)
        {
            var hostRect = host.RectangleToScreen(host.ClientRectangle);
            var x = hostRect.X + (hostRect.Width - Width) / 2;
            var y = hostRect.Y + (hostRect.Height - Height) / 2;
            Location = new Point(Math.Max(0, x), Math.Max(0, y));
        }

        public void CloseDialog(DialogResult result)
        {
            _ = FadeOutAsync(result);
        }

        protected override void OnFormClosed(FormClosedEventArgs e)
        {
            _backgroundDim?.Dispose();
            base.OnFormClosed(e);
        }

        private async Task FadeOutAsync(DialogResult result)
        {
            for(double f = 1.0; f >= 0.0; f -= 0.1)
            {
                Opacity = f;
                await Task.Delay(10);
            }

            _tcs.TrySetResult(result);
            Close();
        }

        private async void FadeInAsync()
        {
            Opacity = 0;
            for(double f = 0.0; f <= 1.0; f += 0.1)
            {
                Opacity = f;
                await Task.Delay(10);
            }
        }
    }
}
