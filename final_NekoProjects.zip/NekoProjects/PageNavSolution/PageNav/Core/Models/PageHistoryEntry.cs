﻿using PageNav.Core.Abstractions;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PageNav.Core.Models
{
     
    public sealed class PageHistoryEntry
    {
        public Type PageType { get; }
        public string Name { get; }
        public object Payload { get; }
        public DateTime Timestamp { get; }

        public PageHistoryEntry(IPageView page, object payload = null)
        {
            PageType = page.GetType();
            Name = page.Name;
            Payload = payload;
            Timestamp = DateTime.Now;
        }
        public override string ToString() => $"{PageType.Name}.{Name} ({Timestamp:HH:mm:ss})";
    }
}
