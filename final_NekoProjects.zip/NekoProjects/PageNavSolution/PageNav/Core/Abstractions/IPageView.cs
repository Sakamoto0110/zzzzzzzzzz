﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PageNav.Core.Abstractions
{
    /// <summary>
    /// Framework-agnostic representation of a UI Page.
    /// Implementations can be WinForms, WPF, MAUI, Avalonia, etc.
    /// </summary>
    public interface IPageView : IDisposable
    {
        bool IsDisposed { get; }
        bool DesignMode { get; }
        event Action<object> ChildViewAdded;
        event Action<object> ChildViewRemoved;
        /// <summary>
        /// Logical name used for navigation and registration.
        /// </summary>
        string Name { get; }

        /// <summary>
        /// True if the page is currently visible.
        /// Each UI framework implements this.
        /// </summary>
        bool IsVisible { get; set; }

        /// <summary>
        /// Optional: Some pages may lock interaction (critical flow).
        /// </summary>
        bool IsLocked { get; set; }

        /// <summary>
        /// Called when the page is being mounted into a host container.
        /// The host is abstract to avoid framework coupling.
        /// </summary>
        void OnAttach(IPageHost host);

        /// <summary>
        /// Called when the page is removed from screen.
        /// </summary>
        void OnDetach();

        event Action OnDetachEvent;


        /// <summary>
        /// Reloads the page (load data, reset UI, etc.)
        /// Should NOT block UI — async-friendly.
        /// </summary>
        [Obsolete("Use OnEnterAsync instead")]
        Task Reload(object args);

        /// <summary>
        /// Enables UI interaction.
        /// </summary>
        void Enable();

        /// <summary>
        /// Disables UI interaction.
        /// </summary>
        void Disable();

        /// <summary>
        /// Releases heavy resources (images, streams, etc.)
        /// Does NOT dispose the UI container itself — that's handled externally.
        /// </summary>
        Task ReleaseResources();
        object NativeView { get; }
    }

}
