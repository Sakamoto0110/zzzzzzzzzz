﻿using NekoLogger.Abstractions;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NekoLogger.Core
{

    public class LoggerWriter : ILoggerHandler
    {
       
        public virtual void Log(object content, Func<object, string> ToStringOverride = null, Severity severity = Severity.Info, string[] tags = null)
        {
            Logger.Log(content, ToStringOverride, severity, tags);
        }
        public virtual void LogEx(object sender, object content, Func<object, string> ToStringOverride = null, Severity severity = Severity.Info, string[] tags = null)
        {
            Logger.Log(sender, content, ToStringOverride, severity, tags);
        }

    }



}