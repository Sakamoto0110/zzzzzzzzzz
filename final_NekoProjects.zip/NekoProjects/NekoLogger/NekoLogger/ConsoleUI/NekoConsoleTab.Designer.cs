﻿using System.Drawing;
using System.Windows.Forms;

namespace NekoLogger.ConsoleUI
{
    partial class NekoConsoleTab
    {
        /// <summary> 
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if(disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Designer de Componentes

        /// <summary> 
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.Output = new System.Windows.Forms.RichTextBox();
            this.Input = new System.Windows.Forms.TextBox();
            this.BottomMenu = new System.Windows.Forms.Panel();
            this.ZoomTrackbar = new System.Windows.Forms.TrackBar();
            this.BottomMenu.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.ZoomTrackbar)).BeginInit();
            this.SuspendLayout();
            // 
            // Output
            // 
            this.Output.Location = new System.Drawing.Point(0, 0);
            this.Output.Name = "Output";
            this.Output.Size = new System.Drawing.Size(100, 96);
            this.Output.TabIndex = 0;
            this.Output.Text = "";
            this.Output.Dock = DockStyle.Fill;
            this.Output.BackColor = SystemColors.Control;
            this.Output.BorderStyle = BorderStyle.None;
            this.Output.SelectionAlignment = HorizontalAlignment.Left;
            this.Output.ShowSelectionMargin = false;
            this.Output.ReadOnly = true;
            this.Output.Font = SystemFonts.DialogFont;
            // 
            // Input
            // 
            this.Input.Location = new System.Drawing.Point(0, 0);
            this.Input.Name = "Input";
            this.Input.Size = new System.Drawing.Size(100, 20);
            this.Input.TabIndex = 1;
            this.Input.Dock = DockStyle.Bottom;
            // 
            // BottomMenu
            // 
            this.BottomMenu.Controls.Add(this.ZoomTrackbar);
            this.BottomMenu.Location = new System.Drawing.Point(0, 0);
            this.BottomMenu.Name = "BottomMenu";
            this.BottomMenu.Size = new System.Drawing.Size(200, 100);
            this.BottomMenu.TabIndex = 2;
            this.BottomMenu.Height = 30;
            this.BottomMenu.Dock = DockStyle.Bottom;
            this.BottomMenu.AutoSizeMode = AutoSizeMode.GrowOnly;
            this.BottomMenu.AutoSize = false;
            // 
            // ZoomTrackbar
            // 
            this.ZoomTrackbar.Location = new System.Drawing.Point(0, 0);
            this.ZoomTrackbar.Name = "ZoomTrackbar";
            this.ZoomTrackbar.Size = new System.Drawing.Size(100, 50);
            this.ZoomTrackbar.TabIndex = 0;
            this.ZoomTrackbar.TickStyle = TickStyle.BottomRight;
            this.ZoomTrackbar.Minimum = 1;
            this.ZoomTrackbar.Maximum = 200;
            this.ZoomTrackbar.Value = 15;
            this.ZoomTrackbar.TickFrequency = 10;
            this.ZoomTrackbar.SmallChange = 1;
            this.ZoomTrackbar.LargeChange = 1;
            this.ZoomTrackbar.Dock = DockStyle.Right;
            // 
            // NekoConsoleTab
            // 
            Controls.Add(this.Output);
            Controls.Add(this.Input);
            Controls.Add(this.BottomMenu);
            this.Name = "NekoVirtualConsole2";
            this.Size = new System.Drawing.Size(500, 300);
            this.BottomMenu.ResumeLayout(false);
            this.BottomMenu.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.ZoomTrackbar)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion
        public RichTextBox Output;
        public TextBox Input;
        public Panel BottomMenu;
        public TrackBar ZoomTrackbar;

    }
}
