﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Transactions;
using System.Windows.Forms;

namespace _2024
{
    public static class ColorExtensions
    {
        /// <summary>
        /// Convert a Color (RGB or RGBA) to HSL.
        /// </summary>
        public static (double H, double S, double L) ToHsl(this Color color)
        {
            double r = color.R / 255.0;
            double g = color.G / 255.0;
            double b = color.B / 255.0;

            double max = Math.Max(r, Math.Max(g, b));
            double min = Math.Min(r, Math.Min(g, b));
            double h = 0, s, l = (max + min) / 2.0;

            if(Math.Abs(max - min) < 0.00001)
            {
                h = s = 0; // gray
            }
            else
            {
                double d = max - min;
                s = l > 0.5 ? d / (2.0 - max - min) : d / (max + min);

                if(max == r)
                    h = (g - b) / d + (g < b ? 6 : 0);
                else if(max == g)
                    h = (b - r) / d + 2;
                else
                    h = (r - g) / d + 4;

                h /= 6.0;
            }

            return (h * 360, s, l); // H in [0,360), S & L in [0,1]
        }

        /// <summary>
        /// Convert HSL values to a Color (RGB).
        /// Alpha defaults to 255 unless provided.
        /// </summary>
        public static Color FromHsl(this (double H, double S, double L) hsl, byte alpha = 255)
        {
            double h = hsl.H % 360;
            double s = hsl.S;
            double l = hsl.L;
            double r, g, b;

            if(s == 0)
            {
                r = g = b = l; // gray
            }
            else
            {
                double q = l < 0.5 ? l * (1 + s) : l + s - l * s;
                double p = 2 * l - q;

                Func<double, double> HueToRgb = (t) =>
                {
                    if(t < 0) t += 1;
                    if(t > 1) t -= 1;
                    if(t < 1.0 / 6) return p + (q - p) * 6 * t;
                    if(t < 1.0 / 2) return q;
                    if(t < 2.0 / 3) return p + (q - p) * (2.0 / 3 - t) * 6;
                    return p;
                };

                double hk = h / 360.0;
                r = HueToRgb(hk + 1.0 / 3);
                g = HueToRgb(hk);
                b = HueToRgb(hk - 1.0 / 3);
            }

            return Color.FromArgb(alpha,
                (int)Math.Round(r * 255),
                (int)Math.Round(g * 255),
                (int)Math.Round(b * 255));
        }
    }
    public struct DeletedButton
    {
        public Button btn;
        public int y, x;

    }
    public class GameSize
    {
        public GameSize() { ColumnCount = 3; RowCount = 3; }
        public GameSize(int x, int y) { ColumnCount = x; RowCount = y; }
        public int ColumnCount { get; set; }
        public int RowCount { get; set; }

        public override string ToString() => $"{ColumnCount} x {RowCount}";

    }

    public class GameScoredEventArgs : EventArgs
    {
        public int Score { get; set; }
        public int Delta { get; set; }
    }
    public class Game
    {
       //0.64
       //33.98

                public event EventHandler<GameScoredEventArgs> Scored;
        public static GameSize[] AvailableGameSizes =
        [
            new GameSize (1,1),
            new GameSize (2,2),
            new GameSize (3,3),
            new GameSize (4,4),
            new GameSize (5,5),
            new GameSize (6,6),
            new GameSize (7,7),
            new GameSize (8,8),
            new GameSize (9,9),
        ];
        private Panel Canvas;
        private Button[][] Buttons = null;
        private List<Button> _deletedButtons = new List<Button>();
        public Button SelectedButton
        {
            get => Buttons[SelectedButtonIndex.X][SelectedButtonIndex.Y];
        }
        private int _score;
        public int Score
        {
            get => _score; set
            {
                var delta = value - _score;
                var args = new GameScoredEventArgs()
                {
                    Score = value,
                    Delta = delta
                };
                Scored?.Invoke(this, args);
                _score = value;
            }
        }
        private Point SelectedButtonIndex;

        public Game(Panel canvas)
        {
            Canvas = canvas;
            Canvas.BackColor = Color.FromArgb(254, 250, 224);
            SelectedButtonIndex = new Point(0, 0);
            LoadStyle();
        }


        public Color bgColor, btnColor, btnBorderColor;

        private void IncrL() { }
        private void IncrH() { }

        public void LoadStyle()
        {
            btnColor = Color.FromArgb(220, 171, 107);
            btnBorderColor = Color.FromArgb(106, 56, 31);
            bgColor = Color.FromArgb(254, 250, 224);
            var hsl = btnColor.ToHsl();
            Console.WriteLine($"L:{hsl.L} H:{hsl.H}");

        }
        public void Start(int startCells)
        {

            LoadStyle();
            Canvas.BackColor = bgColor;
            Canvas.Controls.Clear();
            for(int r = 0; r < GameSize.RowCount; r++)
                for(int c = 0; c < GameSize.ColumnCount; c++)
                    Buttons[r][c] = null;
            AddRandomCells(2, 1, 1);
            Score = 0;


        }
        public IEnumerable<(int y, int x)> GetAvailableCellsIndexes()
        {
            for(int y = 0; y < GameSize.RowCount; y++)
                for(int x = 0; x < GameSize.ColumnCount; x++)
                    if(Buttons[y][x] == null)
                        yield return (y, x);
        }

        public void AddRandomCells(int count, int valueMin, int valueMax)
        {
            (int x, int y)[] idxs = GetAvailableCellsIndexes().ToArray();

            Random rand = new Random();
            for(int i = 0; i < count; i++)
            {
                var x = idxs[rand.Next(0, idxs.Length)].x;
                var y = idxs[rand.Next(0, idxs.Length)].y;
                var v = rand.Next(valueMin, valueMax);
                AddButton(x, y, 1);



            }
        }

        // 1 top
        // 2 right
        // 3 bottom
        // 4 left
        public void MoveButtons(int dir)
        {
            if(isMoving)
                return;
            isMoving = true;

            MoveButtons(dir, this.GameSize.ColumnCount);
           
            isMoving = false;
        }

        double L = 64;
        double H=34;
        bool isMoving = false;

        private void MoveButtons(int dir, int retries)
        {
            if(retries <= 0)
            {
                for(int i = 0; i < _deletedButtons.Count; i++)
                {
                    Canvas.Controls.Remove(_deletedButtons[i]);
                    //Buttons[_deletedButtons[i].y][_deletedButtons[i].x] = null;
                    _deletedButtons.RemoveAt(i);
                }

                return;
            }

            var spd = 2;
            var acc = 1.1;
            switch(dir)
            {
                case 1:

                    MoveButtons(GetMovableButtons(0, -1), MoveDirection.Up, ButtonSize, spd, acc);
                    break;
                case 2:


                    MoveButtons(GetMovableButtons(1, 0), MoveDirection.Right, ButtonSize, spd, acc);
                    break;
                case 3:
                    MoveButtons(GetMovableButtons(0, 1), MoveDirection.Down, ButtonSize, spd, acc);

                    break;
                case 4:
                    MoveButtons(GetMovableButtons(-1, 0), MoveDirection.Left, ButtonSize, spd, acc);
                    break;

            }
            MoveButtons(dir, --retries);

        }


        // 1 top
        // 2 right
        // 3 bottom
        // 4 left


        private Button MergeButtons(Button btn_to_stay, Button btn_to_be_removed)
        {
            // add the value from each button
            var i1 = int.Parse(btn_to_stay.Text);
            var i2 = int.Parse(btn_to_be_removed.Text);
            var i3 = i1 + i2;
            var digit_count = $"{i3}".Length;

            // apply cap to the result value *OPTIONAL*

            // does nothings rn

            // modify the button that stays properties
            btn_to_stay.Text = $"{i3}";
            var hsl = btnColor.ToHsl();
            hsl.L = hsl.L - 0.08;
            if(hsl.L < 0.5)
            {
                hsl.L = 0.8;
                hsl.H = (hsl.H + 16) % 360;
            }
            btn_to_stay.BackColor = ColorExtensions.FromHsl(hsl);
            btn_to_stay.BringToFront();

            

            // update score
            Score = Score + i3;
            // mark the button to be removed
            _deletedButtons.Add(btn_to_be_removed);
            // return the button to be moved
            return btn_to_be_removed;
        }

        public List<Button> GetMovableButtons(int dx, int dy)
        {
            var result = new List<Button>();
            for(int x = 0; x < GameSize.ColumnCount; x++)
            {
                for(int y = 0; y < GameSize.RowCount; y++)
                {

                    if(Buttons[y][x] == null) { }
                    if(Buttons[y][x] != null)
                    {
                        var nx = x + dx;
                        var ny = y + dy;
                        if(nx < 0 || nx >= GameSize.ColumnCount) continue;
                        if(ny < 0 || ny >= GameSize.RowCount) continue;

                        if(Buttons[ny][nx] == null)
                        {
                            Buttons[ny][nx] = Buttons[y][x];
                            result.Add(Buttons[y][x]);
                            Buttons[y][x] = null;

                        }
                        else
                        {
                            if(Buttons[ny][nx].Text == Buttons[y][x].Text)
                            {
                                //result.Add(MergeButtons(Buttons[ny][nx], Buttons[y][x]));
                                //Buttons[ny][nx] = Buttons[ny][nx];
                                //Buttons[y][x] = null;


                                // add the value from each button
                                var btn_to_be_removed = Buttons[y][x];
                                var btn_to_stay = Buttons[ny][nx];
                                var i1 = int.Parse(btn_to_stay.Text);
                                var i2 = int.Parse(btn_to_be_removed.Text);
                                var i3 = i1 + i2;
                                var digit_count = $"{i3}".Length;

                                // apply cap to the result value *OPTIONAL*

                                // modify the button that stays properties
                                btn_to_stay.Text = $"{i3}";
                             
                                //
                                
                                //Canvas.Controls.Remove(Buttons[y][x]);
                                var hsl = btnColor.ToHsl();
                                hsl.L = hsl.L - 0.08;
                                if(hsl.L < 0.5)
                                {
                                    hsl.L = 0.8;
                                    hsl.H = (hsl.H + 16) % 360;
                                }
                                btn_to_stay.BackColor = ColorExtensions.FromHsl(hsl);
                                btn_to_stay.BringToFront();

                                // update score
                                Score = Score + i3;

                                // mark the button to be moved and removed after
                                result.Add(btn_to_be_removed);
                                _deletedButtons.Add(btn_to_be_removed);
                                //
                                Buttons[ny][nx] = btn_to_stay;
                                Buttons[y][x] = null;

                            }
                        }

                    }
                }

            }
            return result;
        }

        public enum MoveDirection { Left, Right, Up, Down }

        public void MoveButtons(
            IEnumerable<Button> btns,
            MoveDirection dir,
            int distance = 75,          // e.g., ButtonSize
            int initialSpeed = 1,
            double acceleration = 1.2)
        {
            if(btns == null) return;

            foreach(var btn in btns)
            {
                if(btn == null) continue;

                // per-button state
                int spd = initialSpeed;
                var start = btn.Location;

                // Axis & sign
                int sx = 0, sy = 0;
                switch(dir)
                {
                    case MoveDirection.Left: sx = -1; sy = 0; break;
                    case MoveDirection.Right: sx = 1; sy = 0; break;
                    case MoveDirection.Up: sx = 0; sy = -1; break;
                    case MoveDirection.Down: sx = 0; sy = 1; break;
                }

                // Target point
                var target = new Point(start.X + sx * distance, start.Y + sy * distance);

                
                // Move loop with overshoot clamp
                while(true)
                {
                    
                    int remainingX = target.X - btn.Location.X;
                    int remainingY = target.Y - btn.Location.Y;

                    // Done?
                    if(sx == 0 && sy == 0) break;
                    if((sx != 0 && sx * remainingX <= 0) && (sy != 0 && sy * remainingY <= 0)) break;
                    if(sx != 0 && sy == 0 && sx * remainingX <= 0) break;
                    if(sy != 0 && sx == 0 && sy * remainingY <= 0) break;

                    // Step with clamp on remaining distance
                    int stepX = sx != 0 ? Math.Min(Math.Abs(remainingX), spd) * sx : 0;
                    int stepY = sy != 0 ? Math.Min(Math.Abs(remainingY), spd) * sy : 0;

                    btn.Location = new Point(btn.Location.X + stepX, btn.Location.Y + stepY);

                    // accelerate (bounded)
                    spd = (int)(spd * acceleration);
                    if(spd < 1) spd = 1;
                    if(spd > distance) spd = distance;

                    Application.DoEvents(); // keeps UI responsive in a tight loop; see async variant below
                }

                // Snap exactly to target to avoid rounding drift
                btn.Location = target;
            }
        }




        private GameSize _gameSize = new GameSize(3, 3);
        public GameSize GameSize
        {
            get => _gameSize;
            set
            {
                var _Buttons = new Button[value.RowCount][];
                for(int r = 0; r < value.RowCount; r++)
                    _Buttons[r] = new Button[value.ColumnCount];
                if(Buttons != null)
                {
                    for(int x = 0; x < _gameSize.ColumnCount && x < value.ColumnCount; x++)
                    {
                        for(int y = 0; y < _gameSize.RowCount && y < value.RowCount; y++)
                        {
                            if(Buttons[y][x] != null)
                            {
                                _Buttons[y][x] = Buttons[y][x];
                            }
                        }
                    }

                }

                Buttons = _Buttons;


                //for(int r = 0; r < value.RowCount; r++)
                //{
                //    btns[r] = new Button[value.ColumnCount];
                //    for(int c = 0; c < value.ColumnCount; c++)
                //    {
                //        var btn = new Button();
                //        btn.Size = new Size(ButtonSize - 2, ButtonSize - 2);
                //        btn.Location = new Point(c * ButtonSize + 1, r * ButtonSize + 1);
                //        btn.Text = $"2";
                //        Canvas.Controls.Add(btn);
                //        btns[r][c] = btn;
                //    }
                //}

                _gameSize = value;
                Canvas.Size = new Size(GameSize.ColumnCount * ButtonSize, GameSize.RowCount * ButtonSize);
            }
        }
        public int ButtonSize { get; set; } = 75;

        private Font CreateButtonFont(int sz)=> new Font("Arialounded MT Bold", sz, FontStyle.Bold);

        public bool AddButton(int x, int y, int value)
        {
            if(x < 0 || x >= GameSize.ColumnCount) throw new ArgumentOutOfRangeException(nameof(x));
            if(y < 0 || y >= GameSize.RowCount) throw new ArgumentOutOfRangeException(nameof(y));
            if(Buttons == null) throw new InvalidOperationException("Game size not set");
            if(Buttons[y][x] != null) return false;
            var btn = new Button();
            btn.Size = new Size(ButtonSize - 2, ButtonSize - 2);
            btn.Font = CreateButtonFont(16);


            btn.Location = new Point(x * ButtonSize + 1, y * ButtonSize + 1);
            btn.Text = $"{value}";
            btn.Enabled = false;
            Canvas.Controls.Add(btn);
            btn.Click += (s, e) => {
                SelectedButtonIndex = new Point(y, x);
            };
            Buttons[y][x] = btn;
            btn.FlatStyle = FlatStyle.Flat;
            btn.FlatAppearance.BorderSize = 2;
            btn.BackColor = btnColor;

            btn.FlatAppearance.BorderColor = btnBorderColor;
            return true;
        }
    }
}
