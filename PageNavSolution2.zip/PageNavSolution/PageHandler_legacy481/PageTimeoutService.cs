﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PageNav
{
    public static class TimeoutService
    {
        public enum TimeoutBehavior
        {
            Default,
            OverrideHome,
            IgnoreTimeout
        }
        private static ITimerAdapter _timer;
        private static int _ticks;
        private static int _thresholdTicks;

        public static event Action TimeoutReached;

        public static void Initialize(ITimerAdapter timerAdapter, int timeoutSeconds)
        {
            _timer = timerAdapter ?? throw new ArgumentNullException(nameof(timerAdapter));

            // convert seconds → ticks (1 tick per second)
            _thresholdTicks = timeoutSeconds;

            _timer.Start(1000, OnTick); // 1s tick
        }

        private static void OnTick()
        {
            _ticks++;
            Console.WriteLine("+" + _ticks);
            if(_ticks >= _thresholdTicks)
            {
                _ticks = 0;
                TimeoutReached?.Invoke();
            }
        }

        public static void Reset(object s, EventArgs e) 
        {
            _ticks = 0;
            Console.WriteLine("timer reseted");
        } 

        public static void Pause() => _timer.Stop();

        public static void Continue() => _timer.Start(1000, OnTick);
    }
}
