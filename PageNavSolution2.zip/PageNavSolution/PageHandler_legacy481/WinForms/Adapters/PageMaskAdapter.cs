﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PageNav.WinForms.Adapters
{
    public class PageMaskAdapter : IPageMask
    {
        private readonly Panel _mask = new Panel();
        private readonly Label _label = new Label();

        public PageMaskAdapter(Control host)
        {
            // host = your Form, or your PageContainer, etc.
            _mask.BackColor = Color.FromArgb(180, Color.Black); // Semi-transparent overlay
            _mask.Dock = DockStyle.Fill;
            _mask.Visible = false;

            _label.Dock = DockStyle.Fill;
            _label.TextAlign = ContentAlignment.MiddleCenter;
            _label.ForeColor = Color.White;
            _label.Font = new Font("Segoe UI", 16, FontStyle.Bold);

            _mask.Controls.Add(_label);
            host.Controls.Add(_mask);
            _mask.BringToFront();
        }

        public void Show(string message = "")
        {
            _label.Text = message;
            _mask.Visible = true;
            _mask.BringToFront();
        }

        public void Hide()
        {
            _mask.Visible = false;
        }
    }

}
