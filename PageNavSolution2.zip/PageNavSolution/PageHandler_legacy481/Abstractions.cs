﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Controls;

namespace PageNav
{
    /// <summary>
    /// Represents a UI framework container (WinForms Panel, WPF Grid, etc.)
    /// where a PageView can attach itself.
    /// </summary>
    public interface IPageHost
    {
        

        /// <summary>
        /// Called by NavigationService to add a page to the host.
        /// Framework adapter decides how to insert.
        /// </summary>
        void AddView(object frameworkView);

        /// <summary>
        /// Called by NavigationService to remove a page.
        /// </summary>
        void RemoveView(object frameworkView);

        /// <summary>
        /// Brings the view to the top (sets z-order).
        /// </summary>
        void BringToFront(object frameworkView);

        /// <summary>
        /// Sets focus to the view if supported.
        /// </summary>
        void Focus(object frameworkView);
    }

    /// <summary>
    /// Framework-agnostic representation of a UI Page.
    /// Implementations can be WinForms, WPF, MAUI, Avalonia, etc.
    /// </summary>
    public interface IPageView : IDisposable
    {
        bool DesignMode { get; }
        event Action<object> ChildViewAdded;
        event Action<object> ChildViewRemoved;
        /// <summary>
        /// Logical name used for navigation and registration.
        /// </summary>
        string Name { get; }

        /// <summary>
        /// True if the page is currently visible.
        /// Each UI framework implements this.
        /// </summary>
        bool IsVisible { get; set; }

        /// <summary>
        /// Optional: Some pages may lock interaction (critical flow).
        /// </summary>
        bool IsLocked { get; set; }

        /// <summary>
        /// Called when the page is being mounted into a host container.
        /// The host is abstract to avoid framework coupling.
        /// </summary>
        void OnAttach(IPageHost host);

        /// <summary>
        /// Called when the page is removed from screen.
        /// </summary>
        void OnDetach();

        event Action OnDetachEvent;


        /// <summary>
        /// Reloads the page (load data, reset UI, etc.)
        /// Should NOT block UI — async-friendly.
        /// </summary>
        Task ReloadAsync(object args);

        /// <summary>
        /// Enables UI interaction.
        /// </summary>
        void Enable();

        /// <summary>
        /// Disables UI interaction.
        /// </summary>
        void Disable();

        /// <summary>
        /// Releases heavy resources (images, streams, etc.)
        /// Does NOT dispose the UI container itself — that's handled externally.
        /// </summary>
        Task ReleaseResources();
        object NativeView { get; }
    }


    public interface IMovableAdapter
    {
        void MakeMovable(object view);
        void RemoveMovable(object view);
    }


    public interface IPageMask
    {
        void Show(string message = "");
        void Hide();
    }
    public interface ITimerAdapter : IDisposable
    {
        void Start(int intervalMilliseconds, Action tick);
        void Stop();
    }
    public interface IEventDispatcherAdapter
    {
        void AttatchEvent<THandler>(object reciever, string eventName, THandler handler) where THandler : Delegate;
        void DetatchEvent<THandler>(object reciever, string eventName, THandler handler) where THandler : Delegate;
       


    }
    public interface IInteractionBlocker
    {
        void Block(object view);
        void Unblock(object view);
    }
    public static class MovableControlHelper
    {
        private static IMovableAdapter _adapter;

        public static void Initialize(IMovableAdapter adapter)
        {
            _adapter = adapter ?? throw new ArgumentNullException(nameof(adapter));
        }

        public static void MakeMovable(object view) => _adapter?.MakeMovable(view);

        public static void RemoveMovable(object view) => _adapter?.RemoveMovable(view);
    }

}
