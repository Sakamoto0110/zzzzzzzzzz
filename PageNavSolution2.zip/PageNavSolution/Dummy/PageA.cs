﻿using PageNav;
using PageNav.Core.Services;
using PageNav.WinForms;
using PageNav.WinForms;
using System;
using System.Threading.Tasks;
using System.Windows.Forms;

[PageBehavior(PageKind.Home,PageCachePolicy.WeakSingleton,Tags = new[] {"Tag"})]
public class PageA : PageView
{
    private Button button1;
    private Button button2;

    public PageA()
    {
        InitializeComponent();

        
            // runtime-only init
            button1.Click += async (s, e) => {
                await NavigationService.GoBackAsync();
            };
        
        
    }
    void InitializeComponent()
    {
            this.button1 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(12, 162);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(113, 54);
            this.button1.TabIndex = 0;
            this.button1.Text = "button1";
            this.button1.UseVisualStyleBackColor = true;
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(160, 85);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(75, 23);
            this.button2.TabIndex = 1;
            this.button2.Text = "button2";
            this.button2.UseVisualStyleBackColor = true;
            // 
            // PageA
            // 
            this.BackColor = System.Drawing.Color.Tomato;
            this.Controls.Add(this.button2);
            this.Controls.Add(this.button1);
            this.Name = "PageA";
            this.Size = new System.Drawing.Size(270, 247);
            this.ResumeLayout(false);

    }
    private async void PageA_Load(object sender, EventArgs e)
    {
        if(DesignMode) return; // required

        await ReloadAsync(null);
    }
    public override Task ReloadAsync(object args)
    {
        return Task.CompletedTask;
    }

     
}
