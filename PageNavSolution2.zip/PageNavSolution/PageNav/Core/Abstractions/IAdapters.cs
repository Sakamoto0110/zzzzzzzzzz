﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PageNav.Core.Abstractions
{
    public interface IPageMask
    {
        void Show(string message = "");
        void Hide();
    }
    public interface ITimerAdapter : IDisposable
    {
        void Start(int intervalMilliseconds, Action tick);
        void Stop();
    }
    public interface IEventDispatcherAdapter
    {
        void AttatchEvent<THandler>(object reciever, string eventName, THandler handler) where THandler : Delegate;
        void DetatchEvent<THandler>(object reciever, string eventName, THandler handler) where THandler : Delegate;



    }
    public interface IInteractionBlocker
    {
        void Block(object view);
        void Unblock(object view);
    }

    public interface IMovableAdapter
    {
        void MakeMovable(object view);
        void RemoveMovable(object view);
    }
    public interface IPlatformAdapter
    {
        bool CanHandle(object host);

        IPageHost CreateHost(object host);
        IPageMask CreateMask(object host);
        IEventDispatcherAdapter CreateEventDispatcher(object host);
        IInteractionBlocker CreateInteractionBlocker(object host);
        ITimerAdapter CreateTimerAdapter();
    }
}
