﻿using PageNav.Core.Abstractions;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PageNav.WinForms
{
    public class PageView : UserControl, IPageView
    {

        private bool _designMode;

        public event Action<object> ChildViewAdded;
        public event Action<object> ChildViewRemoved;
        public event Action OnDetachEvent;

        protected PageView()
        {
            _designMode = DesignMode || LicenseManager.UsageMode == LicenseUsageMode.Designtime;

            if(!_designMode)
            {
                // Runtime initialization here
                this.Visible = false;
                this.Dock = DockStyle.Fill;
            }
            // no runtime logic here
        }


        // --- Designer-safe properties ---
        [Browsable(false)]
        public virtual object NativeView => this;

        [Browsable(false)]
        public bool IsVisible { get => this.Visible; set => this.Visible = value; }

        [Browsable(false)]
        public bool IsLocked { get; set; }

        protected override void OnControlAdded(ControlEventArgs e)
        {
            base.OnControlAdded(e);
            ChildViewAdded?.Invoke(e.Control);
        }

        protected override void OnControlRemoved(ControlEventArgs e)
        {
            base.OnControlRemoved(e);
            ChildViewRemoved?.Invoke(e.Control);
        }

        bool IPageView.DesignMode => DesignMode;

        // --- Lifecycle ---
        public virtual void OnAttach(IPageHost host)
        {
            if(_designMode) return; // Designer must NOT run host logic
            host.AddView(this);
        }

        public virtual void OnDetach()
        {
            if(_designMode) return;
            OnDetachEvent?.Invoke();
            this.Parent?.Controls.Remove(this);
        }

        public virtual Task ReloadAsync(object args)
        {
            return Task.CompletedTask;
        }

        public virtual void Enable() { if(_designMode) return; }

        public virtual void Disable() { if(_designMode) return; }

        public virtual async Task ReleaseResources() { if(_designMode) return; }

        // Avoid disposing issues in designer
        protected override void Dispose(bool disposing)
        {
            if(!_designMode)
                base.Dispose(disposing);
        }
    }
}
