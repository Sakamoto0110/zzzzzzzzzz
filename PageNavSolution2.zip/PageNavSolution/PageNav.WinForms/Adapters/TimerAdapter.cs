﻿using PageNav.Core.Abstractions;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PageNav.WinForms.Adapters
{
    public class TimerAdapter : ITimerAdapter
    {
        private Timer _timer;
        private Action _tick;

        public void Start(int intervalMilliseconds, Action tick)
        {
            _tick = tick;

            _timer = new Timer();
            _timer.Interval = intervalMilliseconds;
            _timer.Tick -= TimerTick;
            _timer.Tick += TimerTick;
            _timer.Start();
        }

        private void TimerTick(object sender, EventArgs e) => _tick?.Invoke();

        public void Stop() => _timer?.Stop();

        public void Dispose() => _timer?.Dispose();
    }
}
