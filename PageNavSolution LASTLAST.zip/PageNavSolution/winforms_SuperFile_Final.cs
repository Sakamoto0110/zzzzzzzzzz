﻿
namespace PageNav.WinForms.Adapters
{
 
    public class EventDispatcherAdapter : IEventDispatcherAdapter
    {

        protected readonly Dictionary<object, HashSet<string>> _attachedEvents = new Dictionary<object, HashSet<string>>();
        protected readonly static Dictionary<(Type, string), EventInfo> _eventCache = new Dictionary<(Type, string), EventInfo>();
       
        public void AttatchEvent<THandler>(object reciever, string eventName, THandler handler) where THandler : Delegate
        {
            if(reciever is System.Windows.Forms.Control c)
                AttatchEventInternal(c, eventName, handler);
        }

        public void DetatchEvent<THandler>(object reciever, string eventName, THandler handler) where THandler : Delegate
        {
            if(reciever is System.Windows.Forms.Control c)
                DetatchEventInternal(c, eventName, handler);
        }

     
        private void AttatchEventInternal<THandler>(System.Windows.Forms.Control reciever, string eventName, THandler handler) where THandler : Delegate
        {
            if(!_attachedEvents.TryGetValue(reciever, out var events))
                _attachedEvents[reciever] = events = new HashSet<string>();

            
            if(events.Contains(eventName))
                return;

            var ev = GetEvent(reciever.GetType(), eventName);
            ev.AddEventHandler(reciever, handler);
            events.Add(eventName);

           
            foreach(System.Windows.Forms.Control c in reciever.Controls)
                AttatchEventInternal(c, eventName, handler);
        }
        private void DetatchEventInternal<THandler>(System.Windows.Forms.Control reciever, string eventName, THandler handler) where THandler : Delegate
        {
            if(_attachedEvents.TryGetValue(reciever, out var events) && events.Contains(eventName))
            {
                var ev = GetEvent(reciever.GetType(), eventName);
                ev.RemoveEventHandler(reciever, handler);
                events.Remove(eventName);

                if(events.Count == 0)
                    _attachedEvents.Remove(reciever);
            }

            foreach(Control child in reciever.Controls)
                DetatchEventInternal(child, eventName, handler);

        }
        protected EventInfo GetEvent(Type type, string name)
        {
            if(!_eventCache.TryGetValue((type, name), out var info))
            {
                info = type.GetEvent(name)
                    ?? throw new ArgumentException($"Event '{name}' not found on type '{type.Name}'.");
                _eventCache[(type, name)] = info;
            }
            return info;
        }
    }
}

namespace PageNav.WinForms.Adapters
{
    public class InteractionBlocker : IInteractionBlocker
    {
        public void Block(object view)
        {
            if(view is System.Windows.Forms.Control c)
                SetChildrenEnabled(c, false);
        }

        public void Unblock(object view)
        {
            if(view is System.Windows.Forms.Control c)
                SetChildrenEnabled(c, true);
        }

        private void SetChildrenEnabled(System.Windows.Forms.Control c, bool state)
        {
            foreach(System.Windows.Forms.Control child in c.Controls)
                child.Enabled = state;
        }
    }
}

namespace PageNav.WinForms.Adapters
{
    public sealed class MovableWindowsFormsAdapter : IMovableAdapter
    {
        private class HandlerSet
        {
            public MouseEventHandler MouseDown;
            public MouseEventHandler MouseMove;
            public MouseEventHandler MouseUp;
            public ControlEventHandler ControlAdded;
            public ControlEventHandler ControlRemoved;
        }

        private readonly Dictionary<Control, HandlerSet> _handlerMap = new Dictionary<Control, HandlerSet>();

        public void MakeMovable(object view)
        {
            if(!(view is Control ctrl))
                throw new ArgumentException("WinForms movable target must be a Control.");

            if(_handlerMap.ContainsKey(ctrl))
                return;

            Point offset = Point.Empty;
            bool isDragging = false;

            var handlers = new HandlerSet();

            handlers.MouseDown = (s, e) => {
                if(e.Button == MouseButtons.Left)
                {
                    isDragging = true;
                    offset = ctrl.PointToClient(Control.MousePosition);
                }
            };

            handlers.MouseMove = (s, e) => {
                if(!isDragging || ctrl.Parent == null) return;

                var mousePos = ctrl.Parent.PointToClient(Control.MousePosition);
                int x = mousePos.X - offset.X;
                int y = mousePos.Y - offset.Y;

                x = Math.Max(0, Math.Min(x, ctrl.Parent.ClientSize.Width - ctrl.Width));
                y = Math.Max(0, Math.Min(y, ctrl.Parent.ClientSize.Height - ctrl.Height));

                ctrl.Location = new Point(x, y);
            };

            handlers.MouseUp = (s, e) => {
                if(e.Button == MouseButtons.Left)
                    isDragging = false;
            };

            handlers.ControlAdded = (s, e) => AttachHandlers(e.Control, handlers);
            handlers.ControlRemoved = (s, e) => DetachHandlers(e.Control, handlers);

            AttachHandlers(ctrl, handlers);

            ctrl.ControlAdded += handlers.ControlAdded;
            ctrl.ControlRemoved += handlers.ControlRemoved;

            _handlerMap[ctrl] = handlers;
        }

        public void RemoveMovable(object view)
        {
            if(!(view is   Control ctrl)) return;

            if(!_handlerMap.TryGetValue(ctrl, out var handlers))
                return;

            DetachHandlers(ctrl, handlers);
            ctrl.ControlAdded -= handlers.ControlAdded;
            ctrl.ControlRemoved -= handlers.ControlRemoved;

            _handlerMap.Remove(ctrl);
        }

        private void AttachHandlers(Control parent, HandlerSet handlers)
        {
            parent.MouseDown += handlers.MouseDown;
            parent.MouseMove += handlers.MouseMove;
            parent.MouseUp += handlers.MouseUp;

            foreach(Control child in parent.Controls)
                AttachHandlers(child, handlers);
        }

        private void DetachHandlers(Control parent, HandlerSet handlers)
        {
            parent.MouseDown -= handlers.MouseDown;
            parent.MouseMove -= handlers.MouseMove;
            parent.MouseUp -= handlers.MouseUp;

            foreach(Control child in parent.Controls)
                DetachHandlers(child, handlers);
        }
    }
}

namespace PageNav.WinForms.Adapters
{
    public class PageMaskAdapter : IPageMask
    {
        private readonly Panel _mask = new Panel();
        private readonly Label _label = new Label();

        public PageMaskAdapter(Control host)
        {
            
            _mask.BackColor = Color.FromArgb(180, Color.Black); 
            _mask.Dock = DockStyle.Fill;
            _mask.Visible = false;

            _label.Dock = DockStyle.Fill;
            _label.TextAlign = ContentAlignment.MiddleCenter;
            _label.ForeColor = Color.White;
            _label.Font = new Font("Segoe UI", 16, FontStyle.Bold);

            _mask.Controls.Add(_label);
            host.Controls.Add(_mask);
            _mask.BringToFront();
        }

        public void Show(string message = "")
        {
            _label.Text = message;
            _mask.Visible = true;
            _mask.BringToFront();
        }

        public void Hide()
        {
            _mask.Visible = false;
        }
    }

}

namespace PageNav.WinForms.Adapters
{
    public class TimerAdapter : ITimerAdapter
    {
        private Timer _timer;
        private Action _tick;

        public void Start(int intervalMilliseconds, Action tick)
        {
            _tick = tick;

            _timer = new Timer();
            _timer.Interval = intervalMilliseconds;
            _timer.Tick -= TimerTick;
            _timer.Tick += TimerTick;
            _timer.Start();
        }

        private void TimerTick(object sender, EventArgs e) => _tick?.Invoke();

        public void Stop() => _timer?.Stop();

        public void Dispose() => _timer?.Dispose();

        public void Continue()
        {
            _timer?.Start();
        }
    }
}

namespace PageNav.WinForms.Adapters
{
    public sealed class WeakEventDispatcherAdapter : IEventDispatcherAdapter
    {
        private class WeakHandler
        {
            public WeakReference Receiver;
            public WeakReference Handler;
            public EventInfo EventInfo;
            public Delegate Proxy;
        }

        private readonly List<WeakHandler> _handlers = new List<WeakHandler>();
        private readonly object _lock = new object();

        public void AttatchEvent<THandler>(object receiver, string eventName, THandler handler) where THandler : Delegate
        {
            if(receiver is System.Windows.Forms.Control c)
                AttatchEventInternal(c, eventName, handler);
        }
        public void DetatchEvent<THandler>(object receiver, string eventName, THandler handler) where THandler : Delegate

        {
            if(receiver is System.Windows.Forms.Control c)
                DetatchEventInternal(c, eventName, handler);
        }

        public void AttatchEventInternal<THandler>(System.Windows.Forms.Control receiver, string eventName, THandler handler) where THandler : Delegate
        {
            if(receiver == null || handler == null) return;
            var ev = receiver.GetType().GetEvent(eventName);

            
            Delegate proxy = CreateProxy(ev.EventHandlerType, handler);

            lock(_lock)
            {
                _handlers.Add(new WeakHandler
                {
                    Receiver = new WeakReference(receiver),
                    Handler = new WeakReference(handler),
                    EventInfo = ev,
                    Proxy = proxy
                });
            }

            ev.AddEventHandler(receiver, proxy);
            foreach(System.Windows.Forms.Control c in receiver.Controls)
                AttatchEventInternal(c, eventName, handler);
           

        }
        public void DetatchEventInternal<THandler>(System.Windows.Forms.Control receiver, string eventName, THandler handler) where THandler : Delegate
        {
            lock(_lock)
            {
                var target = _handlers.FirstOrDefault(x =>
                    x.Receiver.Target == receiver &&
                    x.EventInfo.Name == eventName &&
                    x.Handler.Target == (object)handler);

                if(target == null) return;

                target.EventInfo.RemoveEventHandler(receiver, target.Proxy);
                _handlers.Remove(target);
                foreach(Control child in receiver.Controls)
                    DetatchEventInternal(child, eventName, handler);
            }
        }
        
        
        
        
        
        
        
        
        
        
        
        private Delegate CreateProxy(Type eventType, Delegate originalHandler)
        {
            return Delegate.CreateDelegate(eventType, this,
                GetType().GetMethod(nameof(InvokeWeak), BindingFlags.NonPublic | BindingFlags.Instance)
                .MakeGenericMethod(originalHandler.GetType()));
        }

        private void InvokeWeak<THandler>(object sender, EventArgs e) where THandler : Delegate
        {
            CleanupDead();

            lock(_lock)
            {
                foreach(var entry in _handlers.ToArray())
                {

                    if(entry.Handler.IsAlive && entry.Handler.Target != null)
                    {
                        ((Delegate)entry.Handler.Target).DynamicInvoke(sender, e);
                    }
                }
            }
        }

        private void CleanupDead()
        {
            lock(_lock)
            {
                _handlers.RemoveAll(h => !h.Receiver.IsAlive || !h.Handler.IsAlive);
            }
        }
    }
}

namespace PageNav.WinForms
{
    public class PageHost : IPageHost
    {
        private readonly Control _container;

        public PageHost(Control container)
        {
            _container = container;
        }

        public void AddView(object view)
        {
            if(view is Control ctrl)
                _container.Controls.Add(ctrl);
        }

        public void RemoveView(object view)
        {
            if(view is Control ctrl)
                _container.Controls.Remove(ctrl);
        }

        public void BringToFront(object view)
        {
            if(view is Control ctrl)
                ctrl.BringToFront();
        }

        public void Focus(object view)
        {
            if(view is Control ctrl)
                ctrl.Focus();
        }
    }
}

 

namespace PageNav.WinForms
{
    public class PlatformAdapter : IPlatformAdapter
    {
        public bool CanHandle(object host) => host is System.Windows.Forms.Control;

        public IPageHost CreateHost(object host) =>
            new PageHost((Control)host);

        public IPageMask CreateMask(object host) =>
            new PageMaskAdapter((Control)host);

        public IEventDispatcherAdapter CreateEventDispatcher(object host) =>
            new EventDispatcherAdapter();

        public IInteractionBlocker CreateInteractionBlocker(object host) =>
            new InteractionBlocker();

        public ITimerAdapter CreateTimerAdapter() =>
            new TimerAdapter();
        public IDialogService CreateDialogService(object host) => new WinFormsDialogService();
    }

    public static class WinFormsBootstrap
    {
        public static void Register() =>
            PlatformRegistry.Register(new PlatformAdapter());
    }
}

[assembly: AssemblyTitle("PageNav.WinForms")]
[assembly: AssemblyDescription("")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("")]
[assembly: AssemblyProduct("PageNav.WinForms")]
[assembly: AssemblyCopyright("Copyright ©  2025")]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyCulture("")]

[assembly: ComVisible(false)]

[assembly: Guid("bf73bb61-ac52-47b8-9a34-2d2dac5d0b5e")]

[assembly: AssemblyVersion("1.0.0.0")]
[assembly: AssemblyFileVersion("1.0.0.0")]

namespace PageNav.WinForms.Services
{
    public class WinFormsDialogService : IDialogService
    {
        public Task<DialogResult> ShowMessageAsync(string message, string title = null, DialogIcon icon = DialogIcon.Info)
        {
            return Task.FromResult(Convert(
                MessageBox.Show(message, title ?? "Info")));
        }

        public Task<DialogResult> ShowConfirmAsync(string message, string title = null, DialogIcon icon = DialogIcon.Question)
        {
            return Task.FromResult(Convert(
                MessageBox.Show(message, title ?? "Confirm")));
        }

        private DialogResult Convert(System.Windows.Forms.DialogResult input)
        {
            switch(input)
            {
                case System.Windows.Forms.DialogResult.OK: return DialogResult.Ok;
                case System.Windows.Forms.DialogResult.Yes: return DialogResult.Yes;
                case System.Windows.Forms.DialogResult.Cancel: return DialogResult.Cancel;
                case System.Windows.Forms.DialogResult.No: return DialogResult.No;
                case System.Windows.Forms.DialogResult.Abort: return DialogResult.Abort;
                case System.Windows.Forms.DialogResult.Ignore: return DialogResult.Ignore;
                case System.Windows.Forms.DialogResult.Retry: return DialogResult.Retry;
                default: return DialogResult.None;
            }
        }

    }
}

namespace PageNav.WinForms.Controls
{
    public class BaseDialogForm : Form
    {
        private TaskCompletionSource<DialogResult> _tcs;
        private bool _initialized;

        public bool Draggable { get; set; } = true;
        public bool DimBackground { get; set; } = true;
        public int PaddingAmount { get; set; } = 20;

        private Panel _backgroundDim;
        private Control _dragSource;
        private Point _dragOffset;

        public BaseDialogForm()
        {
            FormBorderStyle = FormBorderStyle.None;
            StartPosition = FormStartPosition.Manual;
            BackColor = Color.White;
            DoubleBuffered = true;
            KeyPreview = true;
            MinimumSize = new Size(300, 180);

            KeyDown += (_, e) => {
                if(e.KeyCode == Keys.Escape)
                    CloseDialog(DialogResult.Cancel);
            };
        }

        public void BindDragArea(Control ctrl)
        {
            _dragSource = ctrl;
            ctrl.MouseDown += DragMouseDown;
            ctrl.MouseMove += DragMouseMove;
        }

        private void DragMouseDown(object sender, MouseEventArgs e)
        {
            if(!Draggable) return;
            _dragOffset = new Point(e.X, e.Y);
        }

        private void DragMouseMove(object sender, MouseEventArgs e)
        {
            if(!Draggable || e.Button != MouseButtons.Left) return;

            var screenPos = Cursor.Position;
            Location = new Point(screenPos.X - _dragOffset.X, screenPos.Y - _dragOffset.Y);
        }

        public async Task<DialogResult> ShowDialogAsync(Control host)
        {
            if(!_initialized)
            {
                _initialized = true;
                InitializeOverlay(host);
            }

            _tcs = new TaskCompletionSource<DialogResult>();

            base.Show(host);
            BringToFront();
            CenterOnHost(host);

            FadeInAsync();

            return await _tcs.Task;
        }

        private void InitializeOverlay(Control host)
        {
            if(!DimBackground) return;

            _backgroundDim = new Panel
            {
                BackColor = Color.FromArgb(120, 0, 0, 0),
                Dock = DockStyle.Fill,
                Visible = true
            };

            host.Controls.Add(_backgroundDim);
            _backgroundDim.BringToFront();
        }

        private void CenterOnHost(Control host)
        {
            var hostRect = host.RectangleToScreen(host.ClientRectangle);
            var x = hostRect.X + (hostRect.Width - Width) / 2;
            var y = hostRect.Y + (hostRect.Height - Height) / 2;
            Location = new Point(Math.Max(0, x), Math.Max(0, y));
        }

        public void CloseDialog(DialogResult result)
        {
            _ = FadeOutAsync(result);
        }

        protected override void OnFormClosed(FormClosedEventArgs e)
        {
            _backgroundDim?.Dispose();
            base.OnFormClosed(e);
        }

        private async Task FadeOutAsync(DialogResult result)
        {
            for(double f = 1.0; f >= 0.0; f -= 0.1)
            {
                Opacity = f;
                await Task.Delay(10);
            }

            _tcs.TrySetResult(result);
            Close();
        }

        private async void FadeInAsync()
        {
            Opacity = 0;
            for(double f = 0.0; f <= 1.0; f += 0.1)
            {
                Opacity = f;
                await Task.Delay(10);
            }
        }
    }
}

namespace PageNav.WinForms
{
    public class PageView : UserControl, IPageView
    {

        private bool _designMode;

        public event Action<object> ChildViewAdded;
        public event Action<object> ChildViewRemoved;
        public event Action OnDetachEvent;

        protected PageView()
        {
            _designMode = DesignMode || LicenseManager.UsageMode == LicenseUsageMode.Designtime;

            if(!_designMode)
            {
                
                this.Visible = false;
               
            }
            
        }

        
        [Browsable(false)]
        public virtual object NativeView => this;

        [Browsable(false)]
        public bool IsVisible { get => this.Visible; set => this.Visible = value; }

        [Browsable(false)]
        public bool IsLocked { get; set; }

        protected override void OnControlAdded(ControlEventArgs e)
        {
            base.OnControlAdded(e);
            ChildViewAdded?.Invoke(e.Control);
        }

        protected override void OnControlRemoved(ControlEventArgs e)
        {
            base.OnControlRemoved(e);
            ChildViewRemoved?.Invoke(e.Control);
        }

        bool IPageView.DesignMode => DesignMode;

        
        public virtual void OnAttach(IPageHost host)
        {
            if(_designMode) return; 
            host.AddView(this);
        }

        public virtual void OnDetach()
        {
            if(_designMode) return;
            OnDetachEvent?.Invoke();
            this.Parent?.Controls.Remove(this);
        }

        public virtual Task Reload(object args)
        {
            return Task.CompletedTask;
        }

        public virtual void Enable() { if(_designMode) return; }

        public virtual void Disable() { if(_designMode) return; }

        public virtual async Task ReleaseResources() { if(_designMode) return; }

        
        protected override void Dispose(bool disposing)
        {
            if(!_designMode)
                base.Dispose(disposing);
        }
    }
}

[assembly: global::System.Runtime.Versioning.TargetFrameworkAttribute(".NETFramework,Version=v4.8.1", FrameworkDisplayName = ".NET Framework 4.8.1")]

public class ConfirmDialog : BaseDialogForm
{
    private Label lblMessage;
    private Button btnYes, btnNo;

    public ConfirmDialog(string message, string title = "Confirm")
    {
        Text = title;

        lblMessage = new Label
        {
            Text = message,
            AutoSize = false,
            TextAlign = ContentAlignment.MiddleCenter,
            Dock = DockStyle.Fill,
            Font = new Font("Segoe UI", 12)
        };

        btnYes = new Button { Text = "Yes", Dock = DockStyle.Bottom };
        btnNo = new Button { Text = "No", Dock = DockStyle.Bottom };

        btnYes.Click += (_, __) => CloseDialog(DialogResult.Yes);
        btnNo.Click += (_, __) => CloseDialog(DialogResult.No);

        Controls.Add(lblMessage);
        Controls.Add(btnYes);
        Controls.Add(btnNo);

        BindDragArea(lblMessage);
    }
}

