﻿using PageNav.Core.Abstractions;
using PageNav.Core.Models;
using System.Collections.Generic;
using System.Linq;

namespace PageNav.Core.Services.Navigation {
public static partial class NavigationService
{
    public static class History
    {
        private static readonly Stack<PageHistoryEntry> _back =    new Stack<PageHistoryEntry>();
        private static readonly Stack<PageHistoryEntry> _forward = new Stack<PageHistoryEntry>();

        public static bool CanGoBack => _back.Count > 0;
        public static bool CanGoForward => _forward.Count > 0;

        internal static void Record(IPageView fromPage)
        {
            if(fromPage == null) return;
            _back.Push(new PageHistoryEntry(fromPage));
            _forward.Clear();
        }

        internal static PageHistoryEntry PopBack() => _back.Pop();
        internal static void PushForward(PageHistoryEntry entry) => _forward.Push(entry);
        internal static PageHistoryEntry PopForward() => _forward.Pop();

        public static IEnumerable<PageHistoryEntry> HistoryBack => _back.ToList();
        public static IEnumerable<PageHistoryEntry> HistoryForward => _forward.ToList();
    }
 
}
}
