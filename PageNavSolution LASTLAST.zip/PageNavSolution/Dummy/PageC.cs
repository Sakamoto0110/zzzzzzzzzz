﻿using PageNav.Core.Services;
using PageNav.WinForms;
using PageNav.WinForms;
using System;
using System.Drawing;
using System.Threading.Tasks;
using System.Windows.Forms;

[PageNav.Core.Services.PageBehavior(cachePolicy: PageCachePolicy.Stackable, WaitCompletionBeforeShow = NavigationLoadMode.LoadInBackground)]
public class PageC : PageView
{
    static Color[] Colors =
    {
        Color.AliceBlue,
        Color.Blue,
        Color.Green,
        Color.Ivory,
        Color.HotPink
    };
    static int idx = 0;
    public PageC()
    {
        Name = "Páge C";
        
        this.Controls.Add(new Label { Text = "PAGE C", AutoSize = true, Font = new System.Drawing.Font("Segoe UI", 16F) });
    }

    public override async Task Reload(object args)
    {
       
    }

    public override async Task OnEnter(object args)
    {
        await Task.Delay(400);
        this.BackColor = Colors[idx++ % Colors.Length];
    }
}
