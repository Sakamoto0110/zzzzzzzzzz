﻿namespace PageNav.Core.Abstractions
{
    public interface IPageStateful
    {
        object CaptureState();
    }
}
