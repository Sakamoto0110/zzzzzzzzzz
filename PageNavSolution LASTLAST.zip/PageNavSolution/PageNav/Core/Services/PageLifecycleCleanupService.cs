﻿using PageNav.Core.Abstractions;
using PageNav.Core.Services;
using PageNav.Diagnostics;
using System;
using System.Threading.Tasks;

internal static class PageLifecycleCleanupService
{
    public static async Task CleanupAsync(IPageView page,IEventDispatcherAdapter dispatcher, bool forceDispose = false)
    {
        if(page == null)
            return;
         if(!PageRegistry.TryToGetDescriptor(page.GetType(), out var desc))
            throw new InvalidOperationException($"PageDescriptor of {page.GetType()} not found.");
        
        var effectivePolicy = forceDispose? PageCachePolicy.Disabled: desc.CachePolicy;
 
        PageLifecycleTracker.Update(page, PageLifecycleState.Leaving);

        // Only framework-owned event cleanup
        if(dispatcher != null && page.NativeView != null)
        {
            dispatcher.DetatchEvent<EventHandler>(
                page.NativeView,
                "Click",
                TimeoutService.Reset);
        }

        switch(desc.CachePolicy)
        {
            case PageCachePolicy.Disabled:
            case PageCachePolicy.Stackable:
                await SafeRelease(page);
                DisposePage(page);
                PageLifecycleTracker.Update(page, PageLifecycleState.Disposed);
                PageLifecycleTracker.Unregister(page);
                break;

            case PageCachePolicy.WeakSingleton:
                await SafeRelease(page);
                PageLifecycleTracker.Update(page, PageLifecycleState.Released);
                break;

            case PageCachePolicy.StrongSingleton:
                PageLifecycleTracker.Update(page, PageLifecycleState.Detached);
                break;
        }
    }

    private static async Task SafeRelease(IPageView page)
    {
        try
        {
            await page.ReleaseResources();
        }
        catch(Exception ex)
        {
            PageLogger.LogError(
                $"ReleaseResources failed on {page.Name}: {ex}");
        }
    }

    private static void DisposePage(IPageView page)
    {
        try
        {
            page.Dispose();
        }
        catch(Exception ex)
        {
            PageLogger.LogError(
                $"Dispose failed on {page.Name}: {ex}");
        }
    }
}
