﻿using PageNav.Core.Abstractions;
using PageNav.Core.Models;
using PageNav.Diagnostics;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;
using static PageNav.Core.Services.NavigationService;
using static PageNav.Core.Services.TimeoutService;

namespace PageNav.Core.Services
{
    // ============================================================
    // ENUMS
    // ============================================================

    /// <summary>
    /// Describes the behavioral category of a page.
    /// May combine flags such as Modal + Popup.
    /// </summary>
    [Flags]
    public enum PageKind
    {
        Home = 1,
        Default = 2,
        Modal = 4,
        Popup = 8
    }

    /// <summary>
    /// Controls how a page is cached and instantiated.
    /// </summary>
    public enum PageCachePolicy
    {
        None = 0,
        Disabled = 1,
        WeakSingleton = 2,
        StrongSingleton = 4,
        Stackable = 8
    }

   

    // ============================================================
    // ATTRIBUTE
    // ============================================================

    /// <summary>
    /// Defines metadata for a page class, such as cache policy, name override, and tags.
    /// </summary>
    [AttributeUsage(AttributeTargets.Class, AllowMultiple = false)]
    public sealed class PageBehaviorAttribute : Attribute
    {
        public TimeoutBehavior Timeout { get; set; } = TimeoutBehavior.Default;

        public NavigationLoadMode WaitCompletionBeforeShow { get; set; } = NavigationLoadMode.ShowImmediately;
        /// <summary>Defines the page category.</summary>
        public PageKind Kind { get; private set; }

        /// <summary>Defines how the page is cached.</summary>
        public PageCachePolicy CachePolicy { get; private set; }

        /// <summary>
        /// Optional new name used for registration instead of the class name.
        /// </summary>
        public string NameOverride { get; set; }

        /// <summary>
        /// Optional found of tags assigned to the page.
        /// </summary>
        public string[] Tags { get; set; }

        /// <summary>
        /// Creates a new attribute describing page behavior.
        /// </summary>
        public PageBehaviorAttribute(
            PageKind kind = PageKind.Default,
            PageCachePolicy cachePolicy = PageCachePolicy.Disabled)
        {
            Kind = kind;
            CachePolicy = cachePolicy;
        }
    }

    // ============================================================
    // MAIN REGISTRY
    // ============================================================

    /// <summary>
    /// Central repository storing metadata for all pages.
    /// Handles registration, tag queries, instance creation and caching.
    /// </summary>
    public static class PageRegistry
    {
        private static readonly Dictionary<string, PageDescriptor> _registry =
            new Dictionary<string, PageDescriptor>(StringComparer.OrdinalIgnoreCase);

        // ------------------------------------------------------------
        // REGISTRATION
        // ------------------------------------------------------------

        /// <summary>
        /// Registers a page type that implements IPageView.
        /// </summary>
        public static void Register<T>() where T : IPageView
        {
            Register(typeof(T));
        }

        /// <summary>
        /// Registers all IPageView classes found inside an assembly.
        /// </summary>
        public static void RegisterFromAssembly(Assembly asm)
        {
            foreach(Type t in asm.GetTypes())
            {
                if(IsPageType(t))
                    Register(t);
            }
        }

        /// <summary>
        /// Scans <see cref="Assembly.GetExecutingAssembly"/> and registers all pages.
        /// Designer-safe.
        /// </summary>
        public static bool TryRegisterFromCurrentAssembly()
        {
            Assembly asm = Assembly.GetExecutingAssembly();
            List<Type> found = new List<Type>();

            foreach(Type t in asm.GetTypes())
            {
                if(IsPageType(t))
                {
                    Register(t);
                    found.Add(t);
                }
            }
            PageLogger.LogInfo("Auto-registered " + found.Count + " pages from executing assembly.");

            return found.Count > 0;
        }

        private static bool IsPageType(Type t)
        {
            return typeof(IPageView).IsAssignableFrom(t) && !t.IsAbstract;
        }

        /// <summary>
        /// Registers a concrete page type.
        /// </summary>
        public static void Register(Type pageType)
        {
            if(!IsPageType(pageType))
                throw new ArgumentException("Type must implement IPageView.", "pageType");

            PageBehaviorAttribute attr =
                (PageBehaviorAttribute)pageType.GetCustomAttributes(typeof(PageBehaviorAttribute), true)
                    .FirstOrDefault();

            string name = attr != null && attr.NameOverride != null
                ? attr.NameOverride
                : pageType.Name;

            if(_registry.ContainsKey(name))
            {
                PageLogger.LogWarn("Attempt to register duplicate page '" + name + "' ignored.");
                return;
            }

            PageDescriptor d = new PageDescriptor();
            d.PageType = pageType;
            d.Name = name;
            d.Kind = attr != null ? attr.Kind : PageKind.Default;
            d.CachePolicy = attr != null ? attr.CachePolicy : PageCachePolicy.Disabled;
            d.Timeout = attr != null ? attr.Timeout : TimeoutBehavior.Default;
            d.WaitCompletionBeforeShow = attr != null ? attr.WaitCompletionBeforeShow : NavigationLoadMode.ShowImmediately;
            if(attr != null && attr.Tags != null)
            {
                foreach(string s in attr.Tags)
                    d.Tags.Add(s);
            }

            _registry[name] = d;
            PageLogger.LogInfo($"Registered Page '{name}' (Type={pageType.Name}), Kind={d.Kind}, CachePolicy={d.CachePolicy}, Tags=[{string.Join(",", d.Tags.ToArray())}])");

        }

        // ------------------------------------------------------------
        // TAGS
        // ------------------------------------------------------------

        /// <summary>Adds a tag to a registered page.</summary>
        public static void AddTag(string pageName, string tag)
        {
            PageDescriptor d;
            if(_registry.TryGetValue(pageName, out d))
            {
                d.Tags.Add(tag);
                PageLogger.LogInfo("Tag '" + tag + "' added to page '" + pageName + "'.");
            }
        }

        /// <summary>Returns true if the page contains the tag.</summary>
        public static bool HasTag(string pageName, string tag)
        {
            PageDescriptor d;
            return _registry.TryGetValue(pageName, out d) && d.Tags.Contains(tag);
        }

        /// <summary>Returns all tags assigned to the page.</summary>
        public static IEnumerable<string> GetTags(string pageName)
        {
            PageDescriptor d;
            if(_registry.TryGetValue(pageName, out d))
                return d.Tags;

            return new string[0];
        }

        // ------------------------------------------------------------
        // QUERY
        // ------------------------------------------------------------

        /// <summary>
        /// Returns the first page instance matching the given tag.
        /// </summary>
        public static IPageView FirstByTag(string tag)
        {
            foreach(PageDescriptor d in _registry.Values)
            {
                if(d.Tags.Contains(tag))
                {
                    PageLogger.LogInfo("FirstByTag('" + tag + "') resolved page '" + d.Name + "'.");
                    return Resolve(d.PageType, d.Name);
                }
            }
            PageLogger.LogWarn("FirstByTag('" + tag + "') found no matching page.");

            return null;
        }

        /// <summary>
        /// Returns all instances of pages containing the specified tag.
        /// </summary>
        public static IEnumerable<IPageView> AllByTag(string tag)
        {
            foreach(PageDescriptor d in _registry.Values)
            {
                if(d.Tags.Contains(tag))
                {
                    PageLogger.LogInfo("AllByTag('" + tag + "') yielding page '" + d.Name + "'.");
                    yield return Resolve(d.PageType, d.Name);
                }
            }
        }

        // ------------------------------------------------------------
        // RESOLUTION / CREATION
        // ------------------------------------------------------------

        /// <summary>
        /// Resolves a page by name, applying the configured cache policy.
        /// </summary>
        public static IPageView Resolve(Type type, string name, bool silent = false)
        {
            PageDescriptor info;
            if(!_registry.TryGetValue(name, out info))
            {
                PageLogger.LogWarn("Resolve('" + name + "') triggered auto-registration.");

                // auto-register fallback
                info = new PageDescriptor();
                info.Name = name;
                info.PageType = type;
                info.Kind = PageKind.Default;
                info.CachePolicy = PageCachePolicy.Disabled;
                _registry[name] = info;

            }
            if(!silent)
                PageLogger.LogInfo("Resolve('" + name + "') using CachePolicy=" + info.CachePolicy);
            switch(info.CachePolicy)
            {
                case PageCachePolicy.Disabled:
                    return Create(info);

                case PageCachePolicy.WeakSingleton:
                    if(info.CachedInstance == null)
                        info.CachedInstance = Create(info);
                    return info.CachedInstance;

                case PageCachePolicy.StrongSingleton:
                    if(info.CachedInstance == null)
                        info.CachedInstance = Create(info);
                    return info.CachedInstance;

                case PageCachePolicy.Stackable:
                    return PushStack(info);
            }

            return Create(info);
        }

        public static bool TryToGetDescriptor(Type type, out PageDescriptor desc)
        {
            if(_registry.Count > 0)
            {
                desc = _registry.Values.First(x => x.PageType == type);
                return true;
            }
            desc = null;
            return false;
        }
            public static PageDescriptor GetDescriptor(Type type)
        {
            if(_registry.Count>0)
                return _registry.Values.First(x => x.PageType == type);
            return default;
        }
        private static IPageView Create(PageDescriptor d)
        {
            var page = (IPageView)Activator.CreateInstance(d.PageType);
            PageLogger.LogInfo("Created new instance of page '" + d.Name + "'.");
            return page;
        }
        public static IPageView CreateNew(Type type, string name)
        {
            var info = new PageDescriptor
            {
                PageType = type,
                Name = name,
                Kind = PageKind.Default,
                CachePolicy = PageCachePolicy.Disabled
            };
            return Create(info);
        }
        private static IPageView PushStack(PageDescriptor d)
        {
            IPageView page = Create(d);
            d.StackInstances.Push(page);
            PageLogger.LogInfo("Stack PUSH for page '" + d.Name + "'. Stack count now: " + d.StackInstances.Count);
            page.OnDetachEvent += async () =>
            {
                if(d.StackInstances.Count > 0 &&
                    Object.ReferenceEquals(d.StackInstances.Peek(), page))
                {
                    await PopStackAsync(d.Name);

                    PageLogger.LogInfo($"Auto Stack POP on detach ('{d.Name}') Stack count now:  {d.StackInstances.Count}");
                }
            };

            return page;
        }
        public static IPageView ResolveTimeoutTarget()
        {
            // 1) Try explicit Home kind
            var byKind = _registry.Values
                .FirstOrDefault(x => x.Kind == PageKind.Home);

            if(byKind != null)
                return Resolve(byKind.PageType, byKind.Name,true);

            // 2) Try "Home" tag
            var byTag = _registry.Values
                .FirstOrDefault(x => x.Tags.Contains("home", StringComparer.OrdinalIgnoreCase));

            if(byTag != null)
                return Resolve(byTag.PageType, byTag.Name);

            // 3) No dedicated home found — return null so caller can decide
            return null;
        }
        /// <summary>
        /// Pops the top instance of a stackable page.
        /// </summary>
        public static void PopStack(string name)
        {
            PageDescriptor d;
            if(!_registry.TryGetValue(name, out d))
                throw new InvalidOperationException("Page '" + name + "' not registered.");

            if(d.CachePolicy != PageCachePolicy.Stackable)
                throw new InvalidOperationException("Page '" + name + "' is not stackable.");

            if(d.StackInstances.Count > 0)
            {
                d.StackInstances.Pop();
                PageLogger.LogInfo($"Manual Stack POP for page '{name}'. New count: {d.StackInstances.Count}");
            }
            else
            {
                PageLogger.LogWarn($"PopStack('{name}') did nothing (stack empty).");

            }
        }

        public static async Task PopStackAsync(string name)
        {
            var d = _registry[name];

            if(d.CachePolicy != PageCachePolicy.Stackable)
                throw new InvalidOperationException("Not stackable.");

            if(d.StackInstances.Count == 0)
                return;
            
            var page = d.StackInstances.Pop();

            await page.ReleaseResources();
            if(page.IsDisposed)
                return;
            await PageLifecycleCleanupService.CleanupAsync(page,NavigationService._events);
        }

    }
}

