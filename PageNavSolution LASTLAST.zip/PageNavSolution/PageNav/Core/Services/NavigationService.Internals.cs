﻿using PageNav.Core.Abstractions;
using PageNav.Core.Models;
using PageNav.Diagnostics;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;
using static PageNav.Core.Services.NavigationService;


namespace PageNav.Core.Services
{
    public static partial class NavigationService
    {
        // -------------------------------------------------------------------------
        // INTERNAL CORE NAVIGATION LOGIC
        // -------------------------------------------------------------------------     
        private static bool _isNavigating;

        private static Task ResolveLoadAsync(
    IPageView page,
    object payload)
        {
            if(page is IBackgroundLoadable bg)
            {
                return RunBackgroundLoadAsync(bg, payload);
            }

            return page.Reload(payload);
        }
        private static async Task RunBackgroundLoadAsync(
    IBackgroundLoadable bg,
    object payload)
        {
            await Task.Run(() => bg.LoadInBackgroundAsync(payload))
                      .ConfigureAwait(false);

            await bg.ApplyBackgroundResultAsync();
        }




        private static async Task SwitchInternal(
    Type pageType,
    NavigationArgs navArgs)
        {
            if(_host == null)
                throw new InvalidOperationException(
                    "NavigationService.Initialize must be called first.");

            if(_isNavigating)
                return;

            _isNavigating = true;

            IPageView fromPage = Current;
            IPageView newPage = null;
            Task preloadTask = null;

            if(!PageRegistry.TryToGetDescriptor(pageType, out var toDesc))
                throw new InvalidOperationException($"PageDescriptor of {pageType} not found.");

            bool useMask = !navArgs.Behavior.HasFlag(NavigationBehavior.NoMask);
            bool useCache = !navArgs.Behavior.HasFlag(NavigationBehavior.Transient);
            bool recordHistory = !navArgs.Behavior.HasFlag(NavigationBehavior.NoHistory);

            if(useMask)
                PageMaskService.Show("Carregando...");

           
            try
            {
                Navigating?.Invoke(Current, pageType, navArgs);

                // ───────────────────────────────
                // Resolve + register
                // ───────────────────────────────
                newPage = useCache ? PageRegistry.Resolve(pageType, pageType.Name) : PageRegistry.CreateNew(pageType, pageType.Name);
                PageLifecycleTracker.Register(newPage, toDesc);

                // ───────────────────────────────
                // LEAVE old page
                // ───────────────────────────────
                if(fromPage is IPageLifecycle leave)
                    await leave.OnLeave();

                if(fromPage != null)
                {
                    fromPage.ChildViewAdded -= OnChildViewAdded;
                    fromPage.ChildViewRemoved -= OnChildViewRemoved;

                    // UI responsibility (ONLY here)
                    _host.Detach(fromPage);

                    // Logical cleanup (NO UI)
                    await PageLifecycleCleanupService.CleanupAsync(
                        fromPage,
                        _events);
                }

                // ───────────────────────────────
                // ATTACH new page
                // ───────────────────────────────
                _host.Attach(newPage);
                _host.BringToFront(newPage);

                newPage.IsVisible = true;
                Current = newPage;

                PageLifecycleTracker.Update(
                    newPage,
                    PageLifecycleState.Attached);

                // ───────────────────────────────
                // LOAD (strategy only)
                // ───────────────────────────────
                switch(toDesc.WaitCompletionBeforeShow)
                {
                    case NavigationLoadMode.LoadBeforeShow:
                        await ResolveLoadAsync(newPage, navArgs.Payload);
                        break;

                    case NavigationLoadMode.LoadInBackground:
                    case NavigationLoadMode.ShowImmediately:
                    default:
                        preloadTask = ResolveLoadAsync(newPage, navArgs.Payload);
                        break;
                }

                // ───────────────────────────────
                // ENTER (exactly once, always awaited)
                // ───────────────────────────────
                if(newPage is IPageLifecycle enter)
                    await enter.OnEnter(navArgs.Payload);

                PageLifecycleTracker.Update(
                    newPage,
                    PageLifecycleState.Entered);

                // ───────────────────────────────
                // Events
                // ───────────────────────────────
                _events?.AttatchEvent<EventHandler>(
                    newPage.NativeView,
                    "Click",
                    TimeoutService.Reset);

                newPage.ChildViewAdded += OnChildViewAdded;
                newPage.ChildViewRemoved += OnChildViewRemoved;

                if(preloadTask != null)
                    await preloadTask;

                _blocker?.Unblock(newPage);

                // ───────────────────────────────
                // History
                // ───────────────────────────────
                if(recordHistory && fromPage != null)
                {
                    NavigationHistory.Record(fromPage);
                    HistoryChanged?.Invoke();
                }

                CurrentChanged?.Invoke(Current);
                Navigated?.Invoke(fromPage, newPage, navArgs);
            }
            catch(Exception ex)
            {
                NavigationFailed?.Invoke(fromPage, pageType, ex);
                throw;
            }
            finally
            {
                if(useMask)
                    PageMaskService.Hide();

                _isNavigating = false;
            }
        }












        //    private static async Task SwitchInternal(
        //Type pageType,
        //NavigationArgs navArgs,
        //bool recordHistory = true)
        //    {
        //        if(_host == null)
        //            throw new InvalidOperationException(
        //                "NavigationService.Initialize must be called first.");

        //        if(_isNavigating)
        //            return;

        //        _isNavigating = true;
        //        Task preloadTask = null;
        //        IPageView fromPage = Current;
        //        IPageView newPage = null;
        //        PageDescriptor desc = PageRegistry.GetDescriptor(pageType);

        //        if(navArgs.UseMask)
        //            PageMaskService.Show("Carregando...");

        //        try
        //        {
        //            Navigating?.Invoke(Current, pageType, navArgs);

        //            // ───────────────────────────────
        //            // Resolve + lifecycle registration
        //            // ───────────────────────────────
        //            newPage = PageRegistry.Resolve(pageType, pageType.Name);
        //            PageLifecycleTracker.Register(
        //                newPage,
        //                PageRegistry.GetDescriptor(pageType));

        //            // ───────────────────────────────
        //            // LEAVE current page
        //            // ───────────────────────────────
        //            if(fromPage is IPageLifecycle leave)
        //                await leave.OnLeave();

        //            // ───────────────────────────────
        //            // Dispose current page by policy
        //            // ───────────────────────────────
        //            if(fromPage != null)
        //            {
        //                fromPage.ChildViewAdded -= OnChildViewAdded;
        //                fromPage.ChildViewRemoved -= OnChildViewRemoved;

        //                // UI responsibility
        //                _host.Detach(fromPage);

        //                // Logical cleanup
        //                await PageLifecycleCleanupService.CleanupAsync(
        //                    fromPage,
        //                    _events);
        //            }

        //            // ───────────────────────────────
        //            // ATTACH new page
        //            // ───────────────────────────────
        //            newPage.OnAttach(_host);
        //            newPage.IsVisible = true;

        //            PageLifecycleTracker.Update(
        //                newPage,
        //                PageLifecycleState.Attached);

        //            Current = newPage;

        //            // ───────────────────────────────
        //            // ENTER new page
        //            // ───────────────────────────────
        //            switch(desc.WaitCompletionBeforeShow)
        //            {
        //                case NavigationLoadMode.LoadBeforeShow:
        //                    await ResolveLoadAsync(newPage, navArgs.Payload);
        //                    break;

        //                case NavigationLoadMode.LoadInBackground:
        //                    preloadTask = ResolveLoadAsync(newPage, navArgs.Payload);
        //                    break;

        //                case NavigationLoadMode.ShowImmediately:
        //                default:
        //                    preloadTask = ResolveLoadAsync(newPage, navArgs.Payload);
        //                    break;
        //            }
        //            if(newPage is IPageLifecycle enter)
        //                await enter.OnEnter(navArgs.Payload);




        //            PageLifecycleTracker.Update(
        //                newPage,
        //                PageLifecycleState.Entered);

        //            // ───────────────────────────────
        //            // Events + timeout reset
        //            // ───────────────────────────────
        //            _events?.AttatchEvent<EventHandler>(
        //                newPage.NativeView,
        //                "Click",
        //                TimeoutService.Reset);

        //            newPage.ChildViewAdded += OnChildViewAdded;
        //            newPage.ChildViewRemoved += OnChildViewRemoved;
        //            if(preloadTask!=null)
        //                await preloadTask;
        //            _host.BringToFront(newPage);
        //            _blocker?.Unblock(newPage);

        //            // ───────────────────────────────
        //            // History
        //            // ───────────────────────────────
        //            if(recordHistory && fromPage != null)
        //            {
        //                NavigationHistory.Record(fromPage);
        //                HistoryChanged?.Invoke();
        //            }

        //            CurrentChanged?.Invoke(Current);
        //            Navigated?.Invoke(fromPage, newPage, navArgs);
        //        }
        //        catch(Exception ex)
        //        {
        //            NavigationFailed?.Invoke(fromPage, pageType, ex);
        //            throw;
        //        }
        //        finally
        //        {
        //            if(navArgs.UseMask)
        //                PageMaskService.Hide();
        //            TimeoutService.Reset(Current,EventArgs.Empty);
        //            _isNavigating = false;
        //        }
        //    }

        //    private static async Task SwitchInternal3(
        //Type pageType,
        //NavigationArgs navArgs,
        //bool recordHistory = true)
        //    {
        //        if(_host == null)
        //            throw new InvalidOperationException("NavigationService.Initialize required.");

        //        if(_isNavigating)
        //            return;

        //        _isNavigating = true;

        //        IPageView fromPage = Current;
        //        IPageView newPage = null;
        //        Task preloadTask = null;
        //        if(navArgs.UseMask)
        //            PageMaskService.Show("Carregando...");
        //        PageDescriptor desc = PageRegistry.GetDescriptor(pageType);
        //        try
        //        {
        //            Navigating?.Invoke(Current, pageType, navArgs);

        //            newPage = PageRegistry.Resolve(pageType, pageType.Name);
        //            PageLifecycleTracker.Register(newPage, PageRegistry.GetDescriptor(pageType));

        //            // LEAVE
        //            if(fromPage is IPageLifecycle leave)
        //                await leave.OnLeave();

        //            // CLEANUP
        //            await PageCleanupService.CleanupAsync(fromPage);
        //            fromPage?.OnDetach();

        //            // DETACH + CLEANUP
        //            if(fromPage != null)
        //            {
        //                PageEventCleanup.Cleanup(fromPage, _events);

        //                fromPage.ChildViewAdded -= OnChildViewAdded;
        //                fromPage.ChildViewRemoved -= OnChildViewRemoved;

        //                await PageCleanupService.DisposePage(fromPage);
        //                fromPage.OnDetach();
        //            }

        //            // ATTACH
        //            newPage.OnAttach(_host);
        //            newPage.IsVisible = true;


        //            async Task ResolveReload(IPageView page, object args)
        //            {
        //                if(newPage is IPageLifecycle _enter)
        //                    await _enter.OnEnter(navArgs.Payload);
        //                else
        //                    await newPage.Reload(navArgs.Payload);
        //            }


        //            Current = newPage;
        //            // ENTER
        //            switch(desc.WaitCompletionBeforeShow)
        //            {
        //                case NavigationLoadMode.LoadBeforeShow:
        //                    await ResolveReload(newPage, navArgs.Payload);
        //                    break;

        //                case NavigationLoadMode.LoadInBackground:
        //                    _ = Task.Run(() => ResolveReload(newPage, navArgs.Payload)) ;
        //                    break;

        //                case NavigationLoadMode.ShowImmediately:
        //                default:
        //                    preloadTask = ResolveReload(newPage, navArgs.Payload);
        //                    break;
        //            }

        //            // EVENTS
        //            _events?.AttatchEvent<EventHandler>(
        //                    newPage.NativeView, "Click", TimeoutService.Reset);

        //            newPage.ChildViewAdded += OnChildViewAdded;
        //            newPage.ChildViewRemoved += OnChildViewRemoved;

        //            _host.BringToFront(newPage);

        //            if(recordHistory && fromPage != null)
        //            {
        //                NavigationHistory.Record(fromPage);
        //                HistoryChanged?.Invoke();
        //            }

        //            CurrentChanged?.Invoke(Current);
        //            Navigated?.Invoke(fromPage, newPage, navArgs);
        //        }
        //        catch(Exception ex)
        //        {
        //            NavigationFailed?.Invoke(fromPage, pageType, ex);
        //            throw;
        //        }
        //        finally
        //        {
        //            if(navArgs.UseMask)
        //                PageMaskService.Hide();

        //            _blocker?.Unblock(Current);
        //            _isNavigating = false;
        //        }
        //    }

        //    private static async Task SwitchInternal1(Type pageType, NavigationArgs navArgs, bool recordHistory = true)
        //    {
        //        if(_host == null)
        //            throw new InvalidOperationException("NavigationService.Initialize must be called before switching pages.");
        //        if(_isNavigating)
        //            return; // Or: throw; or queue logic depending on app philosophy.

        //        _isNavigating = true;
        //        Task preloadTask = null;
        //        IPageView fromPage = Current;
        //        if(navArgs.UseMask)
        //            PageMaskService.Show("Carregando...");
        //        PageDescriptor desc = PageRegistry.GetDescriptor(pageType);
        //        TimeoutService.Reset(fromPage, EventArgs.Empty);

        //        try
        //        {
        //            // ---------------------------------------------------------
        //            // 1) Construct or resolve target page FIRST
        //            // ---------------------------------------------------------
        //            Navigating?.Invoke(Current, pageType, navArgs);
        //            //IPageView newPage = navArgs.UseCache ? PageRegistry.Resolve(pageType, pageType.Name) : 
        //            //                                       PageRegistry.CreateNew(pageType, pageType.Name);
        //            IPageView newPage = PageRegistry.Resolve(pageType, pageType.Name);
        //            PageLoggerService.LogNavigation(Current, newPage, navArgs);


        //            // ---------------------------------------------------------
        //            // 2) Start loading its data IN PARALLEL (but not awaited yet)
        //            // ---------------------------------------------------------
        //            newPage.IsVisible = false;
        //            switch(desc.WaitCompletionBeforeShow)
        //            {
        //                case NavigationLoadMode.LoadBeforeShow:
        //                    await newPage.Reload(navArgs.Payload);
        //                    break;

        //                case NavigationLoadMode.LoadInBackground:
        //                    _ = Task.Run(() => newPage.Reload(navArgs.Payload));
        //                    break;

        //                case NavigationLoadMode.ShowImmediately:
        //                default:
        //                    preloadTask = newPage.Reload(navArgs.Payload);
        //                    break;
        //            }
        //            // (We do NOT await yet.)


        //            // ---------------------------------------------------------
        //            // 3) Cleanup old page while new page is preparing
        //            // ---------------------------------------------------------
        //            if(Current != null)
        //            {
        //                // detach events from old page
        //                if(_events != null)
        //                    _events.DetatchEvent<EventHandler>(Current.NativeView, "Click", TimeoutService.Reset);

        //                PageEventCleanup.Cleanup(Current, _events);
        //                Current.ChildViewAdded -= OnChildViewAdded;
        //                Current.ChildViewRemoved -= OnChildViewRemoved;

        //                await PageCleanupService.DisposePage(Current);

        //                Current.OnDetach();
        //                _blocker?.Block(Current);
        //            }


        //            // ---------------------------------------------------------
        //            // 4) Attach the new page to UI
        //            // ---------------------------------------------------------
        //            newPage.OnAttach(_host);
        //            newPage.IsVisible = true;
        //            Current = newPage;



        //            // ---------------------------------------------------------
        //            // 5) Hook events AFTER attaching
        //            // ---------------------------------------------------------
        //            if(_events != null)
        //                _events.AttatchEvent<EventHandler>(newPage.NativeView, "Click", TimeoutService.Reset);

        //            newPage.ChildViewAdded += OnChildViewAdded;
        //            newPage.ChildViewRemoved += OnChildViewRemoved;


        //            // ---------------------------------------------------------
        //            // 6) Now we await the preload safely
        //            // ---------------------------------------------------------
        //            //if(preloadTask != null)
        //            //   await preloadTask.ContinueWith((t)=> {
        //            //        if(navArgs.UseMask)
        //            //            PageMaskService.Hide();
        //            //            });

        //            _host.BringToFront(newPage);

        //            if(ReferenceEquals(Current, newPage))
        //                CurrentChanged?.Invoke(Current);
        //            else throw new Exception("Navigation failed");
        //            //NavigationHistory.RecordNavigation(Current, newPage);
        //            if(recordHistory && fromPage != null)
        //            {
        //                NavigationHistory.Record(fromPage);
        //                HistoryChanged?.Invoke();
        //            }

        //        }
        //        catch(Exception ex) { NavigationFailed?.Invoke(fromPage, pageType, ex); }
        //        finally
        //        {
        //            if(navArgs.UseMask)
        //                PageMaskService.Hide();
        //            _blocker?.Unblock(Current);
        //            _isNavigating = false;
        //        }
        //    }

        //public static async Task DisposePage(IPageView page)
        //{
        //    if(page == null)
        //        return;

        //    var desc = PageRegistry.GetDescriptor(page.GetType());

        //    PageEventCleanup.Cleanup(page, _events);

        //    switch(desc.CachePolicy)
        //    {
        //        case PageCachePolicy.Disabled:
        //        case PageCachePolicy.Stackable:
        //            await SafeRelease(page);
        //            page.Dispose();
        //            break;

        //        case PageCachePolicy.WeakSingleton:
        //            await SafeRelease(page);
        //            break;

        //        case PageCachePolicy.StrongSingleton:
        //            break;
        //    }
        //}

        //private static async Task SafeRelease(IPageView page)
        //{
        //    try
        //    {
        //        await page.ReleaseResources();
        //    }
        //    catch(Exception ex)
        //    {
        //        PageLogger.LogError(
        //            $"ReleaseResources failed on {page.Name}: {ex.Message}");
        //    }
        //}





    }

}
