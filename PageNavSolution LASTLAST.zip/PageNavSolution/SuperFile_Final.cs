﻿
namespace PageNav.Diagnostics
{
    public static class PageLoggerService
    {
        private static readonly List<PageLogEntry> _entries = new List<PageLogEntry>();

        public static void LogNavigation(IPageView from, IPageView to, NavigationArgs args)
        {
            _entries.Add(new PageLogEntry(
                from?.Name ?? "null",
                to?.Name ?? "null",
                args
            ));
        }

        public static IEnumerable<PageLogEntry> All => _entries;

        public static IEnumerable<PageLogEntry> Last(int count) =>
            _entries.Count <= count ? _entries : _entries.GetRange(_entries.Count - count, count);
    }

    
    
    
    
    public static class PageLogger
    {
        private static readonly object _lock = new object();
        private static string _logPath = "page_registry.log";

        
        
        
        public static void SetLogFile(string path)
        {
            lock(_lock)
            {
                _logPath = path;
            }
        }

        
        
        
        public static void Log(string category, string message)
        {
            lock(_lock)
            {
                var str = $"[{DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss.fff")}][{category}]{message}\n";
                Console.WriteLine(str);
                File.AppendAllText(_logPath, str);
            }
        }

        public static void LogInfo(string msg) { Log("INFO", msg); }
        public static void LogWarn(string msg) { Log("WARN", msg); }
        public static void LogError(string msg) { Log("ERROR", msg); }
    }

}

public static class PlatformRegistry
{
    private static readonly List<IPlatformAdapter> _adapters = new List<IPlatformAdapter>();
    private static bool _lockRegistration;
    private static IPlatformAdapter _resolvedAdapter;

    
    
    
    public static void Register(IPlatformAdapter adapter)
    {
        if(adapter == null)
            throw new ArgumentNullException(nameof(adapter));

        if(_lockRegistration)
            throw new InvalidOperationException("Platform adapters must be registered before initialization.");

        _adapters.Add(adapter);
    }

    
    
    
    
    public static IPlatformAdapter ResolveHost(object host)
    {
        if(host == null)
            throw new ArgumentNullException(nameof(host));

        
        if(_resolvedAdapter != null)
            return _resolvedAdapter;

        foreach(var adapter in _adapters)
        {
            if(adapter.CanHandle(host))
            {
                _resolvedAdapter = adapter;
                _lockRegistration = true;
                return adapter;
            }
        }

        throw new NotSupportedException(
            $"No registered platform adapter can handle host type: {host.GetType().FullName}.\n" +
            $"Registered adapters: {string.Join(", ", _adapters.Select(a => a.GetType().Name))}");
    }
}

[assembly: AssemblyTitle("PageNav")]
[assembly: AssemblyDescription("")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("")]
[assembly: AssemblyProduct("PageNav")]
[assembly: AssemblyCopyright("Copyright ©  2025")]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyCulture("")]

[assembly: ComVisible(false)]

[assembly: Guid("6fee5986-e8a0-4ddf-b944-2af7162dfbb5")]

[assembly: AssemblyVersion("1.0.0.0")]
[assembly: AssemblyFileVersion("1.0.0.0")]

namespace PageNav.Core.Abstractions
{
    public enum DialogIcon
    {
        None,
        Info,
        Warning,
        Error,
        Question
    }
    public enum DialogResult
    {
        None,
        Ok,
        Yes,
        No,
        Cancel,
        Abort,
Ignore,
Retry,

    }

    public interface IDialogService
    {
        
        Task<DialogResult> ShowMessageAsync(string message, string title = null, DialogIcon icon = DialogIcon.Info);

        
        Task<DialogResult> ShowConfirmAsync(string message, string title = null, DialogIcon icon = DialogIcon.Question);

       
    }
}

namespace PageNav.Core.Abstractions
{
    
    
    
    
    public interface IPageHost
    {

        
        
        
        
        void AddView(object frameworkView);

        
        
        
        void RemoveView(object frameworkView);

        
        
        
        void BringToFront(object frameworkView);

        
        
        
        void Focus(object frameworkView);
    }
}

namespace PageNav.Core.Abstractions
{
    
    
    
    
    public interface IPageView : IDisposable
    {
        bool DesignMode { get; }
        event Action<object> ChildViewAdded;
        event Action<object> ChildViewRemoved;
        
        
        
        string Name { get; }

        
        
        
        
        bool IsVisible { get; set; }

        
        
        
        bool IsLocked { get; set; }

        
        
        
        
        void OnAttach(IPageHost host);

        
        
        
        void OnDetach();

        event Action OnDetachEvent;

        
        
        
        
        Task Reload(object args);

        
        
        
        void Enable();

        
        
        
        void Disable();

        
        
        
        
        Task ReleaseResources();
        object NativeView { get; }
    }

}

namespace PageNav.Core.Abstractions
{
    public interface IPlatformAdapter
    {
        bool CanHandle(object host);

        IPageHost CreateHost(object host);
        IPageMask CreateMask(object host);
        IEventDispatcherAdapter CreateEventDispatcher(object host);
        IInteractionBlocker CreateInteractionBlocker(object host);
        ITimerAdapter CreateTimerAdapter();
        IDialogService CreateDialogService(object host);
    }
}

namespace PageNav.Core.Models
{
    
    
    

    
    
    
    
    public sealed class PageDescriptor
    {
        
        public Type PageType { get; set; }

        
        public string Name { get; set; }

        
        public PageKind Kind { get; set; }

        
        public PageCachePolicy CachePolicy { get; set; }

        
        public IPageView CachedInstance { get; set; }

        
        public Stack<IPageView> StackInstances { get; private set; }
        public NavigationLoadMode WaitCompletionBeforeShow { get; set; }

        
        public HashSet<string> Tags { get; set; }
        public TimeoutService.TimeoutBehavior Timeout { get; set; } = TimeoutBehavior.Default;

        
        
        
        public PageDescriptor()
        {
            StackInstances = new Stack<IPageView>();
            Tags = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
        }
    }
}

namespace PageNav.Core.Models
{
    public sealed class PageHistoryEntry
    {
        public readonly IPageView Instance;
        public readonly DateTime Timestamp;

        public PageHistoryEntry(IPageView instance)
        {
            Instance = instance;
            Timestamp = DateTime.Now;
        }

        public override string ToString() => $"{Instance.Name} ({Timestamp:HH:mm:ss})";
    }
}

namespace PageNav.Core.Models
{
    public readonly struct PageLogEntry
    {
        public readonly string From;
        public readonly string To;
        public readonly DateTime Timestamp;
        public readonly NavigationArgs Args;

        public PageLogEntry(string from, string to, NavigationArgs args)
        {
            From = from;
            To = to;
            Args = args;
            Timestamp = DateTime.Now;
        }
    }
}

namespace PageNav.Core.Services
{
    public static class NavigationHistory
    {
        private static readonly Stack<PageHistoryEntry> _back = new Stack<PageHistoryEntry>();
        private static readonly Stack<PageHistoryEntry> _forward = new Stack<PageHistoryEntry>();

        public static bool CanGoBack => _back.Count > 0;
        public static bool CanGoForward => _forward.Count > 0;

        internal static void Record(IPageView fromPage)
        {
            if(fromPage == null) return;
            _back.Push(new PageHistoryEntry(fromPage));
            _forward.Clear();
        }

        internal static PageHistoryEntry PopBack() => _back.Pop();
        internal static void PushForward(PageHistoryEntry entry) => _forward.Push(entry);
        internal static PageHistoryEntry PopForward() => _forward.Pop();

        public static IEnumerable<PageHistoryEntry> HistoryBack => _back.ToList();
        public static IEnumerable<PageHistoryEntry> HistoryForward => _forward.ToList();
    }
}

namespace PageNav.Core.Services
{

    public enum NavigationLoadMode
    {
        ShowImmediately,     
        LoadBeforeShow,      
        LoadInBackground     
    }
    public readonly struct NavigationArgs
    {
        public readonly object Payload;
        public readonly bool UseMask;
        public readonly bool UseCache;
        public readonly NavigationLoadMode LoadMode;

        public NavigationArgs(object payload = null,
                              bool useMask = true,
                              bool useCache = true,
                              NavigationLoadMode loadMode = NavigationLoadMode.ShowImmediately)
        {
            Payload = payload;
            UseMask = useMask;
            UseCache = useCache;
            LoadMode = loadMode;
        }
    }
    public static partial class NavigationService
    {
        private static IPageHost _host;

        public static IPageView Current { get; private set; }
        public static IInteractionBlocker _blocker;
        private static IEventDispatcherAdapter _events;
        private static IPageMask _mask;
        public static event Action<IPageView, Type, NavigationArgs> Navigating;
        public static event Action<IPageView, IPageView, NavigationArgs> Navigated;
        public static event Action<IPageView, Type, Exception> NavigationFailed;
        public static event Action<IPageView> CurrentChanged;
        public static event Action HistoryChanged;
        public static IDialogService Dialogs { get; private set; }
      
      
        public static void Initialize(object nativeHost, int timeoutSeconds = 10)
        {
            if(nativeHost == null)
                throw new ArgumentNullException(nameof(nativeHost));

            
            var adapter = PlatformRegistry.ResolveHost(nativeHost);
            
            _host = adapter.CreateHost(nativeHost);

            
            _mask = adapter.CreateMask(nativeHost);
            _events = adapter.CreateEventDispatcher(nativeHost);
            _blocker = adapter.CreateInteractionBlocker(nativeHost);
            var timer = adapter.CreateTimerAdapter();
            Dialogs = adapter.CreateDialogService(nativeHost);
            
            PageMaskService.Initialize(_mask);
            TimeoutService.Initialize(timer, timeoutSeconds);

            TimeoutService.TimeoutReached += OnTimeout;
        }

        
        
        

        
        
        
        public static Task SwitchPage<T>(object args = null) where T : IPageView => SwitchInternal(typeof(T), new NavigationArgs(useCache: true, payload: args));

        
        
        
        public static Task SwitchTransient<T>(object args = null) where T : IPageView => SwitchInternal(typeof(T), new NavigationArgs(useCache: false, payload: args));

        
        
        
        public static Task SwitchPage(Type type, object args = null) => SwitchInternal(type, new NavigationArgs(useCache: true, payload: args));

        
        
        
        public static Task SwitchTransient(Type type, object args = null) => SwitchInternal(type, new NavigationArgs(useCache: false, payload: args));

        public static async Task GoHomeAsync(object args = null)
        {
            var target = PageRegistry.ResolveTimeoutTarget();

            if(target == null)
                return; 

            await SwitchInternal(target.GetType(), new NavigationArgs(args));
        }

       

        public static async Task<bool> GoBackAsync()
        {
            if(!NavigationHistory.CanGoBack) return false;

            var entry = NavigationHistory.PopBack();
            NavigationHistory.PushForward(new PageHistoryEntry(Current));

            await SwitchInternal(entry.Instance.GetType(),
                                 new NavigationArgs(entry.Instance),
                                 recordHistory: false);
            return true;
        }

        public static async Task<bool> GoForwardAsync()
        {
            if(!NavigationHistory.CanGoForward) return false;

            var entry = NavigationHistory.PopForward();
            NavigationHistory.Record(Current);

            await SwitchInternal(entry.Instance.GetType(),
                                 new NavigationArgs(entry.Instance),
                                 recordHistory: false);
            return true;
        }

    }
}

namespace PageNav.Core.Services
{
    public static partial class NavigationService
    {

        private static void OnChildViewAdded(object obj)
        {

            
            if(_events != null)
                _events.AttatchEvent<EventHandler>(obj, "Click", TimeoutService.Reset);

        }

        private static void OnChildViewRemoved(object obj)
        {

            if(_events != null)
                _events.DetatchEvent<EventHandler>(obj, "Click", TimeoutService.Reset);

        }

        
        
        
        private static async void OnTimeout()
        {

            if(Current != null)
            {
                var desc = PageRegistry.GetDescriptor(Current.GetType());

                switch(desc.Timeout)
                {
                    case TimeoutBehavior.IgnoreTimeout:
                        return;

                    case TimeoutBehavior.OverrideHome:
                        await SwitchInternal(desc.PageType, new NavigationArgs());
                        return;
                }
            }
            
            try
            {
                var target = PageRegistry.ResolveTimeoutTarget();

                if(target == null)
                    return; 
                
                
                await SwitchInternal(target.GetType(), new NavigationArgs(null));
            }
            catch(Exception ex)
            {
                PageLogger.LogError($"Timeout navigation failed: {ex.Message}");
            }

        }

    }
}

namespace PageNav.Core.Services
{
    public static partial class NavigationService
    {
        
        
        
        private static bool _isNavigating;

        private static async Task SwitchInternal(Type pageType, NavigationArgs navArgs, bool recordHistory = true)
        {
            if(_host == null)
                throw new InvalidOperationException("NavigationService.Initialize must be called before switching pages.");
            if(_isNavigating)
                return; 

            _isNavigating = true;
            Task preloadTask = null;
            IPageView fromPage = Current;
            if(navArgs.UseMask)
                PageMaskService.Show("Carregando...");
            PageDescriptor desc = PageRegistry.GetDescriptor(pageType);
            TimeoutService.Reset(fromPage, EventArgs.Empty);

            try
            {
                
                
                
                Navigating?.Invoke(Current, pageType, navArgs);
                
                
                IPageView newPage = PageRegistry.Resolve(pageType, pageType.Name);
                PageLoggerService.LogNavigation(Current, newPage, navArgs);

                
                
                
                newPage.IsVisible = false;
                switch(desc.WaitCompletionBeforeShow)
                {
                    case NavigationLoadMode.LoadBeforeShow:
                        await newPage.Reload(navArgs.Payload);
                        break;

                    case NavigationLoadMode.LoadInBackground:
                        _ = Task.Run(() => newPage.Reload(navArgs.Payload));
                        break;

                    case NavigationLoadMode.ShowImmediately:
                    default:
                        preloadTask = newPage.Reload(navArgs.Payload);
                        break;
                }
                

                
                
                
                if(Current != null)
                {
                    
                    if(_events != null)
                        _events.DetatchEvent<EventHandler>(Current.NativeView, "Click", TimeoutService.Reset);

                    Current.ChildViewAdded -= OnChildViewAdded;
                    Current.ChildViewRemoved -= OnChildViewRemoved;

                    await CleanupPageAsync(Current);

                    Current.OnDetach();
                    _blocker?.Block(Current);
                }

                
                
                
                newPage.OnAttach(_host);
                newPage.IsVisible = true;
                Current = newPage;

                
                
                
                if(_events != null)
                    _events.AttatchEvent<EventHandler>(newPage.NativeView, "Click", TimeoutService.Reset);

                newPage.ChildViewAdded += OnChildViewAdded;
                newPage.ChildViewRemoved += OnChildViewRemoved;

                
                
                
                
                
                
                
                

                _host.BringToFront(newPage);

                if(ReferenceEquals(Current, newPage))
                    CurrentChanged?.Invoke(Current);
                else throw new Exception("Navigation failed");
                
                if(recordHistory && fromPage != null)
                {
                    NavigationHistory.Record(fromPage);
                    HistoryChanged?.Invoke();
                }

            }
            catch(Exception ex) { NavigationFailed?.Invoke(fromPage, pageType, ex); }
            finally
            {
                if(navArgs.UseMask)
                    PageMaskService.Hide();
                _blocker?.Unblock(Current);
                _isNavigating = false;
            }
        }

        private static async Task CleanupPageAsync(IPageView page)
        {
            if(page == null) return;

            var desc = PageRegistry.GetDescriptor(page.GetType());

            switch(desc.CachePolicy)
            {
                case PageCachePolicy.Disabled:
                    await page.ReleaseResources();
                    page.Dispose();
                    break;

                case PageCachePolicy.WeakSingleton:
                    await page.ReleaseResources();
                    break;

                case PageCachePolicy.StrongSingleton:
                    
                    break;

                case PageCachePolicy.Stackable:
                    
                    break;
            }
        }

    }
}

namespace PageNav.Core.Services
{
    public static class PageMaskService
    {
        private static IPageMask _mask;

        public static void Initialize(IPageMask mask)
        {
            _mask = mask ?? throw new ArgumentNullException(nameof(mask));
        }

        public static void Show(string message = "")
        {
            _mask?.Show(message);
        }

        public static void Hide()
        {
            _mask?.Hide();
        }
    }
}

namespace PageNav.Core.Services
{
    
    
    

    
    
    
    
    [Flags]
    public enum PageKind
    {
        Home = 1,
        Default = 2,
        Modal = 4,
        Popup = 8
    }

    
    
    
    public enum PageCachePolicy
    {
        None = 0,
        Disabled = 1,
        WeakSingleton = 2,
        StrongSingleton = 4,
        Stackable = 8
    }

   

    
    
    

    
    
    
    [AttributeUsage(AttributeTargets.Class, AllowMultiple = false)]
    public sealed class PageBehaviorAttribute : Attribute
    {
        public TimeoutBehavior Timeout { get; set; } = TimeoutBehavior.Default;

        public NavigationLoadMode WaitCompletionBeforeShow { get; set; } = NavigationLoadMode.ShowImmediately;
        
        public PageKind Kind { get; private set; }

        
        public PageCachePolicy CachePolicy { get; private set; }

        
        
        
        public string NameOverride { get; set; }

        
        
        
        public string[] Tags { get; set; }

        
        
        
        public PageBehaviorAttribute(
            PageKind kind = PageKind.Default,
            PageCachePolicy cachePolicy = PageCachePolicy.Disabled)
        {
            Kind = kind;
            CachePolicy = cachePolicy;
        }
    }

    
    
    

    
    
    
    
    public static class PageRegistry
    {
        private static readonly Dictionary<string, PageDescriptor> _registry =
            new Dictionary<string, PageDescriptor>(StringComparer.OrdinalIgnoreCase);

        
        
        

        
        
        
        public static void Register<T>() where T : IPageView
        {
            Register(typeof(T));
        }

        
        
        
        public static void RegisterFromAssembly(Assembly asm)
        {
            foreach(Type t in asm.GetTypes())
            {
                if(IsPageType(t))
                    Register(t);
            }
        }

        
        
        
        
        public static bool TryRegisterFromCurrentAssembly()
        {
            Assembly asm = Assembly.GetExecutingAssembly();
            List<Type> found = new List<Type>();

            foreach(Type t in asm.GetTypes())
            {
                if(IsPageType(t))
                {
                    Register(t);
                    found.Add(t);
                }
            }
            PageLogger.LogInfo("Auto-registered " + found.Count + " pages from executing assembly.");

            return found.Count > 0;
        }

        private static bool IsPageType(Type t)
        {
            return typeof(IPageView).IsAssignableFrom(t) && !t.IsAbstract;
        }

        
        
        
        public static void Register(Type pageType)
        {
            if(!IsPageType(pageType))
                throw new ArgumentException("Type must implement IPageView.", "pageType");

            PageBehaviorAttribute attr =
                (PageBehaviorAttribute)pageType.GetCustomAttributes(typeof(PageBehaviorAttribute), true)
                    .FirstOrDefault();

            string name = attr != null && attr.NameOverride != null
                ? attr.NameOverride
                : pageType.Name;

            if(_registry.ContainsKey(name))
            {
                PageLogger.LogWarn("Attempt to register duplicate page '" + name + "' ignored.");
                return;
            }

            PageDescriptor d = new PageDescriptor();
            d.PageType = pageType;
            d.Name = name;
            d.Kind = attr != null ? attr.Kind : PageKind.Default;
            d.CachePolicy = attr != null ? attr.CachePolicy : PageCachePolicy.Disabled;
            d.Timeout = attr != null ? attr.Timeout : TimeoutBehavior.Default;
            d.WaitCompletionBeforeShow = attr != null ? attr.WaitCompletionBeforeShow : NavigationLoadMode.ShowImmediately;
            if(attr != null && attr.Tags != null)
            {
                foreach(string s in attr.Tags)
                    d.Tags.Add(s);
            }

            _registry[name] = d;
            PageLogger.LogInfo($"Registered Page '{name}' (Type={pageType.Name}), Kind={d.Kind}, CachePolicy={d.CachePolicy}, Tags=[{string.Join(",", d.Tags.ToArray())}])");

        }

        
        
        

        
        public static void AddTag(string pageName, string tag)
        {
            PageDescriptor d;
            if(_registry.TryGetValue(pageName, out d))
            {
                d.Tags.Add(tag);
                PageLogger.LogInfo("Tag '" + tag + "' added to page '" + pageName + "'.");
            }
        }

        
        public static bool HasTag(string pageName, string tag)
        {
            PageDescriptor d;
            return _registry.TryGetValue(pageName, out d) && d.Tags.Contains(tag);
        }

        
        public static IEnumerable<string> GetTags(string pageName)
        {
            PageDescriptor d;
            if(_registry.TryGetValue(pageName, out d))
                return d.Tags;

            return new string[0];
        }

        
        
        

        
        
        
        public static IPageView FirstByTag(string tag)
        {
            foreach(PageDescriptor d in _registry.Values)
            {
                if(d.Tags.Contains(tag))
                {
                    PageLogger.LogInfo("FirstByTag('" + tag + "') resolved page '" + d.Name + "'.");
                    return Resolve(d.PageType, d.Name);
                }
            }
            PageLogger.LogWarn("FirstByTag('" + tag + "') found no matching page.");

            return null;
        }

        
        
        
        public static IEnumerable<IPageView> AllByTag(string tag)
        {
            foreach(PageDescriptor d in _registry.Values)
            {
                if(d.Tags.Contains(tag))
                {
                    PageLogger.LogInfo("AllByTag('" + tag + "') yielding page '" + d.Name + "'.");
                    yield return Resolve(d.PageType, d.Name);
                }
            }
        }

        
        
        

        
        
        
        public static IPageView Resolve(Type type, string name, bool silent = false)
        {
            PageDescriptor info;
            if(!_registry.TryGetValue(name, out info))
            {
                PageLogger.LogWarn("Resolve('" + name + "') triggered auto-registration.");

                
                info = new PageDescriptor();
                info.Name = name;
                info.PageType = type;
                info.Kind = PageKind.Default;
                info.CachePolicy = PageCachePolicy.Disabled;
                _registry[name] = info;

            }
            if(!silent)
                PageLogger.LogInfo("Resolve('" + name + "') using CachePolicy=" + info.CachePolicy);
            switch(info.CachePolicy)
            {
                case PageCachePolicy.Disabled:
                    return Create(info);

                case PageCachePolicy.WeakSingleton:
                    if(info.CachedInstance == null)
                        info.CachedInstance = Create(info);
                    return info.CachedInstance;

                case PageCachePolicy.StrongSingleton:
                    if(info.CachedInstance == null)
                        info.CachedInstance = Create(info);
                    return info.CachedInstance;

                case PageCachePolicy.Stackable:
                    return PushStack(info);
            }

            return Create(info);
        }
        public static PageDescriptor GetDescriptor(Type type) => _registry.Values.First(x => x.PageType == type);
        private static IPageView Create(PageDescriptor d)
        {
            var page = (IPageView)Activator.CreateInstance(d.PageType);
            PageLogger.LogInfo("Created new instance of page '" + d.Name + "'.");
            return page;
        }
        public static IPageView CreateNew(Type type, string name)
        {
            var info = new PageDescriptor
            {
                PageType = type,
                Name = name,
                Kind = PageKind.Default,
                CachePolicy = PageCachePolicy.Disabled
            };
            return Create(info);
        }
        private static IPageView PushStack(PageDescriptor d)
        {
            IPageView page = Create(d);
            d.StackInstances.Push(page);
            PageLogger.LogInfo("Stack PUSH for page '" + d.Name + "'. Stack count now: " + d.StackInstances.Count);
            page.OnDetachEvent += async () =>
            {
                if(d.StackInstances.Count > 0 &&
                    Object.ReferenceEquals(d.StackInstances.Peek(), page))
                {
                    await PopStackAsync(d.Name);

                    PageLogger.LogInfo($"Auto Stack POP on detach ('{d.Name}') Stack count now:  {d.StackInstances.Count}");
                }
            };

            return page;
        }
        public static IPageView ResolveTimeoutTarget()
        {
            
            var byKind = _registry.Values
                .FirstOrDefault(x => x.Kind == PageKind.Home);

            if(byKind != null)
                return Resolve(byKind.PageType, byKind.Name,true);

            
            var byTag = _registry.Values
                .FirstOrDefault(x => x.Tags.Contains("home", StringComparer.OrdinalIgnoreCase));

            if(byTag != null)
                return Resolve(byTag.PageType, byTag.Name);

            
            return null;
        }
        
        
        
        public static void PopStack(string name)
        {
            PageDescriptor d;
            if(!_registry.TryGetValue(name, out d))
                throw new InvalidOperationException("Page '" + name + "' not registered.");

            if(d.CachePolicy != PageCachePolicy.Stackable)
                throw new InvalidOperationException("Page '" + name + "' is not stackable.");

            if(d.StackInstances.Count > 0)
            {
                d.StackInstances.Pop();
                PageLogger.LogInfo($"Manual Stack POP for page '{name}'. New count: {d.StackInstances.Count}");
            }
            else
            {
                PageLogger.LogWarn($"PopStack('{name}') did nothing (stack empty).");

            }
        }

        public static async Task PopStackAsync(string name)
        {
            var d = _registry[name];

            if(d.CachePolicy != PageCachePolicy.Stackable)
                throw new InvalidOperationException("Not stackable.");

            if(d.StackInstances.Count == 0)
                return;

            var page = d.StackInstances.Pop();

            await page.ReleaseResources();
            page.Dispose();
        }

    }
}

namespace PageNav.Core.Services
{
    public static class TimeoutService
    {
        public enum TimeoutBehavior
        {
            Default,
            OverrideHome,
            IgnoreTimeout
        }
        public enum TimeoutState { Uninitialized, Running, Paused, Fired, Stopped }
        public static int SecondsRemaining => _thresholdTicks - _ticks;
        public static int TotalTimeoutSeconds => (_thresholdTicks * _intervalMs) / 1000;
        public static TimeoutState State { get; private set; } = TimeoutState.Uninitialized;
        private static ITimerAdapter _timer;
        private static int _ticks;
        private static int _thresholdTicks;
        private static int _intervalMs=1000;

        public static event Action TimeoutReached;

        public static void Initialize(ITimerAdapter timerAdapter, int timeoutSeconds)
        {
            _timer = timerAdapter ?? throw new ArgumentNullException(nameof(timerAdapter));
            if(State != TimeoutState.Uninitialized)
                throw new InvalidOperationException("TimeoutService already initialized.");
            State = TimeoutState.Running;
            
            _thresholdTicks = timeoutSeconds;

            _timer.Start(_intervalMs, OnTick); 
        }

        private static void OnTick()
        {
            _ticks++;Console.WriteLine($"{_ticks}");
            if(_ticks >= _thresholdTicks)
            
            {
                
                _ticks = 0;
                Console.WriteLine($"{_ticks}");
                Reset(null, EventArgs.Empty);
                TimeoutReached?.Invoke();
            }
        }

        public static void Reset(object s, EventArgs e)
        {
            Console.WriteLine("a");
            _ticks = 0;
         }

        public static void Pause()
        {
            State = TimeoutState.Paused;
            _timer.Stop(); 
        }

        public static void Continue()
        {
            State = TimeoutState.Running;
            _timer.Continue();
              
        }
    }
}

[assembly: global::System.Runtime.Versioning.TargetFrameworkAttribute(".NETFramework,Version=v4.8.1", FrameworkDisplayName = ".NET Framework 4.8.1")]

namespace PageNav.Core.Abstractions
{
    public interface IChildWindow : IDisposable
    {
        object NativeView { get; }
        bool IsVisible { get; set; }

        event Action Closed;

        void OnAttach(IPageHost host);
        void OnDetach();

        Task<DialogResult> AwaitResultAsync();
        void SetMessage(string text);
        void SetTitle(string title);
    }
}

namespace PageNav.Core.Abstractions
{
    public interface IEventDispatcherAdapter
    {
        void AttatchEvent<THandler>(object reciever, string eventName, THandler handler) where THandler : Delegate;
        void DetatchEvent<THandler>(object reciever, string eventName, THandler handler) where THandler : Delegate;

    }
}

namespace PageNav.Core.Abstractions
{
    public interface IInteractionBlocker
    {
        void Block(object view);
        void Unblock(object view);
    }
}

namespace PageNav.Core.Abstractions
{
    public interface IMovableAdapter
    {
        void MakeMovable(object view);
        void RemoveMovable(object view);
    }
}

namespace PageNav.Core.Abstractions
{
    public interface IPageMask
    {
        void Show(string message = "");
        void Hide();
    }
}

namespace PageNav.Core.Abstractions
{
    public interface ITimerAdapter : IDisposable
    {
        void Continue();
        void Start(int intervalMilliseconds, Action tick);
        void Stop();
    }
}

