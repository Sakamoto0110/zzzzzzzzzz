﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PageNav.WinForms
{
    public static class DesignModeTools
    {
        public static bool IsInDesignMode(Control c)
        {
            if(LicenseManager.UsageMode == LicenseUsageMode.Designtime)
                return true;

            while(c != null)
            {
                if(c.Site?.DesignMode == true)
                    return true;

                c = c.Parent;
            }

            return false;
        }
    }
}
