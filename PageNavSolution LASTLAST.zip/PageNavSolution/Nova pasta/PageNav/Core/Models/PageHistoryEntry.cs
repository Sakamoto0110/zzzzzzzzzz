﻿using PageNav.Core.Abstractions;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PageNav.Core.Models
{
    public sealed class PageHistoryEntry
    {
        public readonly IPageView Instance;
        public readonly DateTime Timestamp;

        public PageHistoryEntry(IPageView instance)
        {
            Instance = instance;
            Timestamp = DateTime.Now;
        }

        public override string ToString() => $"{Instance.Name} ({Timestamp:HH:mm:ss})";
    }
}
