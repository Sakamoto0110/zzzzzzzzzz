﻿using PageNav.Core.Services;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static PageNav.Core.Services.NavigationService;

namespace PageNav.Core.Models
{
    public readonly struct PageLogEntry
    {
        public readonly string From;
        public readonly string To;
        public readonly DateTime Timestamp;
        public readonly NavigationArgs Args;

        public PageLogEntry(string from, string to, NavigationArgs args)
        {
            From = from;
            To = to;
            Args = args;
            Timestamp = DateTime.Now;
        }
    }
}
