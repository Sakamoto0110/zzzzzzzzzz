﻿namespace PageNav.Core.Abstractions
{
    public interface IPlatformAdapter
    {
        bool CanHandle(object host);

        IPageHost CreateHost(object host);
        IPageMask CreateMask(object host);
        IEventDispatcherAdapter CreateEventDispatcher(object host);
        IInteractionBlocker CreateInteractionBlocker(object host);
        ITimerAdapter CreateTimerAdapter();
        IDialogService CreateDialogService(object host);
    }
}
