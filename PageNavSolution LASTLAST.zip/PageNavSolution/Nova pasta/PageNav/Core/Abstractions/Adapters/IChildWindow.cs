﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PageNav.Core.Abstractions
{
    public interface IChildWindow : IDisposable
    {
        object NativeView { get; }
        bool IsVisible { get; set; }

        event Action Closed;

        void OnAttach(IPageHost host);
        void OnDetach();

        Task<DialogResult> AwaitResultAsync();
        void SetMessage(string text);
        void SetTitle(string title);
    }
}
