﻿using PageNav.Core.Abstractions;
using PageNav.Core.Models;
 using PageNav.Diagnostics;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using static PageNav.Core.Services.TimeoutService;

namespace PageNav.Core.Services
{

    public enum NavigationLoadMode
    {
        ShowImmediately,     // current behavior
        LoadBeforeShow,      // preload then attach + show
        LoadInBackground     // show skeleton UI while loading
    }
    public readonly struct NavigationArgs
    {
        public readonly object Payload;
        public readonly bool UseMask;
        public readonly bool UseCache;
        public readonly NavigationLoadMode LoadMode;

        public NavigationArgs(object payload = null,
                              bool useMask = true,
                              bool useCache = true,
                              NavigationLoadMode loadMode = NavigationLoadMode.ShowImmediately)
        {
            Payload = payload;
            UseMask = useMask;
            UseCache = useCache;
            LoadMode = loadMode;
        }
    }
    public static partial class NavigationService
    {
        private static IPageHost _host;

        public static IPageView Current { get; private set; }
        public static IInteractionBlocker _blocker;
        private static IEventDispatcherAdapter _events;
        private static IPageMask _mask;
        public static event Action<IPageView, Type, NavigationArgs> Navigating;
        public static event Action<IPageView, IPageView, NavigationArgs> Navigated;
        public static event Action<IPageView, Type, Exception> NavigationFailed;
        public static event Action<IPageView> CurrentChanged;
        public static event Action HistoryChanged;
        public static IDialogService Dialogs { get; private set; }
      
      
        public static void Initialize(object nativeHost, int timeoutSeconds = 10)
        {
            if(nativeHost == null)
                throw new ArgumentNullException(nameof(nativeHost));

            // Resolve platform
            var adapter = PlatformRegistry.ResolveHost(nativeHost);
            
            _host = adapter.CreateHost(nativeHost);

            // Retrieve platform-specific services (mask, event dispatcher, etc)
            _mask = adapter.CreateMask(nativeHost);
            _events = adapter.CreateEventDispatcher(nativeHost);
            _blocker = adapter.CreateInteractionBlocker(nativeHost);
            var timer = adapter.CreateTimerAdapter();
            Dialogs = adapter.CreateDialogService(nativeHost);
            // Init timeout + mask service
            PageMaskService.Initialize(_mask);
            TimeoutService.Initialize(timer, timeoutSeconds);

            TimeoutService.TimeoutReached += OnTimeout;
        }

        // -------------------------------------------------------------------------
        // PUBLIC API
        // -------------------------------------------------------------------------


        // -------------------------------------------------------------------------
        // 1) CACHED NAVIGATION (Persistent pages)
        // -------------------------------------------------------------------------
        public static Task SwitchPage<T>(object args = null) where T : IPageView => SwitchInternal(typeof(T), new NavigationArgs(useCache: true, payload: args));

        // -------------------------------------------------------------------------
        // 2) TRANSIENT NAVIGATION (New instance every time)
        // -------------------------------------------------------------------------
        public static Task SwitchTransient<T>(object args = null) where T : IPageView => SwitchInternal(typeof(T), new NavigationArgs(useCache: false, payload: args));


        // -------------------------------------------------------------------------
        // 1) CACHED NAVIGATION (Persistent pages)
        // -------------------------------------------------------------------------
        public static Task SwitchPage(Type type, object args = null) => SwitchInternal(type, new NavigationArgs(useCache: true, payload: args));

        // -------------------------------------------------------------------------
        // 2) TRANSIENT NAVIGATION (New instance every time)
        // -------------------------------------------------------------------------
        public static Task SwitchTransient(Type type, object args = null) => SwitchInternal(type, new NavigationArgs(useCache: false, payload: args));


        public static async Task GoHomeAsync(object args = null)
        {
            var target = PageRegistry.ResolveTimeoutTarget();

            if(target == null)
                return; // or throw/log depending on design

            await SwitchInternal(target.GetType(), new NavigationArgs(args));
        }



       


        public static async Task<bool> GoBackAsync()
        {
            if(!NavigationHistory.CanGoBack) return false;

            var entry = NavigationHistory.PopBack();
            NavigationHistory.PushForward(new PageHistoryEntry(Current));

            await SwitchInternal(entry.Instance.GetType(),
                                 new NavigationArgs(entry.Instance),
                                 recordHistory: false);
            return true;
        }

        public static async Task<bool> GoForwardAsync()
        {
            if(!NavigationHistory.CanGoForward) return false;

            var entry = NavigationHistory.PopForward();
            NavigationHistory.Record(Current);

            await SwitchInternal(entry.Instance.GetType(),
                                 new NavigationArgs(entry.Instance),
                                 recordHistory: false);
            return true;
        }

    }
}
