﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;

namespace SuperFileBuilder
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("=== Super File Builder (No Comments + No Usings) ===");

            string projectDir;

            if(args.Length > 0 && Directory.Exists(args[0]))
            {
                projectDir = args[0];
            }
            else
            {
                Console.Write("Enter project directory path: ");
                projectDir = Console.ReadLine();
            }

            if(!Directory.Exists(projectDir))
            {
                Console.WriteLine("ERROR: Directory does not exist.");
                return;
            }

            string outputFileName = "SuperFile_Final.cs";
            string outputFilePath = Path.Combine(projectDir, outputFileName);

            var csFiles = Directory.GetFiles(projectDir, "*.cs", SearchOption.AllDirectories)
                .Where(f => !f.EndsWith(outputFileName)) // prevent recursion
                .ToList();

            if(csFiles.Count == 0)
            {
                Console.WriteLine("No .cs files found.");
                return;
            }

            Console.WriteLine($"Found {csFiles.Count} files.");
            Console.WriteLine("Processing...");

            var mergedContent = new StringBuilder();

            foreach(var file in csFiles)
            {
                string content = File.ReadAllText(file);

                // Remove comments
                content = StripComments(content);

                // Remove using lines
                var lines = content.Split('\n')
                    .Where(l => !l.TrimStart().StartsWith("using "))
                    .ToArray();

                mergedContent.AppendLine(string.Join("\n", lines));
                mergedContent.AppendLine();
            }

            // Optional: remove duplicate multiple blank lines
            string finalOutput = Regex.Replace(mergedContent.ToString(), @"(\r?\n){3,}", "\n\n");

            File.WriteAllText(outputFilePath, finalOutput, Encoding.UTF8);

            Console.WriteLine($"DONE! Super file written to:\n{outputFilePath}");
        }

        /// <summary>
        /// Removes all types of comments (//, ///, and /* */ blocks)
        /// </summary>
        static string StripComments(string input)
        {
            // remove block comments /* ... */
            input = Regex.Replace(input, @"/\*[\s\S]*?\*/", "", RegexOptions.Multiline);

            // remove single-line // comments
            input = Regex.Replace(input, @"//.*", "");

            // remove XML triple-slash comments
            input = Regex.Replace(input, @"^\s*///.*$", "", RegexOptions.Multiline);

            return input;
        }
    }
}
