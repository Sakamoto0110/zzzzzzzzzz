﻿using PageNav.Core;
using PageNav.Core.Abstractions;
using PageNav.Core.Platform;
using PageNav.WinForms.Adapters;
using System.Windows.Forms;

namespace PageNav.WinForms
{
    public class PlatformAdapter : IPlatformAdapter
    {
        public bool CanHandle(object host) => host is System.Windows.Forms.Control;

        public IPageHost CreateHost(object host) =>
            new PageHost((Control)host);

        public IPageMask CreateMask(object host) =>
            new PageMaskAdapter((Control)host);

        public IEventDispatcherAdapter CreateEventDispatcher(object host) =>
            new EventDispatcherAdapter();

        public IInteractionBlocker CreateInteractionBlocker(object host) =>
            new InteractionBlocker();

        public ITimerAdapter CreateTimerAdapter() =>
            new TimerAdapter();
    }

    public static class WinFormsBootstrap
    {
        public static void Register() =>
            PlatformRegistry.Register(new PlatformAdapter());
    }
}
