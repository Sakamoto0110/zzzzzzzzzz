﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PageNav
{
    public interface IChildView : IDisposable
    {
        string Name { get; }
        object NativeView { get; }

        bool IsVisible { get; set; }
        bool IsModal { get; }
        bool BlocksNavigation { get; }

        Task OnShowAsync(object args);
        Task OnCloseAsync();

        event Action<IChildView> RequestClose;
    }
    public interface IChildWindowService
    {
        IReadOnlyList<IChildView> Active { get; }

        Task<IChildView> OpenAsync(Type type, ChildViewArgs args);
        Task CloseAsync(IChildView view);

        Task<DialogResult<T>> ShowDialogAsync<T>(Type dialogType, object payload = null);
    }
    public enum ChildViewType
    {
        Popup,
        ToolWindow,
        ModalDialog,
        SystemOverlay
    }
    public sealed class ChildViewArgs
    {
        public object Payload { get; }
        public ChildViewType Type { get; }
        public bool Exclusive { get; }

        public ChildViewArgs(object payload = null,
                             ChildViewType type = ChildViewType.Popup,
                             bool exclusive = false)
        {
            Payload = payload;
            Type = type;
            Exclusive = exclusive;
        }
    }

    
    public class DialogResult<T>
    {
        public bool Success { get; }
        public T Value { get; }

        public DialogResult(bool success, T value)
        {
            Success = success;
            Value = value;
        }
    }












    internal sealed class ChildWindowService : IChildWindowService
    {
        private readonly Stack<IChildView> _stack = new Stack<IChildView>();
        private readonly IPageHost _host;
        private readonly IInteractionBlocker _blocker;

        public IReadOnlyList<IChildView> Active => _stack.ToList();

        public ChildWindowService(IPageHost host, IInteractionBlocker blocker)
        {
            _host = host;
            _blocker = blocker;
        }

        public async Task<IChildView> OpenAsync(Type type, ChildViewArgs args)
        {
            var view = PageAdapterFactory.CreateChildView(type);

            view.RequestClose += async v => await CloseAsync(v);

            _stack.Push(view);

            if(view.IsModal || args.Type == ChildViewType.ModalDialog)
                _blocker.Block(NavigationService.Current?.NativeView);

            await view.OnShowAsync(args.Payload);

            _host.AddView(view.NativeView);

            return view;
        }

        public async Task CloseAsync(IChildView view)
        {
            if(!_stack.Contains(view))
                return;

            await view.OnCloseAsync();
            _host.RemoveView(view.NativeView);
            _stack.Pop();

            if(!Active.Any(x => x.IsModal))
                _blocker.Unblock(NavigationService.Current?.NativeView);

            view.Dispose();
        }

        public async Task<DialogResult<T>> ShowDialogAsync<T>(Type dialogType, object payload = null)
        {
            var tcs = new TaskCompletionSource<DialogResult<T>>();

            var dialog = await OpenAsync(dialogType,
                new ChildViewArgs(payload, ChildViewType.ModalDialog));

            if(!(dialog is  IDialogResultProvider<T> provider))
                throw new InvalidOperationException($"{dialogType.Name} must implement IDialogResultProvider<T>");

            provider.ResultAvailable += async result =>
            {
                tcs.TrySetResult(result);
                await CloseAsync(dialog);
            };

            return await tcs.Task;
        }
    }
    public interface IDialogResultProvider<T>
    {
        event Action<DialogResult<T>> ResultAvailable;
    }

}
