﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PageNav
{
    internal class DesignTimeHost : IPageHost
    {
        public void AddView(object view) { }
        public void RemoveView(object view) { }
        public void BringToFront(object view) { }
        public void Focus(object view) { }
    }
}
