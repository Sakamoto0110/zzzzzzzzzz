﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static PageNav.TimeoutService;

namespace PageNav
{
    public static partial class NavigationService
    {
        private static void OnChildViewAdded(object obj)
        {
            // Attach timeout reset handler to newly added controls
            if(_events != null)
                _events.AttatchEvent<EventHandler>(obj, "Click", TimeoutService.Reset);


        }

        private static void OnChildViewRemoved(object obj)
        {
            if(_events != null)
                _events.DetatchEvent<EventHandler>(obj, "Click", TimeoutService.Reset);


        }

        /// <summary>
        /// Default Timeout fallback
        /// </summary>
        private static async void OnTimeout()
        {

            if(Current != null)
            {
                var desc = PageRegistry.GetDescriptor(Current.GetType());

                switch(desc.Timeout)
                {
                    case TimeoutBehavior.IgnoreTimeout:
                        return;

                    case TimeoutBehavior.OverrideHome:
                        await SwitchInternal(desc.PageType, new NavigationArgs());
                        return;
                }
            }
            // try to switch to home page
            try
            {
                var target = PageRegistry.ResolveTimeoutTarget();

                if(target == null)
                    return; // or throw/log depending on design
                //if(_childManager.ActiveChildren.Any(c => c.IsLocked))
                //    return;
                await SwitchInternal(target.GetType(), new NavigationArgs(null));
            }
            catch(Exception ex)
            {
                PageLogger.LogError($"Timeout navigation failed: {ex.Message}");
            }

        }
    }
}
