﻿using PageNav.Core.Abstractions;
using PageNav.Core.Models;
using PageNav.Diagnostics;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PageNav.Core.Services
{
    public static partial class NavigationService
    {
        // -------------------------------------------------------------------------
        // INTERNAL CORE NAVIGATION LOGIC
        // -------------------------------------------------------------------------     
        private static bool _isNavigating;
        //private static async Task SwitchInternal(Type pageType, NavigationArgs navArgs)
        //{
        //    if(_isNavigating)
        //        return;
        //    _isNavigating = true;
        //    if(navArgs.UseMask)
        //        PageMaskService.Show("Carregando...");
        //    try
        //    {
        //        // remove global events from the current page
        //        if(Current != null && _events != null)
        //        {
        //            _events.DetatchEvent<EventHandler>(Current.NativeView, "Click", TimeoutService.Reset);
        //        }

        //        IPageView newPage = PageRegistry.Resolve(pageType, pageType.Name);

        //        if(navArgs.UseCache)
        //            newPage = PageRegistry.Resolve(pageType, pageType.Name);
        //        else // always create fresh, bypassing cache policy                    
        //            newPage = PageRegistry.CreateNew(pageType, pageType.Name);

        //        PageLoggerService.LogNavigation(Current, newPage, navArgs);
        //        if(Current != null)
        //        {
        //            Current.ChildViewAdded -= OnChildViewAdded;
        //            Current.ChildViewRemoved -= OnChildViewRemoved;

        //            Current.OnDetach();
        //            _blocker?.Block(Current);
        //        }

        //        newPage.OnAttach(_host);
        //        newPage.IsVisible = true;

        //        Current = newPage;
        //        // --- Attach global timeout reset events ---------------
        //        if(_events != null)
        //        {
        //            _events.AttatchEvent<EventHandler>(newPage.NativeView, "Click", TimeoutService.Reset);
        //        }
        //        // AUTOMATIC SUBSCRIPTION TO CHILD VIEW EVENTS
        //        newPage.ChildViewAdded += OnChildViewAdded;
        //        newPage.ChildViewRemoved += OnChildViewRemoved;

        //        await newPage.ReloadAsync(navArgs.Payload);
        //        _host.BringToFront(newPage);

        //    }
        //    catch { }
        //    finally
        //    {
        //        _isNavigating = false;
        //        _blocker?.Unblock(Current);
        //        if(navArgs.UseMask)
        //            PageMaskService.Hide();
        //    }
        //}


        /*
         * // ---------------------------------------------------------
        // 1) Construct or resolve target page FIRST
        // ---------------------------------------------------------
            IPageView newPage = navArgs.UseCache
            ? PageRegistry.Resolve(pageType, pageType.Name)
            : PageRegistry.CreateNew(pageType, pageType.Name);
         */

        private static async Task SwitchInternal(Type pageType, NavigationArgs navArgs, bool recordHistory = true)
        {
            if(_isNavigating)
                return; // Or: throw; or queue logic depending on app philosophy.

            _isNavigating = true;
            Task preloadTask = null;
            IPageView fromPage = Current;
            if(navArgs.UseMask)
                PageMaskService.Show("Carregando...");

            try
            {
                async void Safe()
                {
                    // ---------------------------
                    // 1) Tear down old page safely
                    // ---------------------------
                    if(Current != null)
                    {
                        // Stop event tracking
                        if(_events != null)
                            _events.DetatchEvent<EventHandler>(Current.NativeView, "Click", TimeoutService.Reset);

                        // Unsubscribe child controls
                        Current.ChildViewAdded -= OnChildViewAdded;
                        Current.ChildViewRemoved -= OnChildViewRemoved;

                        // Release or dispose depending on cache policy
                        await CleanupPageAsync(Current);

                        // Remove from host
                        Current.OnDetach();
                        _blocker?.Block(Current);
                    }


                    // ---------------------------
                    // 2) Create or reuse target page
                    // ---------------------------
                    IPageView newPage = navArgs.UseCache
                        ? PageRegistry.Resolve(pageType, pageType.Name)
                        : PageRegistry.CreateNew(pageType, pageType.Name);


                    PageLoggerService.LogNavigation(Current, newPage, navArgs);


                    // ---------------------------
                    // 3) Attach new page to UI
                    // ---------------------------
                    newPage.OnAttach(_host);
                    newPage.IsVisible = true;
                    Current = newPage;


                    // ---------------------------
                    // 4) Hook interaction / timeout events
                    // ---------------------------
                    if(_events != null)
                        _events.AttatchEvent<EventHandler>(newPage.NativeView, "Click", TimeoutService.Reset);

                    // Auto-wire child components
                    newPage.ChildViewAdded += OnChildViewAdded;
                    newPage.ChildViewRemoved += OnChildViewRemoved;


                    // ---------------------------
                    // 5) Let the page load data
                    // ---------------------------
                    await newPage.ReloadAsync(navArgs.Payload);

                    _host.BringToFront(newPage);
                    _blocker?.Unblock(Current);
                }
                async Task Paralel()
                {
                    // ---------------------------------------------------------
                    // 1) Construct or resolve target page FIRST
                    // ---------------------------------------------------------
                    //IPageView newPage = navArgs.UseCache
                    //    ? PageRegistry.Resolve(pageType, pageType.Name)
                    //    : PageRegistry.CreateNew(pageType, pageType.Name);
                    IPageView newPage = PageRegistry.Resolve(pageType, pageType.Name);

                    PageLoggerService.LogNavigation(Current, newPage, navArgs);


                    // ---------------------------------------------------------
                    // 2) Start loading its data IN PARALLEL (but not awaited yet)
                    // ---------------------------------------------------------
                    preloadTask = newPage.ReloadAsync(navArgs.Payload);

                    // (We do NOT await yet.)


                    // ---------------------------------------------------------
                    // 3) Cleanup old page while new page is preparing
                    // ---------------------------------------------------------
                    if(Current != null)
                    {
                        // detach events from old page
                        if(_events != null)
                            _events.DetatchEvent<EventHandler>(Current.NativeView, "Click", TimeoutService.Reset);

                        Current.ChildViewAdded -= OnChildViewAdded;
                        Current.ChildViewRemoved -= OnChildViewRemoved;

                        await CleanupPageAsync(Current);

                        Current.OnDetach();
                        _blocker?.Block(Current);
                    }


                    // ---------------------------------------------------------
                    // 4) Attach the new page to UI
                    // ---------------------------------------------------------
                    newPage.OnAttach(_host);
                    newPage.IsVisible = true;
                    Current = newPage;



                    // ---------------------------------------------------------
                    // 5) Hook events AFTER attaching
                    // ---------------------------------------------------------
                    if(_events != null)
                        _events.AttatchEvent<EventHandler>(newPage.NativeView, "Click", TimeoutService.Reset);

                    newPage.ChildViewAdded += OnChildViewAdded;
                    newPage.ChildViewRemoved += OnChildViewRemoved;


                    // ---------------------------------------------------------
                    // 6) Now we await the preload safely
                    // ---------------------------------------------------------
                    if(preloadTask != null)
                        await preloadTask;

                    _host.BringToFront(newPage);
                    //NavigationHistory.RecordNavigation(Current, newPage);
                    if(recordHistory && fromPage != null)
                    {
                        NavigationHistory.Record(fromPage);
                    }
                }
                await Paralel();
            }
            finally
            {
                if(navArgs.UseMask)
                    PageMaskService.Hide();
                _blocker?.Unblock(Current);
                _isNavigating = false;
            }
        }
        
        public static async Task<bool> GoBackAsync()
        {
            if(!NavigationHistory.CanGoBack) return false;

            var entry = NavigationHistory.PopBack();
            NavigationHistory.PushForward(new PageHistoryEntry(Current));

            await SwitchInternal(entry.Instance.GetType(),
                                 new NavigationArgs(entry.Instance),
                                 recordHistory: false);
            return true;
        }

        public static async Task<bool> GoForwardAsync()
        {
            if(!NavigationHistory.CanGoForward) return false;

            var entry = NavigationHistory.PopForward();
            NavigationHistory.Record(Current);

            await SwitchInternal(entry.Instance.GetType(),
                                 new NavigationArgs(entry.Instance),
                                 recordHistory: false);
            return true;
        }

        private static async Task CleanupPageAsync(IPageView page)
        {
            if(page == null) return;

            var desc = PageRegistry.GetDescriptor(page.GetType());

            switch(desc.CachePolicy)
            {
                case PageCachePolicy.Disabled:
                    await page.ReleaseResources();
                    page.Dispose();
                    break;

                case PageCachePolicy.WeakSingleton:
                    await page.ReleaseResources();
                    break;

                case PageCachePolicy.StrongSingleton:
                    // Keep intact — do nothing
                    break;

                case PageCachePolicy.Stackable:
                    // Cleanup only when popped
                    break;
            }
        }
    }
}
