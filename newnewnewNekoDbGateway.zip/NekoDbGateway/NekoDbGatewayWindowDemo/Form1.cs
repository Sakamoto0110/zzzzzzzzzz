﻿using NekoDbGateway.Dynamic;
using NekoDbGateway.Query;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace NekoDbGateway
{
    public partial class Form1 : Form
    {
        DatabaseGateway dg = new DatabaseGateway();

        public Form1()
        {
            InitializeComponent();
            
        }

        private async void button1_Click(object sender, EventArgs e)
        {
             int i = 0;
            rtbOutput.Clear();
            using(var sql = DatabaseContexts.Remote)
            {
                sql.OnSqlGenerated += (_) => Console.WriteLine("SqlGenerated");
                sql.OnSqlDispatch += (_) => Console.WriteLine("SqlDispatch");
                sql.OnSuccess += (_) => Console.WriteLine("Success");
                sql.OnError += (_) => {
                    Console.WriteLine("Error");
                };
                await dg.Read<Func>(sql,
                    new QueryBuilder()
                    .Select("Nome", "id_setor", "id_funcionario")
                    .Top(5)
                    .From("Funcionarios"),
                    (func) => {
                    
                        Invoke(new Action(() => {
                            rtbOutput.AppendText($"[{i++}]Funcionario:{func.Nome}, {func.id_funcionario}, {func.id_setor}\n");
                    
                        }));
                    });
                
        
                
            }
            
          
        }

        private async void button2_Click(object sender, EventArgs e)
        {
            rtbOutput.Clear();
           
            using(var sql = DatabaseContexts.Remote)
            {
                sql.OnSqlGenerated += (_) => Console.WriteLine("SqlGenerated");
                sql.OnSqlDispatch += (_) => Console.WriteLine("SqlDispatch");
                sql.OnSuccess += (_) => Console.WriteLine("Success");
                sql.OnError += (_) => {
                    Console.WriteLine("Error");
                };
                await dg.Read(sql,
                    new QueryBuilder()
                    .Select("Nome", "id_setor", "id_funcionario")
                    .Top(15)
                    .From("Funcionarios"),
                    (dynamic func) => {
                        Invoke(new Action(() => {
                            rtbOutput.AppendText($"Funcionario:{func.id_funcionario}, {func.id_setor}, {func["Nome"]}\n");
                        }));
                    });
            }


        }
    }
    class Func{
        public int id_funcionario { get; set; }
        public int id_setor { get; set; }
        public int Nome { get; set; }
    }

   
}
